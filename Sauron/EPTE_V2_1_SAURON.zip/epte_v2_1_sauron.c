/*
*   File: EPTE_V2_1_SAURON.c
*   
*   Descripci�n: Program file del programa principal de Sauron
*   
*   Proyecto: EPTE 2
*   Versi�n: 3.0
*
*   Ionclinics & Deionics SL
*/

/******************************** Identificador del programma ********************************/
#define SAURON

/************************************ Libreria de Programa ***********************************/
#include <EPTE_V2_1_SAURON.h>           // Libreria de definiciones
#include <math.h>                       // Libreria matem�tica
#include <stdlib.h>                     // Libreria est�ndar

/************************************ Librerias Definidas ************************************/
#include "driver_MMA8451.h"             // Librer�a del aceler�metro
#include "driver_PCA9555_PCA9554.h"     // Librer�a del expansor
#include "BQ34Z100G1.h"                 // Librer�a del monitor de bater�a
#include "ST7529.c"                     // Librer�a del GLCD 
#include "/Pictures/main_logo.c"

/*********************************** Definiciones de tipo ************************************/
typedef int8 (*pt2Fpantalla)();         // Definimos tipo de variable para apuntar a as funciones de representacion
pt2Fpantalla funcArr_menu[206]={0};     // Definimos punteros

/************************************ Prototipo Funciones ************************************/
void initReles();                                                       // Inicializaci�n de los rel�s
void control_led(int1 control,int1 color,int led);                      // Control de los LEDs de terapia       
void control_DC(int1 control,int8 DC);                                  // Control de las alimentaciones
void control_rele(int1 control,int8 rele);                              // Control de los rel�s
void ControlSonido(int1 control);                                       // Control del pito
void update_button(long *button_history);                               // Actualiza el estado del codificador
int1 read_button();                                                     // Lee el estado del codificador
int1 is_button_pressed(long *button_history);                           // Lee si se ha girado el codificador
void pausa_I(long delay);                                               // Ejecuta un delay no bloqueante
void funcion_dormir();                                                  // Funci�n que prepara el equipo para dormir
int8 nivelBateria();                                                    // Devuelve el nivel restannte de bateria (%)
int1 estadoCarga();                                                     // Devuelve el estado de carga de la bateria
int16 calc_Tgalv(int32 carga,int16 corriente);                          // ELIMINAR - Funcion para el calculo de tiempo de tratamento galvanica
int32 calc_CargaGalv(int16 corriente);                                  // Funcion para el calculo de tiempo de tratamento galvanica
int16 calc_Tmicro();                                                    // Funcion para el calculo de tiempo de tratamento microcorrientes
int16 Calc_BWmax(int16 frecuencia,int1 polaridad);                      // C�lculo del m�ximo ancho de pulso
int16 Calc_BW(int16 max,int16 BW);                                      // C�lculo del ancho de pulso
void Calc_representacion_t(int16 iTiempoActivo, int16 iTiempoReposo);   // Pasa de segundos a min:seg
int8 checkAutoapagado();                                                // Funci�n para comprobar el autoapagado del equipo
int16 redondeoI_50(int16 Ivalor);                                       // Redondeo de la corriente en pasos de 50uA
int16 redondeoI_100(int16 Ivalor);                                      // Redondeo de la corriente en pasos de 100uA
void f_avisos();                                                        // Funcion que detecta max value o baja resistencia de carga
void calculoTiempoDesfase();                                            // Calcula el iempo de desfase entre canales
void delay_ms_wdt(int16 i16DelayWDT);                                   // Funci�n utilizada para hacer un delay sin que el WDG externo reinicie el microcontrolador
void apagadoGalvanica();                                                // Apagado galv�nica
void apagadoMicrocorrientes();                                          // Apagado microcorrientes
void apagadoSMP();                                                      // Apagado del sistema multipulsos
void apagadoCHA();                                                      // Apagado del canal A
void apagadoCHB();                                                      // Apagado del canal B
void apagadoCHC();                                                      // Apagado del canal C
void apagadoCanales();                                                  // Apaga los canales dependiendo del n�mero de canales seleccionado precviamente
void maxPulsosSMP();                                                    // Calcula el m�ximo n�mero de pulsos que puede realizar por periodo en SMP
void copiarDatosSimetria(int1 bTiempo);                                 // Copia todos los datos en caso de simetria entre canales
void comprobacionLimitesFrecuencia();                                   // Comprueba los l�mites de frecuencia en cada canal y los asigna
int1 isPower12OK();                                                     // Comprobaci�n de la alimentaci�n de 12V
int1 isPower30OK();                                                     // Comrpobaci�n de la alimentaci�n de 30V
void reset_orco();                                                      // Realiza reset a Orco
void pitidoCorto();                                                     // Activa el pitido durante un corto periodo de tiempo
void pitidoLargo();                                                     // Activa el pitido durante un largo periodo de tiempo
void pitidoPointerConectado();                                          // Activa el pitido durante un corto periodo de tiempo cuando el pointer est� conectado
void pitidoPointerDesconectado();                                       // Activa el pitido durante un largo periodo de tiempo cuando el pointer est� desconectado

/************************************ Librerias Definidas ************************************/
#include "../ComLib/comunicacion_struct.c"      // Librer�a de comunicaci�n entre el PIC Sauron -> Orco
#include "menus_epte2.c"                        // Librer�a de men�s

/************************************** Interrupciones ***************************************/
// Timer 10 - Base de tiempos
#INT_TIMER10
void TIMER10_isr(void){

    restart_wdt();                              // Reinicia el contador del WDT
    
    i32ParpadeoBateria++;                       // Incremento el contador del parpadeo de bater�a          
    var_tiempo++;                               // Incremento la variable contador de tiempo 
    
    if(i32ParpadeoBateria>=500){                // Si ha pasado medio segundo
        i32ParpadeoBateria=0;                   // Reinico el valor del contador
        bParpadeoBateria=~bParpadeoBateria;     // Cambio el estado del bit para la representaci�n de la bater�a
    }
    
    if((i8CanalesActivados || bTratamientoSMPActivado || bTratamientoGalvanicaActivado || bMicrocorrientesEncendido) && bEmpiezaContadorTiempo){       // Si hay un tratamiento activo
        i32TiempoComunicaciones++;                                  // Incremento el tiempo de comunicaciones
        
        // El valor para 1 segundo deber�a de ser 1000, pero se ha puesto 993 para cuadrar el tiempo de ejecuci�n y tal y que realmente sea un segundo - Revisar
        if(var_tiempo>=993){                                        // Si ha pasado un segundo
            f_segundo=1;                                            // Indico que ha pasado un segundo
            var_tiempo=0;                                           // Reinicio la variable contador de tiempo
        }
        if(i32TiempoComunicaciones>(3*TIEMPO_REPRESENTACION)){      // Si ha pasado 2*TIEMPO_REPRESENTACION (~1.5s), hay un error en las comunicacioens
            i32TiempoComunicaciones=0;                              // Reinicio el contador
            bErrorComunicaciones=1;                                 // Indico error de comunicaciones
        }
    }
}

// IMPv: Timer 12 - Sistema anti-rebotes del codificador
#INT_TIMER12
void TIMER12_isr(void){

    cuenta++;                                               // Incrementa el contador de cuenta
    if (cuenta<=15){                                        // Si no ha incrementado hasta haber pasado 16 veces
        update_button(&button_history);                     // Actualizo el estado del codificador
        pulsacion=is_button_pressed(&button_history);       // Se comprueba si ha sido girado correctamente o han sido rebotes
        if (pulsacion==1){                                  // Si se ha detectado un giro
            if(bGirDerecha){                                // Si se ha girado a la derecha
                itecla=1;                                   // Indico que se ha girado a la derecha
            }else{                                          // Si se ha girado a la izquierda
                itecla=2;                                   // Indico que se ha girado a la izquierda
            }
            button_history=0xffff;                          // Reinicio el valor del estado del codificador
            disable_interrupts(INT_TIMER12);                // Deshabilito la interrupci�n del Timer 12
            clear_interrupt(INT_EXT1_H2L);                  // Limpio la interrupci�n generada por el codificador
            enable_interrupts(INT_EXT1_H2L);                // Habilito la interrupci�n del codificador
            bModoRulancha=1;
        }
    }else{                                                  // Si ha pasado de 16
        cuenta=0;                                           // Reinicio el valor de cuenta
        button_history=0xffff;                              // Reinicio el valor del estado del codificador
        disable_interrupts(INT_TIMER12);                    // Deshabilito la interrupci�n del Timer 12
        enable_interrupts(INT_EXT1_H2L);                    // Habilito la interrupci�n del codificador
    }
}

// Interrupci�n del pulsador RB0
#INT_EXT
void  EXT_isr(void){

    disable_interrupts(INT_EXT_H2L);        // Dshabilita la interrupci�n del bot�n
    clear_interrupt(INT_EXT_H2L);           // Limpia el flag de interrupci�n
    
    
    if(iMenuActual==121||iMenuActual==141||iMenuActual==181||iMenuActual==143||iMenuActual==183||i8CanalesActivados!=0){   // Si se ha presionado el bot�n de apagado durante el tratamiento
        if(iMenuActual==121 && i16TimeRaw[0]>i16Tgalv && !bTerapia){        // Si estamos en tratamiento dando galv�nica y el tiempo restante es mayor que el tiempo de galv�nica
                                                                            // No hagas nada
        }else{
            bPausaTratamiento=1;                        // Este bot�n pausa el tratamiento
            itecla=5;                                   // Asigan la tecla 5 para apagar el tratamiento
        }
    }else{                                              // Si se haya presionado la tecla otro momento
        while(!input_state(ON_OFF)){                    // Mientras el bot�n de encendido/apagado est� presionado
            if(!bSleepMode){                            // Si no se encuentra dormido
                controlSonido(1);                       // Enciendo el pito
            }
            delay_ms(1);                                // Delay de 1 ms
            i16TiempoApretado++;                        // Aumenta el ocntador
            
            if(i16TiempoApretado>1000){                 // Si el contador es superior a 1000, es decir, ha pasado 1 segundo (1000 incrementos x 1ms)
                if (bSleepMode){                        // Si se encontraba en modo sleep
                    bSleepMode=0;                       // Pongo el indicador de modo sleep a 0
                    iMenuActual=0;                      // Fijo el men� actual al men� principal
                }else{                                  // Si acaba de entrar al modo sleep
                    bSleepMode=1;                       // Pongo el indicador de modo sleep a 1
                }
                break;                                  // Sale del bucle while
            }else{                                      // Si ha sido presionado una vez
                if(!bSleepMode){                        // Si no estamos durmiendo
                    if(i8CanalesActivados==0){          // Si no hay ning�n tratamiento activo mientras configuro otro canal que no est� activado
                        iMenuActual=0;                  // Vuelvo al menu principal
                        giPos=Anterior_giPos[0];        // Recupero el valor de giPos guardado
                        Anterior_giPos[0]=0;            // Inicializo el anterior giPos
                        Anterior_giPos[1]=0;            // Inicializo el anterior giPos
                        bAlMenuPrincipal=1;             // Flag que indica la vuelta al men� principal
                    }
                }
            }
        }
        controlSonido(0);                               // Apago el pito
    }
    
    i16TiempoApretado=0;                // Reinicia el valor del contador de tiempo apretado
    clear_interrupt(INT_EXT_H2L);       // Limpia la interrupci�n del bot�n 
    enable_interrupts(INT_EXT_H2L);     // Habilita la interrupcion del bot�m
  
}

// Interrupci�n del codificador rotativo para saber la direcci�n de giro
#INT_EXT1
void  EXT1_isr(void){

   if(input_state(COD_B)){              // Si se encuentra activo el COD_B
      bGirDerecha=1;                    // Significa que estoy girando a la derecha
   }else{                               // En el caso de que no se encuentre activo
      bGirIzquierda=1;                  // Significa que estoy girando hacia la izquierda
   }
   cuenta=0;
   update_button(&button_history);      // Actualizo el estado del codificador
   disable_interrupts(INT_EXT1_H2L);    // Deshabilito la interrupci�n
   enable_interrupts(INT_TIMER12);      // Habilito el Timer 12 para el sistema antirebotes
}

// Interrupci�n al presionar alguna de las teclas del teclado
#INT_EXT3
void  EXT3_isr(void){
    // No hacer nada
}

// Interrupci�n del puerto RB
#INT_RB
void  RB_isr(void){

    enable_RB=0;                                                // Deshabilitamos interrupcion cambio RB
    aux=PORTB;                                                  // Leo el puerto B
    clear_RB=0;                                                 // Borramos flag de interrupcion

    if(!(aux&0x40)){                                            // Si NO(!) ha entrado a la interrupci�n debido a que hay una se�al en CTS
        if ((input_state(INT_ACEL)==1)&&(bSleepMode==0)){       // Si hay interrupcion de acelerometro y el dispositivo se encuentra activado
            baceleron=1;                                        // Flag que indica caida del dispositivo
        }else{                                                  // En el caso de que no sea activada la interrupci�n por el aceler�metro o que se encontrara el dispositivo dormido                                        
            if (input_state(V_CHG)==0){                         // Si existe interrupcion por cargador
                bcargador=1;                                    // Indico que se ha conectado el cargador
            }else{                                              // Sino, ha sido un ruido el que ha activado la interrupci�n                           
                enable_RB=1;                                    // Habilitamos interrupcion cambio RB
            }                                                 
        }
    }else{                                                      // Si ha entrado debido a que hay una se�al en CTS
        enable_RB=1;                                            // Pasa de la interrupci�n
    }
}

// Interrupci�n recepci�n datos puerto serie
#INT_RDA2
void serial_isr(){

    bAguantaEnvio=1;                                                        // Indica que debe de "aguantar" el envuio hasta que vea que se puede enviar sin colisiones   
    i8BufferEntrada[i8BufferIndex++]=i8DatoRecibido=fgetc(COM_PIC_UART);    // Capturo el dato recibido por el otro PIC                                 

    if(i8BufferIndex>1){                                // Si ya tenemos m�nimo dos datos en el buffer de entrada 
        if(i8DatoRecibido=='\r' || bCasiRecibido){      // Si se ha recibido el inicio de fin de trama o se habia recibido en el dato anterior
            bCasiRecibido=1;                            // Pongo el flag casi recibido activado
            if(i8DatoRecibido=='\n'){                   // Si se recibe el fin de fin de trama
                bCasiRecibido=0;                        // Reinicio flag casi recibido
                bDatoRecibido=1;                        // Indica que ya se ha recibido la trama de datos
                i8BufferIndex=0;                        // Inicializa el valor de �ndice del buffer
            }else if(i8DatoRecibido!='\r'){             // Si el dato que se ha recibido no es ni \r ni \n
                bCasiRecibido=0;                        // Reinicio flag casi recibido
            }
        }
    }
}


/************************************ Programa Principal *************************************/
void main() {
    
    // Declaraci�n de array de punteros ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    restart_wdt();                                          // Reinicio contador del WDT
    funcArr_menu[0] = &menu_0;                              // Pantalla inicial
    
    // GENERAL
    funcArr_menu[10] = &menu_10;                            // Configuracion general
    funcArr_menu[11] = &menu_11;                            // Iluminacion (Configuracion general)
    funcArr_menu[12] = &menu_12;                            // Se�al Acustica (Configuracion general)
    funcArr_menu[13] = &menu_13;                            // Versiones (Configuracion general)
    funcArr_menu[14] = &menu_14;                            // Constraste (Configuraci�n general) 
    funcArr_menu[15] = &menu_15;                            // Idioma (Configuraci�n general) 
    
    // GALV�NICA + MICROCORRIENTES
    funcArr_menu[20] = &menu_20;                            // Configuracion tratamiento galvanica
    funcArr_menu[21] = &menu_22;                            // Configuracion corriente electrica galvanica
    funcArr_menu[22] = &menu_42;                            // Configuracion tiempo galvanica
    funcArr_menu[23] = &menu_23;                            // Configuracion Tiempo de rampa galvanica
    funcArr_menu[24] = &menu_22;                            // Configuracion corriente microcorrientes micro
    funcArr_menu[25] = &menu_42;                            // Configuracion Tiempo activo microcorriente
    funcArr_menu[26] = &menu_29;                            // Configuracion de polaridad
    funcArr_menu[27] = &menu_27;                            // Configuracion ancho de pulso microcorrientes
    funcArr_menu[28] = &menu_28;                            // Configuracion frecuencia microcorrientes  
    
    // ELECTROESTIMULACI�N + POINTER
    funcArr_menu[40] = &menu_40;                            // Configuracion electroestimulacion
    funcArr_menu[41] = &menu_41;                            // Numero de canales
    funcArr_menu[42] = &menu_33;                            // Simetria canales
    funcArr_menu[43] = &menu_42;                            // Configuracion tiempo activo
    funcArr_menu[44] = &menu_42;                            // Configuracion tiempo descanso
    funcArr_menu[45] = &menu_23;                            // Configuracion tiempo rampa
    funcArr_menu[46] = &menu_43;                            // Configuracion n�mero de repeticiones
    funcArr_menu[47] = &menu_22;                            // Configuracion de corriente de tratamiente
    funcArr_menu[48] = &menu_28;                            // Configuracion de frecuencia
    funcArr_menu[49] = &menu_29;                            // Configuracion de polaridad
    funcArr_menu[50] = &menu_33;                            // Configuracion de simetria 
    funcArr_menu[51] = &menu_27;                            // Configuracion del PW +
    funcArr_menu[52] = &menu_27;                            // Configuracion del PW -
    
    // TESTS DEL DISPOSITIVO
    funcArr_menu[60] = &menu_60;                            // Test del dispositivo 
    funcArr_menu[61] = &menu_61;                            // Test del bicolor 
    funcArr_menu[62] = &menu_12;                            // Test del sonoro
    funcArr_menu[63] = &menu_63;                            // Test del pulsadores   
    funcArr_menu[64] = &menu_11;                            // Test del Pantalla  
    funcArr_menu[65] = &menu_65;                            // Test del acelerometro    
    funcArr_menu[66] = &menu_66;                            // Test del alimentacion ext
    funcArr_menu[67] = &menu_67;                            // Test del status cargador
    funcArr_menu[68] = &menu_68;                            // Test del DC/DC 12V   
    funcArr_menu[69] = &menu_69;                            // Test del DC/DC 48V
    funcArr_menu[70] = &menu_70;                            // Test reles
    funcArr_menu[71] = &menu_71;                            // Test BQ34Z100-G1   
    funcArr_menu[72] = &menu_72;                            // Test COMUNICACION ENTRE PIC�S
    funcArr_menu[73] = &menu_73;                            // Test CHA   
    funcArr_menu[74] = &menu_74;                            // Test CHB   
    funcArr_menu[75] = &menu_75;                            // Test CHC   
    
    // SISTEMA MULTIPULSOS
    funcArr_menu[80] = &menu_80;                            // Sistema multipulsos SMP
    funcArr_menu[81] = &menu_42;                            // Tiempo activo SMP
    funcArr_menu[82] = &menu_42;                            // Tiempo desfase SMP
    funcArr_menu[83] = &menu_28;                            // Frecuencia SMP
    funcArr_menu[84] = &menu_27;                            // Ancho de pulso SMP
    
    // TRATAMIENTO GALV�NICA
    funcArr_menu[120] = &menu_120;                          // Pantalla de inicio de tratamiento galvanica
    funcArr_menu[121] = &menu_120;                          // Pantalla de tratamiento galvanica
    funcArr_menu[123] = &menu_120;                          // Pantalla de eror de electrodo tratamiento galvanica
    
    // TRATAMIENTO ELECTROESTIMULACI�N
    funcArr_menu[140] = &menu_140;                           // Pantalla de inicio de electroestimulacion
    funcArr_menu[141] = &menu_140;                           // Pantalla de electroestimulaci�n activa
    funcArr_menu[142] = &menu_140;                           // Pantalla de electroestimulaci�n reposo
    funcArr_menu[143] = &menu_140;                           // Pantalla de Error de electrodo
    
    // TRATAMIENTO SMP
    funcArr_menu[180] = &menu_180;                           // Pantalla inicio SMP
    funcArr_menu[181] = &menu_180;                           // Pantalla de SMP activa
    funcArr_menu[183] = &menu_180;                           // Pantalla de Error de electrodo
    
    // OTRO MEN�S
    funcArr_menu[200] = &menu_200;                           // Indicaci�n de autoapagado  
    funcArr_menu[201] = &menu_201;                           // Apagado del equipo
    funcArr_menu[202] = &menu_202;                           // Error de transistores
    funcArr_menu[203] = &menu_203;                           // Error de sistema de medida
    funcArr_menu[204] = &menu_204;                           // Carga del equipo     
    funcArr_menu[205] = &menu_205;                           // Error de comunicaciones     
    
    // Asignaci�n de puertos anal�gicos +++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    ANCON0=0x00;        // ANCON0: Anal�gicas -> X    Digitales -> AN0,AN1,AN2,AN3,AN4,AN5,AN6,AN7
    ANCON1=0x00;        // ANCON1: Anal�gicas -> X    Digitales -> AN8,AN9,AN10,AN11,AN12,AN14,AN14,AN15 
    ANCON2=0x00;        // ANCON2: Anal�gicas -> X    Digitales -> AN16,AN17,AN18,AN19,AN20,AN21,AN22,AN23
    
    // Habilitaci�n interrupci�n del pulsador RB0
    aux=PORTB;                                          // Leo el puerto B para 
    clear_RB=0;                                         // Limpio el flag de la interrupci�n del puerto B             
    clear_interrupt(INT_EXT_H2L);                       // Limpio el flag de la interrupci�n de RB0
    enable_interrupts(INT_EXT_H2L);                     // Habilitamos interrupcion EXT H-->L
    enable_RB=0;                                        // Habilito las interrpciones del puerto B
    enable_interrupts(GLOBAL);                          // Habilitamos interrupciones
    
    // Puesta a nivel bajo de todos los pines ++++++++++++++++++++++++++++++++++++++++++++++++++++++
    output_a(0x00);                     // Pongo a nivel bajo el puerto A
    output_b(0x00);                     // Pongo a nivel bajo el puerto B
    output_c(0x00);                     // Pongo a nivel bajo el puerto C
    output_d(0x00);                     // Pongo a nivel bajo el puerto D
    output_e(0x00);                     // Pongo a nivel bajo el puerto E
    output_f(0x00);                     // Pongo a nivel bajo el puerto F
    output_g(0x00);                     // Pongo a nivel bajo el puerto G
    
    control_DC(0,EN_5);                 // Apago alimentaci�n 5V
    control_DC(0,EN_5_sw);              // Apago alimentaci�n 5V de perif�ricos
    control_DC(0,EN_12);                // Apago alimentaci�n 12 V
    
    I2C_1_ON=0;                         // Apagado del I2C       
    DEBUG_UART_ON=0;                    // Apagado UART depuraci�n
    COM_PIC_UART_ON=0;                  // Apagado UART comunicaci�n
    bSleepMode=1;                       // Indico que va a dormir
    
dormir:                                 // GOTO SLEEP
    
    output_high(RST_ORCO);              // Reseteo y mantengo nivel alto en el PIC ORCO (RESET ACTIVO A NIVEL ALTO!)
    sleep();                            // Entra en modo de bajo consumo
    
    if(bSleepMode&&(!bCargador)){       // Si detecta que el equipo debe de estar en sleep y se ha despertado por cualquier cosa...
        goto dormir;                    // Se envia a dormir
    }
    
    // Despierta del modo sleep ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    restart_wdt();                      // Reinicio contador WDT
    enable_RB=0;                        // Deshabilita las interrupciones del puerto RB
    
    TRISC|=0xD8;                
    TRISC&=~0x21;                       // Configuraci�n TRISC para poder hacer uso de los pines - Si no se hace esta configuraci�n, da problemas con el FIXED_IO/FAST/STANDARD_IO

    TRISG|=0x02;                        // Configuraci�n TRISG
    
    DEBUG_UART_ON=1;                    // Apagado UART Debug
    COM_PIC_UART_ON=1;                  // Encendido UART comunicaci�n
    
    MEMCON=0xFF;                        // Deshabilitamos el bus de memoria externo
   
    control_DC(1,EN_5);                 // Habilito alimentaci�n de 5 V
    delay_ms(500);                      // Delay de estabilizaci�n
    
    // Setup Timer 2    - Timer resto de moduladores 250 us overflow, 250 us interrupt
    setup_timer_2(T2_DIV_BY_16,249,1);   
    
    // Configuracion pito
    setup_ccp7(CCP_PWM|CCP_SHUTDOWN_AC_L|CCP_SHUTDOWN_BD_L);        // Modulador para se�al acustica
    set_pwm7_duty((int16)((i16nivel_son*4.5)));                     // Cargamos duty de trabajo [0..500]
    
    for(int8 i8Init=0; i8Init<3; i8Init++){         // Bucle que parpadea un led al inicio para indicar que se ha encendido el equipo
        output_high(LED_CHG_V);
        delay_ms(125);
        output_low(LED_CHG_V);
        delay_ms(125);
    }
    
    control_DC(1,EN_5_sw);              // Habilitaci�n alimentaci�n de  5V sw
    delay_ms(500);                      // Delay de estabilizacion
    
    control_DC(1,EN_12);                // Habilitaci�n de la alimentacion de 12 V
    delay_ms(500);                      // Delay de estabilizaci�n 
    
    restart_wdt();                      // Reinicio contador WDT
    
    I2C_1_ON=1;                         // Encendido I2C
    i2c_init(true);                     // Habilitci�n I2C
    SPI_2_ON=1;                         // Habilitaci�n SPI
    
    // Configuraci�n del expansor (Address==0x00)
    conf_PCA955X(0x00,0x00,0x00,PCA9555);       // Configuraci�n de los reles y LEDs de terapia como salida
    write_PCA955X(0x00,0x00,0x00,PCA9555);      // Desactivamos todos los reles y los LEDs de terapia
    
    // Configuraci�n de los timers
    // Setup Timer 10  - Base de tiempos general de 1ms
    setup_timer_10(T10_DIV_BY_4,250,16);       
    TIMER10_ON=0;
    
    // Setup Timer 12 - Base de tiempos de la rulancha de 256 us
    setup_timer_12(T12_DIV_BY_16,16,16);
   
    // Configuraci�n de los PWM
    setup_ccp8(CCP_PWM);                                        // Modulador iluminacion pantalla
    
    setup_comparator(NC_NC_NC_NC);
    set_pwm7_duty((int16)0);                                    // Pone el valor de se�al ac�stica a 0
    set_pwm8_duty((int16)i8nivel_ilum*10);                      // Cargamos duty de trabajo [0..1000] 
    
    output_low(RST_ORCO);                                       // Pongo a nivel bajo el reset del ORCO para activar ese PIC
    
    restart_wdt();                                              // Reinicio contador WDT
    
    // Inicializaci�n de la pantalla
    ST7529_init();                                              // Inicializaci�n del controlador de pantalla
    ControlSonido(0);                                           // Apago pito

    // Pongo imagen inicial
    ST7529_putImageGS(imagen,9,25,iImagRow,iImagCol);           // Pongo logo EPTE en pantalla              
    
    // Inicializaci�n rel�s
    restart_wdt();                                              // Reinicio contador WDT
    
    initReles();                                                // Inicializa todos los rel�s
    
    restart_wdt();                                              // Reinicio contador WDT
    
    // Inicializaci�n del aceler�metro
    if (!begin_MMA8451()){                                      // Si no se inicializa correctamente
        ST7529_printf("Acelerometro NOK",0,50,M_,NORMAL);       // DEBUG  
    }
    
    enable_interrupts(INT_RDA2);                                // Habilito interrupciones del puerto serie
    enable_interrupts(GLOBAL);                                  // Habilito interrupciones globales
        
    setRange_MMA8451(MMA8451_RANGE_8_G);                        // Configuro rango del aceler�metro
    
    restart_wdt();                                              // Reinicio contador WDT
    
    delay_ms(2000);                                             // Delay de muestra por pantalla
    
    restart_wdt();                                              // Reinicio contador WDT
    
    ControlSonido(0);                                           // Apago el pito
    
    ST7529_clear();                                             // Limpio la pantalla                                                  
   
cargador:                               // GOTO CARGADOR
    // Rutina del cargador
    disable_interrupts(INT_EXT_H2L);                        // Deshabilitamos la interrupci�n del pulsador on/off
    disable_interrupts(GLOBAL);                             // Deshabilito todas las
    while (input_state(V_CHG)==0){                          // Mientras el cargador est� conectado
        restart_wdt();                                      // Reinicio contador WDT
        bcargador=1;                                        // Indica que el cargador se encuentra conectado
        output_high(LED_CHG_R);                             // Enchufo el LED de carga
        iMenuActual=204;                                    // Selecciono el men� de carga
        result=(*funcArr_menu[iMenuActual])();              // Me voy al men� de carga   
    }
    
    readRegister8_MMA8451(MMA8451_REG_MT_SRC);              // Borrado interrupcion del acelerometro
    aux=PORTB;                                              // Leo el puerto B
    output_low(LED_CHG_R);                                  // Apago el LED de cargaa
    clear_RB=0;                                             // Limpiamos flag interrupcion de acelerometro                                          
    clear_interrupt(INT_EXT_H2L);                           // Limpio interrupci�n del pulsador On/Off
    enable_interrupts(INT_EXT_H2L);                         // Habilito interrupci�n del pulsador On/Off

    iMenuAnterior=250;                                      // Asigno un valor aleatorio como inicializacion al men� anterior
    bcargador=0;                                            // Inidica que el cargador se encuentra desconectado
    iMenuActual=0;                                          // Asigno valor menu principal al men� actual
   
    // Habilitaci�n de interrupciones
    enable_interrupts(INT_EXT1_H2L);            // Habilitamos interrupcion del encoder incremental
    enable_interrupts(INT_EXT3_H2L);            // Habilitamos interrupcion del expasor de puertos correspondiente a pulsadores y mas
    clear_interrupt(INT_TIMER10);               // Limpio interrupci�n Timer 10
    enable_interrupts(INT_TIMER10);             // Habilitamos interrupcion del timer 10. Base de tiempos
    enable_interrupts(INT_RDA2);                // Habilito interrupci�n puerto serie
    enable_interrupts(INT_RB);                  // Habilito interrupci�n puerto RB
    enable_interrupts(GLOBAL);                  // Habilito interrupciones
    
    aux=PORTB;                          // Leo el puerto B - Repetido??
    clear_RB=0;                         // Limpiamos flag interrupcion de acelerometro - Repetido??
    var_tiempo=0;                       // Inicializamos contador de tiempo
    enable_RB=1;                        // Habilitamos interrupcion de acelerometro         
    restart_wdt();                      // Reinicio contador WDT
    TIMER10_ON=1;                       // Habilitamos timer 10 (base de tiempos)
    f_segundo=0;                        // Inicializamos flag de segundos
    
    // Compobaci�n de la comunicaci�n con orco
    bComprobacionInicial=1;                     // Indico que se est� realizando la comunicaci�n inicial
    envioConfiguracion(MODO_CHECK_ALIVE);       // Envio paquete a Orco
    
    if(bErrorComunicaciones){                   // Si hay un error en las comunicaciones iniciales
        iMenuActual=205;                        // indico men� de error
        result=(*funcArr_menu[iMenuActual])();  // Voy al men� de error
        funcion_dormir();                       // Preparo para dormir
        bErrorComunicaciones=0;                 // Inicializo valor de error de comunicaciones
        goto dormir;                            // Voy a dormir
    }
    
    bComprobacionInicial=0;                     // Inicializo flag de comprobaci�n inicial 
    
    // ------------------------------------------------------------------------------------------
    // --------------------------------------- BUCLE PRINCIPAL ----------------------------------
    
    while(TRUE){                                    // Bucle de programa principal
    
        // ---------------------------------- ERROR EN COMUNICACIONES  -----------------------------
        
        if(bErrorComunicaciones){                   // Si ha ocurrido un error en las comunicaciones
            bErrorComunicaciones=0;                 // Inicializo flag de error
            iMenuActual=205;                        // Indico men� de error
            result=(*funcArr_menu[iMenuActual])();  // Me voy al men�   
            iMenuActual=0;                          // Voy al men� principal
            giPos=0;                                // Inicializo variable posici�n
            result=(*funcArr_menu[iMenuActual])();  // Me voy al men� 
        }
        
        // --------------------------------------- RECEPCION ORCO ----------------------------------
        
        if(bDatoRecibido){                                                                              // Si he recibido alg�n dato de Orco
            bDatoRecibido=0;                                                                            // Pongo el flag a 0
            i32TiempoComunicaciones=0;                                                                  // Inicializo el contador de timeout de comunicaciones
            if(RETURN_OK==lecturaPaquete()){                                                            // Leo el paquete  recibido
                switch(i8TipoPaquete){                                                                  // Dependiendo del paquete recibido...
                    case MODO_ERRORES:                                                                  // Si se trata de un paquete identificativo de errores
                        if(i16ErroresOcurridos!=0){                                                     // Si ha ocurrido alg�n error...
                            if(i16ErroresOcurridos & ERROR_ELECTRODO_CHA){                              // Si se trata de un error de electrodo en el CHA
                                bErrorElectrodo[CHA_C]=1;                                               // Activo flag de error de electrodo CHA/SMP
                                
                                control_led(0,verde,led_CHA);                                           // Apago LED VErde
                                control_led(1,rojo,led_CHA);                                            // Apago LED Rojo
                                
                                if(TRATAMIENTO_ELECTRO == i8TratamientoSeleccionado){                   // Si estamos en tratamiento de electroestimulaci�n
                                    iMenuActual=143;                                                    // Cambio a menu de error de electrodo 
                                    if(i8TrElec[i8ConfigCanal]>0){                                      // Si hay rampa configurada
                                        bValorAlcanzado=0;                                              // Inicializo el flag de valor de corriente final alcanzado 
                                    }
                                }
                            }else{                                                                      // Si no hay error en el CHA
                                bErrorElectrodo[CHA_C]=0;                                               // Pongo flga error de electrodo CHA/SMP a 0
                            }
                            
                            if(i16ErroresOcurridos & ERROR_ELECTRODO_CHB){                              // Si hay error de  elctrodo en el CHB
                                bErrorElectrodo[CHB_C]=1;                                               // Activo flag de erorr de electrodo CHB/GALV
                                
                                if(TRATAMIENTO_ELECTRO == i8TratamientoSeleccionado){                   // Si estamos en tratamiento de elctroestimulacion
                                                                       
                                    control_led(0,verde,led_CHB);                                       // Apago LED verde CHB
                                    control_led(1,rojo,led_CHB);                                        // Enciendo LED rojo CHB

                                    iMenuActual=143;                                                    // Selecciono el men� de error de electrodo
                                    if(i8TrElec[i8ConfigCanal]>0){                                                     // Si hay rampa configurada
                                        bValorAlcanzado=0;                                              // Inicializo el flag de valor de corriente final alcanzado 
                                    }
                                }else if(TRATAMIENTO_GALVANICA == i8TratamientoSeleccionado){           // Si estamos en tratamiento de galv�nica
                                    iMenuActual=123;                                                    // Selecciono el men� de error de electrodo                                       
                                    if(i8Trampagalv>0){                                                 // Si hay rampa configurada                                 
                                        bValorAlcanzado=0;                                              // Inicializo el flag de valor de corriente final alcanzado 
                                    }
                                    
                                    control_led(0,verde,led_GALV);                                      // Apago LED verde GALV
                                    control_led(1,rojo,led_GALV);                                       // Enciendo LED rojo GALV
                                }else if(TRATAMIENTO_MICROCORRIENTES == i8TratamientoSeleccionado){
                                    iMenuActual=123;                                                    // Selecciono el men� de error de electrodo                                       
                                    if(i8Trampamicro>0){                                                 // Si hay rampa configurada                                 
                                        bValorAlcanzado=0;                                              // Inicializo el flag de valor de corriente final alcanzado 
                                    }
                                    
                                    control_led(0,verde,led_GALV);                                      // Apago LED verde GALV
                                    control_led(1,rojo,led_GALV);                                       // Enciendo LED rojo GALV
                                }
                            }else{                                                                      // Si no hay error de electrodo
                                bErrorElectrodo[CHB_C]=0;                                               // Limpio el flag de error de electrodo CHB/GALV
                            }
                                                     
                            if(i16ErroresOcurridos & ERROR_ELECTRODO_CHC){                              // Si hay error de electrodo en el CHC
                                bErrorElectrodo[CHC_C]=1;                                               // Activo flag de error de lectrodo CHC
                                
                                control_led(0,verde,led_CHC);                                           // Apago LED verde CHC
                                control_led(1,rojo,led_CHC);                                            // Enciendo LED rojo CHC
                                if(TRATAMIENTO_ELECTRO == i8TratamientoSeleccionado){
                                    
                                    iMenuActual=143;                                                    // Selecciono men� de error de electrodo
                                    if(i8TrElec[i8ConfigCanal]>0){                                      // Si hay rampa configurada                                 
                                        bValorAlcanzado=0;                                              // Inicializo el flag de valor de corriente final alcanzado 
                                    }
                                
                                }else if(TRATAMIENTO_SMP == i8TratamientoSeleccionado){                 // Si estamos en tratamiento del sistema multipulsos
                                    iMenuActual=183;                                                    // Cambio a men� de error de elctrodo
                                }
                            }else{                                                                      // Si no hay error de electrodo
                                bErrorElectrodo[CHC_C]=0;                                               // Limpio el flag de error de electrodo del CHC
                            }

                            if(i16ErroresOcurridos & ERROR_SIMETRIA_CHA){                               // TODO - Error de simetr�a CHA
                            
                            }
                            
                            if(i16ErroresOcurridos & ERROR_SIMETRIA_CHB){                               // TODO - Error de simetr�a CHB
                            
                            }
                            
                            if(i16ErroresOcurridos & ERROR_SIMETRIA_CHC){                               // TODO - Error de simetr�a CHC
                            
                            }
                            
                            if(i16ErroresOcurridos & ERROR_CALIBRADO_CHA){                              // TODO - Error de calibrado CHA
                            
                            }
                            
                            if(i16ErroresOcurridos & ERROR_CALIBRADO_CHB){                              // TODO - Error de calibrado CHB
                            
                            }
                            
                            if(i16ErroresOcurridos & ERROR_CALIBRADO_CHC){                              // TODO - Error de calibrado CHC
                            
                            }
          
                            if(i16ErroresOcurridos & ERROR_TRANSISTORES_CHA){                           // TODO - Error de transistores CHA
                            
                            }
                            
                            if(i16ErroresOcurridos & ERROR_TRANSISTORES_CHB){                           // TODO - Error de transistores CHB
                            
                            }
                            
                            if(i16ErroresOcurridos & ERROR_TRANSISTORES_CHC){                           // TODO - Error de transistores CHC
                            
                            }

                        }else{                                                                          // Si ya no hay ning�n error...
                            if(TRATAMIENTO_ELECTRO==i8TratamientoSeleccionado){                         // Si el tratamiento seleccionado es el de electroestimulaci�n
                                if(i8CanalesActivados){                                                 // Si el tratamiento se encuentra activado
                                    iMenuActual=141;                                                    // Selecciono el men� de tartaiento activo
                                    
                                    bErrorElectrodo[CHA_C]=0;                                           // Pongo a cero el valor de error de electrodo 
                                    bErrorElectrodo[CHB_C]=0;
                                    bErrorElectrodo[CHC_C]=0;
                                    
                                    
                                    switch(i8CanalesActivados){                                         // Dependiendo del modo de canales elegido...
                                        case CANALES_A:                                                 // Canal A
                                            control_led(0,rojo,led_CHA);                                // Apago LED rojo
                                            control_led(1,verde,led_CHA);                               // Enciendo LED verde
                                            break;
                                        case CANALES_B:                                                 // Canal B
                                            control_led(0,rojo,led_CHB);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHB);                               // Enciendo LED verde
                                            break;
                                        case CANALES_C:                                                 // Canal C
                                            control_led(0,rojo,led_CHC);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHC);                               // Enciendo LED verde
                                            break;
                                        case CANALES_AB:                                                // Canal A y B
                                            control_led(0,rojo,led_CHA);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHA);                               // Enciendo LED verde
                                    
                                            control_led(0,rojo,led_CHB);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHB);                               // Enciendo LED verde
                                            break;
                                        case CANALES_BC:                                                // Canal B y C
                                            control_led(0,rojo,led_CHB);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHB);                               // Enciendo LED verde
                                    
                                            control_led(0,rojo,led_CHC);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHC);                               // Enciendo LED verde
                                            break;
                                        case CANALES_AC:                                                // Canal A y C
                                            control_led(0,rojo,led_CHA);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHA);                               // Enciendo LED verde
                                        
                                            control_led(0,rojo,led_CHC);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHC);                               // Enciendo LED verde
                                            break;
                                        case CANALES_ABC:                                               // Canal A, B y C
                                            control_led(0,rojo,led_CHA);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHA);                               // Enciendo LED verde
                                    
                                            control_led(0,rojo,led_CHB);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHB);                               // Enciendo LED verde
                                            
                                            control_led(0,rojo,led_CHC);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHC);                               // Enciendo LED verde
                                            break;
                                        case CANALES_BP:                                                // Canal B y Pointer
                                            control_led(0,rojo,led_CHB);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHB);                               // Enciendo LED verde
                                            break;
                                        case CANALES_CP:                                                // Canal C y Pointer
                                            control_led(0,rojo,led_CHC);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHC);                               // Enciendo LED verde
                                            break;
                                        case CANALES_BCP:                                               // Canal B, C y Pointer
                                            control_led(0,rojo,led_CHB);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHB);                               // Enciendo LED verde
                                            
                                            control_led(0,rojo,led_CHC);                                // Apago LED rojo    
                                            control_led(1,verde,led_CHC);                               // Enciendo LED verde
                                            break;
                                    }   // Cierre switch case canales LEDs
                                }   // Cierreif tratamiento activado
                            }else if(TRATAMIENTO_GALVANICA == i8TratamientoSeleccionado){               // Si se encuentra en tratamiento de galv�mica
                                iMenuActual=121;                                                        // Selecciono el men� de tartamiento activo
                                
                                bErrorElectrodo[CHB_C]=0;                                               // Limpio el flag de error de electrodo
                                
                                control_led(0,rojo,led_GALV);                                           // Apago LED rojo GALV     
                                control_led(1,verde,led_GALV);                                          // Enciendo LED verde GALV
                            }else if(TRATAMIENTO_MICROCORRIENTES == i8TratamientoSeleccionado){               // Si se encuentra en tratamiento de micrococrrientes
                                iMenuActual=121;                                                        // Selecciono el men� de tartamiento activo
                                
                                bErrorElectrodo[CHB_C]=0;                                               // Limpio el flag de error de electrodo
                                
                                control_led(0,rojo,led_GALV);                                           // Apago LED rojo GALV     
                                control_led(1,verde,led_GALV);                                          // Enciendo LED verde GALV
                            }else if(TRATAMIENTO_SMP == i8TratamientoSeleccionado){                     // Si se encuentra en tratamiento de SMP
                                iMenuActual=181;                                                        // Selecciono el men� de tartamiento activo
                                                                                                                                                   
                                bErrorElectrodo[CHC_C]=0;                                               // Limpio el flag de error de electrodo    
                                                                                                                                                   
                                control_led(0,rojo,led_CHC);                                            // Apago LED rojo CHA/SMP                     
                                control_led(1,verde,led_CHC);                                           // Enciendo LED verde CHA/SMP                 
                                
                            }   // Cierre if-else errores ocurridos
                        }
                        break;
                        
                    case MODO_MEDIDAS_OBTENIDAS:                                                        // Si se ha recibido un paquete del tipo de medidas obtenidas
                        f_avisos();                                                                     // Selecciono la funci�n de muestra de avisos por pantalla (MAX/CC...)
                        break;
                    case MODO_CONTROL_TIEMPO:                                                           // Si se ha recibido un paquete de control de tiempo
                        
                        if(!bEmpiezaContadorTiempo){                                                    // Si no ha empezado el momento de contar el tiempo
                            var_tiempo=0;                                                               // Inicializo el valor del contador
                        }
                        bValorAlcanzado=structControlTiempo.sbValorAlcanzado;                           // Copia el valor de la struct a la varibale global del programa
                        bEmpiezaContadorTiempo=structControlTiempo.sbEmpiezaContadorTiempo;             // Copia el valor de la struct a la varibale global del programa
                        
                        if(bValorAlcanzado){                                                            // Si ha alcanzado el valor de corriente de tratamiento
                            pitidoCorto();                                                              // Realiza un pitido corto
                        }
                        
                        structControlTiempo.sbValorAlcanzado=0;                                         // Inicializa el valor de la struct
                        structControlTiempo.sbEmpiezaContadorTiempo=0;
                        bPrimeraMedida=1;                                                               // Indica que se trata de la primera medida
                        break;
                    case MODO_CONEXION_POINTER:                                                         // Si se ha conectado o desconectado el pointer
                        if(bPointerConectado){                                                          // Si se ha conectado
                            pitidoPointerConectado();                                                   // Realiza un pitido corto
                        }else{                                                                          // Si se ha desconectado
                            pitidoPointerDesconectado();                                                // Realiza un pitido largo
                        }
                        break;
                    case MODO_CHECK_INICIAL:                                                            // Si se ha recibido un paquete de control de tiempo
                        // TODO: Medidas iniciales, comprobaci�n
                        break;
                }   // Cierre switch tipo paquete
            }   // Cierre if lectura paquete
        }   // Cierre if dato recibido

        // --------------------------------------- NIVEL BATERIA ----------------------------------- 
        
        i8Bat=nivelBateria();           // Obtiene el nivel de bater�a restante
        i8punt_bat=1+(i8Bat/20);        // Obtiene el nivel de bateria para representaci�n en pantalla
        
        if(i8Bat<10){                   // Si la bateria es inferior al 10%
            bBateriaBaja=1;             // Indico bateria baja
        }else{                          // Si es igual o superior al 10%
            bBateriaBaja=0;             // Indico bateria normal
        }
        
        if(i8punt_bat>=6){              // Si llega al 100%
            i8punt_bat=5;               // Ponemos el m�ximo valor de representaci�n
        } 
        
        // --------------------------------------- BATER�A BAJA ----------------------------------- 
        /*
        if (i8Bat<=2){                  // Si el nivel de bateria es igual o inferior al 2 %
            ST7529_clear();                                         // Limpio la pantalla
            ST7529_printf("NIVEL BAJO DE BATERIA",8,30,L_,NORMAL);  // Muestro un mensaje de aviso al usuario
            ST7529_printf("INFERIOR AL 2%",22,55,L_,NORMAL);         
            ST7529_printf("CARGUE EL DISPOSITIVO",12,80,L_,NORMAL);
            
            ControlSonido(1);                                       // Enciendo pito
            delay_ms (5000);                                        // Delay pito
            ControlSonido(0);                                       // Apago pito
            
            funcion_dormir();                                       // Preparo el equipo para dormir
            
            goto dormir;                                            // Envio el equipo a dormir
        }
        */
        // --------------------------------------- CARGADOR ----------------------------------- 
        
        if (input_state(V_CHG)==0){                         // Si se ha conectado el cargador
        
            output_high(LED_CHG_R);                         // Enciendo el LED de carga  

            ControlSonido(1);                               // Enciendo pito
            ST7529_clear();
            
            ST7529_printf("ALIMENTACION CONECTADA",8,35,M_,NORMAL);     // Texto por pantalla  
              
            if(iMenuActual==141 || iMenuActual==142 || iMenuActual==181 || iMenuActual==121 || i8CanalesActivados!=0){          // Si se encuentra en tratamiento
            
                ST7529_printf("APAGANDO TRATAMIENTOS",8,65,M_,NORMAL);              // Indico mensaje por pantalla
                ST7529_printf("     ACTIVOS...",8,80,M_,NORMAL);
                
                iMenuAnterior=250;                          // Inicializo men� antoerior
                
                initReles();                                // Inicializa rel�s
                
                if(i8CanalesActivados){                     // Si hay alg�n canal activado de electroestimulaci�n
                
                    i8CanalesActivados=CANALES_ABC;         // Indico que estabn activados todos los canales para que los apague todos, esten o no
                    i8ReposoActivados=0;                    // Aseguro que no hay nada de reposo activado para asegurar que se apagan los canales completamente
                    
                    envioTratamiento(MODO_START_STOP,COMANDO_STOP);      // Envio paquete de apagado de canales
        
                    apagadoCanales();                       // Apaga los canales de electroestimulaci�n
                    
                    i8CanalesActivados=0;                   // Reinicio el valor de canales activados
                    
                }else if(iMenuActual>120&&iMenuActual<140){             // Si est� galv�nica/galv+micro activado
        
                    envioTratamiento(MODO_START_STOP,COMANDO_STOP);     // Envio comando STOP
        
                    apagadoMicrocorrientes();                           // Apagado de los canales
                    
                    bTratamientoGalvanicaActivado=0;                    // Inicializa variable de tratamiento
                    
                }else if(iMenuActual>180){                              // Si est� el SMP activado

                    envioTratamiento(MODO_START_STOP,COMANDO_STOP);     // Envio comando STOP
        
                    apagadoSMP();                                       // Apagado de los canales            
                    bTratamientoSMPActivado=0;                          // Inicializa variable de tratamiento
                }
            }
            delay_ms(2000);                                 // Delay muestra por pantalla
            iMenuActual=204;                                // Lo envio al men� de carga
            result=(*funcArr_menu[iMenuActual])();          // Actualizo la pantalla  de men�
            ControlSonido(0);                               // Apago el pito
            
            goto cargador;                                  // Envio el equipo al� bucle  de carga
        }
        
        // --------------------------------------- MODO SLEEP ----------------------------------- 
        
        if(bSleepMode){                                     // Si se encuentra el modo sleep activado
            funcion_dormir();                               // Preparo el equipo para dormir
            goto dormir;                                    // Envio el equipo a dormir
        }
        
        // --------------------------------------- ACELER�METRO Y ALIMENTACI�N ----------------------------------- 
        
        if(baceleron || (bPrimeraMedida && (i8CanalesActivados||(iMenuActual>120&&iMenuActual<140)||iMenuActual>180) && !(isPower12OK()&&isPower30OK()))){      // Si se ha activado el flag de que ha ocurrido una aceleraci�n
            iMenuAnterior=250;                          // Inicializo men� antoerior
            
            if(i8CanalesActivados){                     // Si hay alg�n canal activado de electroestimulaci�n
            
                i8CanalesActivados=CANALES_ABC;         // Indico que estabn activados todos los canales para que los apague todos, esten o no
                i8ReposoActivados=0;                    // Aseguro que no hay nada de reposo activado para asegurar que se apagan los canales completamente
                
                // Envio paquete de apagado de canales
                envioTratamiento(MODO_START_STOP,COMANDO_START_PAUSA); 

                apagadoCanales();                       // Apaga los canales de electroestimulaci�n
                
                i8CanalesActivados=0;                   // Reinicio el valor de canales activados a 0
                
                if(iMenuActual>=140){                   // Si el men� en el que se encuentra es el 140, 141, 142 o 143
                    iMenuActual=140;                    // Asigno el men� 140
                }
            }else if(iMenuActual>120&&iMenuActual<140){             // Si est� galv�nica/galv+micro activado

                i16Tgalv=calc_Tgalv(i32Cgalv,i16Igalv);             // Inicializo variable tiempo 
                i16TimeRaw[0]=i16Tgalv+i8TrampaGalv;                // Inicializo variable tiempo raw
                i32CargaGalvanicaRestante=i32Cgalv+i16CRampaGalv;   // Inicializo variable carga

                envioTratamiento(MODO_START_STOP,COMANDO_STOP);     // Envio comando STOP

                apagadoMicrocorrientes();                           // Apagado de los canales
                bTratamientoGalvanicaActivado=0;                    // Inicializa variable de tratamiento
                iMenuActual=120;                                    // Voy al men� 120

            }else if(iMenuActual>180){                              // Si est� el SMP activado
            
                i16TimeRaw[0]=i16TacSMP;                            // Inicializo variable tiempo activo

                envioTratamiento(MODO_START_STOP,COMANDO_STOP);     // Envio comando STOP

                apagadoSMP();                                       // Apagado de los canales            
                bTratamientoSMPActivado=0;                          // Inicializa variable de tratamiento
                iMenuActual=180;                                    // Vuelvo al men� 180 (Paro el tratamiento)
            }
            
            for (int8 i8Leds=0;i8Leds<TOTAL_LEDS;i8Leds++){         // Recorro todoso los LEDs
                control_led(1,rojo,i8Leds);                         // Enciendo LED rojo
            }   
            
            initReles();                                            // Inicializo los rel�s
            ST7529_clear();                                         // Limpio pantalla
            
            if(baceleron){              // Si el error es por un aceler�n
                ST7529_printf("     MOVIMIENTO BRUSCO    ",0,50,L_,NORMAL);     // Muestro error de caida libre
                ST7529_printf("         DETECTADO",0,70,L_,NORMAL);         
                ControlSonido(1);                                       // Enciendo el pito
                delay_ms(5000);                                         // Delay pito
                ControlSonido(0);                                       // Apago el pito
                
                // Apagado leds de tratamiento
                for (int8 i8Leds=0;i8Leds<TOTAL_LEDS;i8Leds++){         // Recorro todoso los LEDs
                    control_led(0,verde,i8Leds);                        // Apagado LED verde
                    control_led(0,rojo,i8Leds);                         // Apagado LED rojo
                }        
                
                readRegister8_MMA8451(MMA8451_REG_MT_SRC);  // Borrado interrupcion del acelerometro
                delay_ms(100);                              // Peque�o delay espera
                aux=PORTB;                                  // Leo el puerto B 
                clear_RB=0;                                 // Limpio interrupci�n RB
                delay_ms(1);                                // Peque�o delay
                baceleron=0;                                // Inicializo flag que indica caida del dispositivo         
                enable_RB=1;                                // Habilito interrupcio�n puerto RB
            }else{                      // Si el error es por la alimentaci�n de tratamiento
                ST7529_printf("     ERROR ALIMENTACION    ",0,50,L_,NORMAL);     // Muestro error de alimentaci�n
                ST7529_printf("        TRATAMIENTO",0,70,L_,NORMAL);    // Muestro error de alimentaci�n
                ControlSonido(1);                                       // Enciendo el pito
                delay_ms(5000);                                         // Delay pito
                ControlSonido(0);                                       // Apago el pito
                bPrimeraMedida=0;                                       // Inicializo el valor de la primera medida
                
                // Apagado leds de tratamiento
                for (int8 i8Leds=0;i8Leds<TOTAL_LEDS;i8Leds++){         // Recorro todoso los LEDs
                    control_led(0,verde,i8Leds);                        // Apagado LED verde
                    control_led(0,rojo,i8Leds);                         // Apagado LED rojo
                }    
            }
        }
        
        // --------------------------------------- REPRESENTACI�N TIEMPO ----------------------------------- 
        
        if (iMenuActual==141 || iMenuActual==142 || iMenuActual==181 || iMenuActual==121 || i8CanalesActivados || i8ReposoActivados){           // En tratamiento o reposo en electroestimulacion o SMP
            if (f_segundo){                                                                                             // Si ha pasado un segundo
                f_segundo=0;                                                                                            // Se reinicia la variable
                if(bEmpiezaContadorTiempo){                                                                             // Si se ha alcanzado el valor de corriente seleccionado, puede empezar a descontar el tiempo    
                    if(iMenuActual==141 || i8CanalesActivados){                                                         // Si esta en el menu de tratamiento...
                        for(int8 i8ContTime=0; i8ContTime<3; i8ContTime++){                                             // Observamos cada canal...
                            if((i8CanalesActivados & (1<<i8ContTime)) && !(i8ReposoActivados & (1<<i8ContTime))){       // Si el canal que queremos est� activado y no se encuentra en reposo
                                if(i16TimeRaw[i8ContTime]<=0){                                                          // Si ha transcurrido todo el tiempo de tratamiento...
                                    if(i8ConfigCanal==i8ContTime){                                                      // Si el canal que se est� observando es el que est� seleccionado en pantalla
                                        iMenuAnterior=iMenuActual;                                                      // Guarda menu anterior
                                        iMenuActual=142;                                                                // Cambio de menu a reposo
                                    }
                                    i16TimeRaw[i8ContTime]=i16TacElec[i8ContTime];                                      // Recargamos el valor del tratamiento activo
                                    bReposoActivado=0;                                                                  // Init variable reposo

                                    if(i8NrepRaw[i8ContTime]>1){                                                        // Si todavia quedan repeticiones
                                        switch(i8ContTime){                                                             // Depende del canal que se est� observando
                                            case CHA_C:                                                                 // Canal A
                                                i8ReposoActivados|=CANALES_A;                                           // Indico que se encuentra en reposo
                                                break;
                                            case CHB_C:                                                                 // Canal B                     
                                                i8ReposoActivados|=CANALES_B;                                           // Indico que se encuentra en reposo
                                                break;
                                            case CHC_C:                                                                 // Canal C                          
                                                i8ReposoActivados|=CANALES_C;                                           // Indico que se encuentra en reposo
                                                break;
                                        }
                                        i8RawAux=i8ConfigCanal;                                                         // Variable auxiliar para cambiar el estado de este canal en Orco
                                        i8ConfigCanal=i8ContTime;                                                       // Cambio el canal a configurar
                                        
                                        envioTratamiento(MODO_START_STOP,COMANDO_START_REPOSO);                         // Envio paquete REPOSO
                                        
                                        i8ConfigCanal=i8RawAux;                                                         // Vuelvo a poner el valor que tenia anteriormente
                                        structMedidasElectro.si16IMedElec[i8ContTime][PULSO_POS]=0;                     // Inicializo el valor de corriente de la struct
                                        bReposoActivado=1;                                                              // Activa el flag indicando que el modo reposo est� activado
                                    }else{                                                                              // Si estamos en la �ltima repetici�n
                                        i8NrepRaw[i8ContTime]=i8Nrep[i8ContTime];                                       // Inicializo el valor de repeticiones
                                        
                                        switch(i8ContTime){                                                             // Dependiendo del canal que estemos observando
                                            case CHA_C:                                                                 // Canal A
                                                i8CanalesActivados&=~CHA_ACT;                                           // Inicializo flag de canal activado
                                                i8ReposoActivados&=~CHA_ACT;                                            // Inciializo flag de canal en reposo
                                                apagadoCHA();                                                           // Apagado del canal
                                                control_led(0,verde,led_CHA);                                           // Apagado LED del canal
                                                break;
                                            case CHB_C:                                                                 // Canal B                          
                                                i8CanalesActivados&=~CHB_ACT;                                           // Inicializo flag de canal activado 
                                                i8ReposoActivados&=~CHB_ACT;                                            // Inciializo flag de canal en reposo
                                                apagadoCHB();                                                           // Apagado del canal                 
                                                control_led(0,verde,led_CHB);                                           // Apagado LED del canal             
                                                break;
                                            case CHC_C:                                                                 // Canal C                           
                                                i8CanalesActivados&=~CHC_ACT;                                           // Inicializo flag de canal activado 
                                                i8ReposoActivados&=~CHC_ACT;                                            // Inciializo flag de canal en reposo
                                                control_led(0,verde,led_CHC);                                           // Apagado del canal                 
                                                apagadoCHC();                                                           // Apagado LED del canal             
                                                break;
                                            case POINTER_C:                                                             // Canal POINTER                           
                                                i8CanalesActivados&=~POINTER_ACT;                                       // Inicializo flag de canal activado 
                                                i8ReposoActivados&=~POINTER_ACT;                                        // Inciializo flag de canal en reposo
                                                apagadoCHA();                                                           // Apagado del canal                 
                                                control_led(0,verde,led_CHA);                                           // Apagado LED del canal             
                                                break;
                                        }
                                        i8RawAux=i8ConfigCanal;                                                         // Variable auxiliar para cambiar el estado de este canal en Orco
                                        i8ConfigCanal=i8ContTime;                                                       // Cambio el canal a configurar                                  
                                                                                                                                                                                         
                                        envioTratamiento(MODO_START_STOP,COMANDO_STOP);                                 // Envio paquete STOP                                          
                                                                                                                                                                                         
                                        i8ConfigCanal=i8RawAux;                                                         // Vuelvo a poner el valor que tenia anteriormente               
                                        structMedidasElectro.si16IMedElec[i8ContTime][PULSO_POS]=0;                     // Inicializo el valor de corriente de la struct                 
                                                                                                                           
                                        pitidoLargo();                                                                  // Pitido largo indicando final de tratamiento                           
    
                                        if(i8CanalesActivados==0){                                                      // Si no hay canales activados
                                            iMenuAnterior=iMenuActual;                                                  // Cambio de men�
                                            iMenuActual=140;                                                            // Voy al men� 140
                                        }
                                    }
                                }else{                                                                                  // ...si no ha transcurrido todo el tiempo de tratamiento
                                    if(!(i16ErroresOcurridos & (1<<i8ContTime))){                                       // Si no existe error de electrodo en ese canal
                                        i16TimeRaw[i8ContTime]--;                                                       // Resta un segundo
                                        if(i16TimeRaw[i8ContTime]<=4 && i8Nrep[i8ContTime]==1){                         // Si estamos en los �ltimos 5 segundos y es la �ltima repetici�n
                                            pitidoCorto();                                                              // Pitido corto
                                        }
                                    }
                                }   // Cierre if - si ha transcurrido todo el tiempo de tratamiento
                            }   // Cierre if - Si el canal que queremos est� activado y no se encuentra en reposo
                        }   // Cierre for observaci�n canales 
                    }else if(iMenuActual==181){                                                                         // Control tiempo - Sistema Multipulsos
                        if(i16TimeRaw[0]<=0){                                                                           // Si ha transcurrido todo el tiempo de tratamiento...
                            iMenuAnterior=iMenuActual;                                                                  // Guarda menu anterior
                            iMenuActual=180;                                                                            // Cambio de menu
                            i16TimeRaw[0]=i16TacSMP;                                                                    // Recargamos el valor del tratamiento activo
                            i16ISMP=4;                                                                                  // Inicializo valor de corriente
                            i8PulsosSMP=1;                                                                              // Inicializo n�mero de pulsos
                            bCorrientePulsos=0;                                                                         // Inicializo selector pulsos/corriente a corriente
        
                            envioTratamiento(MODO_START_STOP,COMANDO_STOP);                                             // Envio paquete STOP
                            
                            pitidoLargo();                                                                              // Pitido largo indicando final de tratamiento
                            
                            apagadoSMP();                                                                               // Apago el tartamiento de SMP
                            
                            bTratamientoSMPActivado=0;                                                                  // Inicializo variable de tratamiento SMP activado
                        }else{                                                                                          // ...si no ha transcurrido todo el tiempo de tratamiento
                            i16TimeRaw[0]--;                                                                            // Resta un segundo
                        }
                    }else if(iMenuActual==121){                                                                         // Control de tiempo - Galv�nica
                        if(i16Tgalv==0){                                                                                // Si es tiempo ilimitado
                            i16TimeRaw[0]++;                                                                            // Incremento el tiempo de tratamiento un segundo
                            if(bValorAlcanzado && !bTerapia){                                                           // Si se ha alcanzado el valor de corriente deseado y estamos en galv�nica
                                i32CargaGalvanicaRestante-=i16DecrementoCargaGalvanica;                                 // Decrementa el nivel de carga de tratamiento restante
                            }else{                                                                                      // Si no...
                                i32CargaGalvanicaRestante-=i16CRampaGalvInc;                                            // Decrementa el nivel de carga de tratamiento restante en rampa
                            }
                        }else{                                                                                          // Si hay un tiempo definido de tratamiento
                            i16TimeRaw[0]--;                                                                            // Se resta un segundo
                            
                            if((i16TimeRaw[0]<=5 && i16TimeRaw[0]>=1) && (!bSeleccionGalvanica || (bSeleccionGalvanica&&bTerapia))){  // Si estamos en los �ltimos 5 segundos del tratamiento
                                pitidoCorto();                                                                          // Pitido corto
                            }
                            
                            if(i16TimeRaw[0]<=0){                                                                       // Si ha transcurrido todo el tiempo de tratamiento...
                            
                                if(!bSeleccionGalvanica || (bSeleccionGalvanica&&bTerapia)){                            // Si solo se ha seleccionado galvanica O ya debe de apagarse el tratamiento tras pasar el tiempo de microcorrientes
                                    iMenuAnterior=iMenuActual;                                                          // Guarda menu anterior
                                    iMenuActual=120;                                                                    // Cambio de menu
                                    
                                    i16Tgalv=calc_Tgalv(i32Cgalv,i16Igalv);                                             // Inicializo variable tiempo 
                                    i16TimeRaw[0]=i16Tgalv+i8TrampaGalv;                                                // Inicializo variable tiempo raw
                                    i32CargaGalvanicaRestante=i32Cgalv+i16CRampaGalv;                                   // Inicializo variable carga 
                                    
                                    envioTratamiento(MODO_START_STOP,COMANDO_STOP);                                     // Envio paquete STOP
                                    
                                    pitidoLargo();                                                                      // Pitido Largo
                                    
                                    apagadoMicrocorrientes();                                                           // Apago el tratamieto de galvanica
                                }else{                                                                                  // Si se ha seleccionado galv�nica + microcorrientes
                                    bTerapia=1;                                                                         // Indico que empieza microcorrientes
                                    bMicrocorrientesEncendido=1;                                                        // Indico microcorrientes encendido
                                    giPos=i16Imicro;                                                                    // Inicializo giPos
                                    i8TratamientoSeleccionado=TRATAMIENTO_MICROCORRIENTES;                              // Indico tratamiento microcorrientes
                                    i16TimeRaw[0]=i16Tmicro;                                                            // Cargo el tiempo de microcorrientes en el contador de tiempo

                                    structTratamientoGalvanicaActivo.si16IGalv=i16IGalv;                                // Asigna el valor de corriente 
                                    structTratamientoGalvanicaActivo.si16Imicro=i16Imicro;                              // Asigna el valor de corriente 
                                    structTratamientoGalvanicaActivo.sbTerapia=bTerapia;                                // Asigna el valor de terapia 
                                    
                                    envioTratamiento(MODO_TRAT_GALV_ACTIVO);                                            // Envio paquete galv�nica
                                     
                                    pitidoLargo();                                                                      // Pitido largo
                                }
                            }else{                                                                                      // ...si no ha transcurrido todo el tiempo de tratamiento
                                                                                                                            
                                if(bValorAlcanzado && !bTerapia){                                                       // Si se ha alcanzado el valor de corriente de tratamiento galv�nico
                                    i32CargaGalvanicaRestante-=i16DecrementoCargaGalvanica;                             // Decrementa el nivel de carga de tratamiento restante
                                }else{                                                                                  // Si no...
                                    i32CargaGalvanicaRestante-=i16CRampaGalvInc;                                        // Decrementa el nivel de carga de tratamiento restante en rampa
                                }
                            }
                        }   // Cierre if - Tiempo restante
                    }   // Cierre if - Tratamiento galv�nica
                    if(i8ReposoActivados){                                                                              // Si estamos en reposo de electroestimulaci�n...
                        for(int8 i8ContTimer=0; i8ContTimer<3; i8ContTimer++){                                          // Observamos todos los canales
                            if(i8ReposoActivados & (1<<i8ContTimer)){                                                   // Selecciona entre los distintos canales de electroestimulaci�n
                                if(i8NrepRaw[i8ContTimer]<=1){                                                          // Si ya han transcurrido todas las repeticiones...
                                    i8NrepRaw[i8ContTimer]=i8Nrep[i8ContTimer];                                         // Inicializo el valor de repeticiones
                                    if(i8ConfigCanal==i8ContTimer){                                                     // Si el canal que se est� mostrando es el que se est� observando
                                        iMenuAnterior=iMenuActual;                                                      // Guarda menu anterior
                                        iMenuActual=140;                                                                // Asigna menu de tratamiento 
                                    }
                                    
                                    switch(i8ContTimer){                                                                // Dependiendo del canal que estemos observando 
                                        case CHA_C:                                                                     // Canal A                                      
                                            i8CanalesActivados&=~CHA_ACT;                                               // Inicializo flag de canal activado            
                                            i8ReposoActivados&=~CHA_ACT;                                                // Inciializo flag de canal en reposo           
                                            apagadoCHA();                                                               // Apagado del canal                            
                                            control_led(0,verde,led_CHA);                                               // Apagado LED del canal                        
                                            break;                                                                                                                      
                                        case CHB_C:                                                                     // Canal B                                      
                                            i8CanalesActivados&=~CHB_ACT;                                               // Inicializo flag de canal activado            
                                            i8ReposoActivados&=~CHB_ACT;                                                // Inciializo flag de canal en reposo           
                                            apagadoCHB();                                                               // Apagado del canal                            
                                            control_led(0,verde,led_CHB);                                               // Apagado LED del canal                        
                                            break;                                                                                                                      
                                        case CHC_C:                                                                     // Canal C                                      
                                            i8CanalesActivados&=~CHC_ACT;                                               // Inicializo flag de canal activado            
                                            i8ReposoActivados&=~CHC_ACT;                                                // Inciializo flag de canal en reposo           
                                            control_led(0,verde,led_CHC);                                               // Apagado del canal                            
                                            apagadoCHC();                                                               // Apagado LED del canal                        
                                            break;                                                                                                                      
                                        case POINTER_C:                                                                 // Canal POINTER                                
                                            i8CanalesActivados&=~POINTER_ACT;                                           // Inicializo flag de canal activado            
                                            i8ReposoActivados&=~POINTER_ACT;                                            // Inciializo flag de canal en reposo           
                                            apagadoCHA();                                                               // Apagado del canal                            
                                            control_led(0,verde,led_CHA);                                               // Apagado LED del canal                        
                                            break;
                                    }
                                    
                                    i8RawAux=i8ConfigCanal;                                                             // Variable auxiliar para cambiar el estado de este canal en Orco
                                    i8ConfigCanal=i8ContTimer;                                                          // Cambio el canal a configurar                                  
                                                                                                                                                                                         
                                    envioTratamiento(MODO_START_STOP,COMANDO_STOP);                                     // Envio paquete STOP                                            
                                                                                                                                                                                         
                                    i8ConfigCanal=i8RawAux;                                                             // Vuelvo a poner el valor que tenia anteriormente               
                                                                                                                                     
                                    pitidoLargo();                                                                      // Pitido largo indicando final de tratamiento                                                               
                                                                                                                                                                                         
                                    if(i8CanalesActivados==0){                                                          // Si no hay canales activados                                   
                                        iMenuAnterior=iMenuActual;                                                      // Cambio de men�                                                
                                        iMenuActual=140;                                                                // Voy al men� 140                                               
                                    }                                                                                                      
                                    bReposoActivado=0;                                                                  // Inicializa variable de reposo activado
                                }else{                                                                                  // ...si quedan repeticones por realizar
                                    if(i16TimeRepRaw[i8ContTimer]<=0){                                                  // Si ha transcurrido todo el tiempo de reposo....
                                        if(i8ConfigCanal==i8ContTimer){                                                 // Si el canal que se est� mostrando es el que se est� observando
                                            iMenuAnterior=iMenuActual;                                                  // Guarda menu anterior                                                                                           
                                            iMenuActual=141;                                                            // Asigna menu de tratamiento                                                                                     
                                        }
                                        bReposoActivado=0;                                                              // Desactivamos el reposo
                                        i16TimeRepRaw[i8ContTimer]=i16TdElec[i8ContTimer];                              // Recargamos el valor de reposo
                                        i8NrepRaw[i8ContTimer]--;                                                       // Resta una repeticion
                                        switch(i8ContTimer){                                                            // Depende del canal que se est� observando          
                                            case CHA_C:                                                                 // Canal A                                 
                                                i8ReposoActivados&=~CANALES_A;                                          // Indico que se encuentra en reposo       
                                                break;                                                                                                             
                                            case CHB_C:                                                                 // Canal B                                 
                                                i8ReposoActivados&=~CANALES_B;                                          // Indico que se encuentra en reposo       
                                                break;                                                                                                             
                                            case CHC_C:                                                                 // Canal C                                 
                                                i8ReposoActivados&=~CANALES_C;                                          // Indico que se encuentra en reposo       
                                                break;                                                                  
                                        }
                                        
                                        i8RawAux=i8ConfigCanal;                                                         // Variable auxiliar para cambiar el estado de este canal en Orco 
                                        i8ConfigCanal=i8ContTimer;                                                      // Cambio el canal a configurar                                   
                                        
                                        envioTratamiento(MODO_START_STOP,COMANDO_STOP_REPOSO);                          // Envio paquete STOP REPOSO
                                           
                                        i8ConfigCanal=i8RawAux;                                                         // Vuelvo a poner el valor que tenia anteriormente 
                                    }else{                                                                              // ...si no ha transcurrido todo el tiempo de reposo
                                        if(!(i16ErroresOcurridos & (1<<i8ContTimer))){                                  // Si no existe error de electrodo en ese canal
                                            i16TimeRepRaw[i8ContTimer]--;                                               // Resta un segundo
                                        }
                                    }
                                } // Cierre if-else Num reps elect
                            } // Cierre if i8ReposoActivados
                        } // Cierre for
                    } // Cierre if-else menu terapia
                }   // Cierre valor alcanzado
             } // Cierre if segundo
             result=(*funcArr_menu[iMenuActual])();                                                                     // Refresca el valor de pantalla
        }else{                                                                                                          // Si no est� en ninguna terapia activa...
            switch(checkAutoapagado()){                                                                                 // Comprueba si lleva inactivo 10 minutos
                case TIEMPO_DESCUENTO:                                                                                  // Si lleva 9 minutos inactivo, indica al usuario que el equipo se apagar� autom�ticamente en un minuto
                    iMenuActual=200;                                                                                    // Men� tiempo de descuento                   
                    break;
                case INACTIVO:                                                                                          // Si ha pasado el "minuto de cortes�a" y el usuario no ha tocado el equipo, este entra en modo sleep
                    iMenuActual=201;                                                                                    // Men� de apagado del equipo
                    bSleepMode=1;                                                                                       // Flag que indica que se va a dormir
                    break;
            }
            result=(*funcArr_menu[iMenuActual])();                                                                      // Refresca el valor de pantalla
        }
        
        // --------------------------------------- MEN�S RULANCHA ----------------------------------- 
        
        switch (iMenuActual){
            case 20:                    // Galv�nica + microcorrientes
                switch(giPos){
                    case 1:             // Configuracion corriente electrica galvanica  
                        submenu_22();
                        break;
                    case 2:             // Configuracion tiempo galvanica               
                        submenu_42();
                        break;
                    case 3:             // Configuracion Tiempo de rampa galvanica      
                        submenu_23();
                        break;
                    case 4:             // Configuracion corriente microcorrientes micro
                        submenu_22();
                        break;
                    case 5:             // Configuracion Tiempo activo microcorriente   
                        submenu_42();
                        break;
                    case 6:             // Configuracion de polaridad                   
                        submenu_29();
                        break;
                    case 7:             // Configuracion ancho de pulso microcorrientes 
                        submenu_27();
                        break;
                    case 8:             // Configuracion frecuencia microcorrientes     
                        submenu_28();
                        break;
                }
                break;
            case 40:                    // Electroestimulaci�n + Pointer
                switch(giPos){
                    case 2:             // Configuracion tiempo activo              
                        submenu_42();
                        break;
                    case 3:             // Configuracion tiempo descanso            
                        submenu_42();
                        break;
                    case 4:             // Configuracion tiempo rampa               
                        submenu_23();
                        break;
                    case 5:             // Configuracion n�mero de repeticiones     
                        submenu_43();
                        break;
                    case 6:             // Configuracion de corriente de tratamiente
                        submenu_22();
                        break;
                    case 7:             // Configuracion de frecuencia              
                        submenu_28();
                        break;
                    case 8:             // Configuracion de polaridad               
                        submenu_29();
                        break;
                    case 9:             // Configuracion de simetria                
                        submenu_33();
                        break;
                    case 10:            // Configuracion del PW +                   
                        submenu_27();
                        break;
                    case 11:            // Configuracion del PW -                   
                        submenu_27();
                        break;
                }
                break;
            case 80:                    // SMP
                switch(giPos){
                    case 0:             // Tiempo activo SMP 
                        submenu_42();
                        break;
                    case 1:             // Tiempo desfase SMP
                        submenu_42();
                        break;
                    case 2:             // Frecuencia SMP    
                        submenu_28();
                        break;
                    case 3:             // Ancho de pulso SMP
                        submenu_27();
                        break;
                }
                break;
        }
        
        // --------------------------------------- TECLA PULSADA ----------------------------------- 
        
        if(!input_state(MENU_4)){                               // TECLA 1 - Si se presiona la tecla de selecci�n hacia arriba
            i32TiempoComunicaciones=0;                          // Reinicio variable timeout comunicaciones
            ControlSonido(1);                                   // Activa sonido para la tecla
            delay_ms(DELAY_PITIDO_TECLADO);                     // Delay pitido tecla
            ControlSonido(0);                                   // Apago pito
            itecla=1;                                           // Selecciona opci�n 1
            delay_ms(DELAY_TECLADO);                            // Delay antirebote
        }else if(!input_state(MENU_3)){                         // TECLA 2 - Si se presiona la tecla de selecci�n hacia abajo
            i32TiempoComunicaciones=0;                          // Reinicio variable timeout comunicaciones
            ControlSonido(1);                                   // Activa sonido para la tecla
            delay_ms(DELAY_PITIDO_TECLADO);                     // Delay pitido tecla 
            ControlSonido(0);                                   // Apago pito         
            itecla=2;                                           // Selecciona opci�n 2                  
            delay_ms(DELAY_TECLADO);                            // Delay antirebote                       
        }else if(!input_state(MENU_2)){                         // TECLA 3 - Si se presiona la tecla de selecci�n hacia la derecha/config
            i32TiempoComunicaciones=0;                          // Reinicio variable timeout comunicaciones
            if(iMenuActual!=141 && iMenuActual!=121){           // Si no estamos en tratamiento activo de galvanica o tratamiento activo de electroestimulaci�n
                if(!(iMenuActual==141 && (i8CanalesActivados==CANALES_AB || i8CanalesActivados==CANALES_BC || i8CanalesActivados == CANALES_AC || i8CanalesActivados==CANALES_ABC))){       // Si NO estamos en electroestimulacion ni el numero de canales activados en este es superior 2
                    ControlSonido(1);                           // Activa sonido para la tecla
                }
            }
            delay_ms(DELAY_PITIDO_TECLADO);                     // Delay pitido tecla 
            ControlSonido(0);                                   // Apago pito         
            itecla=3;                                           // Selecciona opci�n 3
            delay_ms(DELAY_TECLADO);                            // Delay antirebote   
        }else if(!input_state(MENU_1)){                         // TECLA 4 - Si se presiona la tecla de selecci�n hacia la izquierda/cancelar
            i32TiempoComunicaciones=0;                          // Reinicio variable timeout comunicaciones
            if(iMenuActual!=141 && iMenuActual!=181 && iMenuActual!=121){   // Si no estamos en tratamiento activo
                ControlSonido(1);                               // Activa sonido para la tecla
            }
            delay_ms(DELAY_PITIDO_TECLADO);                     // Delay pitido tecla 
            ControlSonido(0);                                   // Apago pito         
            itecla=4;                                           // Selecciona opci�n 4
            delay_ms(DELAY_TECLADO);                            // Delay antirebote   
        }else if(!input_state(ST_STOP)){                        // Si se presiona la tecla de selecci�n start/stop
            i32TiempoComunicaciones=0;                          // Reinicio variable timeout comunicaciones
            ControlSonido(1);                                   // Activa sonido para la tecla
            delay_ms(DELAY_PITIDO_TECLADO);                     // Delay pitido tecla 
            ControlSonido(0);                                   // Apago pito         
            itecla=5;                                           // Selecciona opci�n 5 
            delay_ms(DELAY_TECLADO);                            // Delay antirebote           
        }
        
        // --------------------------------------- TECLA 1 (SELECCTOR ARRIBA / GIRO DERECHA) ----------------------------------- 
        
        if(itecla==1){                                          // Si se ha presionado la tecla 1
            var_puls=1;                                         // Indicamos quen se ha pulsado la tecla 1
            bascendente=1;                                      // Indicamos que se trata de la tecla ascendente activando el flag
        
            if((i8CanalesActivados==0)&&((iMenuActual!=141)&&(iMenuActual!=142)&&(iMenuActual!=181)&&(iMenuActual!=121)&&(iMenuActual!=200))){      // Si no est� realizando ningun tratamiento
                var_tiempo=0;                                   // Reinicia la variable tiempo para el autoapagado
            }
        
            if (iMenuActual==141 || iMenuActual==121){          // Si est� en tratamiento de electroestimulacion o galvanica
                if(iMenuActual==121){                           // Si estamos en tratamiento de galv�nica
                    if(!bTerapia){                              // Si estamos en galv�nica
                        if(bValorAlcanzado){                    // Si se ha alcanzado el valor de corriente deseado
                            (giPos<20) ? (giPos++) : (giPos+=2);// Si la corriente es menor de (20*50) = 1000uA = 1mA, los incrementos son de 50 uA, sino, de 100uA
        
                            if ((giPos>=200)){                  // Si estamos en terapia de galvanica
                                giPos=200;                      // Fijamos el m�ximo nivel de corriente a (200*50) = 10000uA = 10mA
                            }
                    
                            i16Igalv=giPos;                     // Asigno el valor de gipos a la corriente
                            
                            i16DecrementoCargaGalvanica=i16Igalv*50;    // Asigno nuevo decremento de la carga galv�nica
                            
                            if(i16Tgalv!=0){                    // Si el tiemp ode tratamiento es distinto de 0 (infinito)
                                i16TimeRaw[0]=calc_Tgalv(i32CargaGalvanicaRestante,i16Igalv);   // Calculo el nuevo tiempo de carga
                            }
                            bCambiado=1;                        // Indico que se ha modificado el nivel de corriente durante el tratamiento
                        }
                    }else{                                      // Si estamos en microcorrientes
                        (giPos<20) ? (giPos++) : (giPos+=2);    // Si la corriente es menor de (20*50) = 1000uA = 1mA, los incrementos son de 50 uA, sino, de 100uA
                        
                        if ((giPos>=100)&&(bTerapia==1)){       // Si estamos en terapia de microcorrientes y la coreinte es superior a (100*50) = 5000uA = 5mA
                            giPos=100;                          // Fijamos el m�ximo nivel de corriente a (100*50) = 5000uA = 5mA 
                        }
                        
                        i16Imicro=giPos;                        // Asigno el valor de gipos a la corriente
                        bCambiado=1;                            // Indico que se ha modificado el nivel de corriente durante el tratamiento
                        bEmpiezaContadorTiempo=1;               // Pone el contador de tiempo activo (en realidad no hace falta, ya esta activado anteriormente!??)
                    }
                }else{                                          // Si est� en tratamiento de electroestimulacion
                    giPos=i16IElec[i8ConfigCanal];              // Asigno el valor de la corriente a giPos
                    giPos++;                                    // Aumento el contador (aumenta corriente e tratamiento activo)
                    
                    if(giPos>=300){                             // Si estamos en terapia de microcorrientes y la corrinte es superior a (300*50) = 15000uA = 15mA
                        giPos=300;                              // Fijamos el m�ximo nivel de corriente a (300*50) = 15000uA = 15mA
                    }
                    
                    i16IElec[i8ConfigCanal]=giPos;              // Asigno el valor de gipos a la corriente
                    bCambiado=1;                                // Indico que se ha modificado el nivel de corriente durante el tratamiento
                }
            }else if (iMenuActual==181){                        // Si estamos entratamiento SMP
                giPos++;                                        // Aumento la corriente o pulsos en factor de 1
                
                if (giPos>=300){                                // Si supera los 15mA (300*50)
                    giPos=300;                                  // Fija a 15 mA
                }
        
                if(bCorrientePulsos){                           // Si se est� modificando el n�meo de pulsos (bCorrientePulsos==1)
                    if(giPos>=i8MaxPulsosSMP){                  // Si se a llegado al m�ximo n�mero de pusos que puede realizar
                        gipos=i8MaxPulsosSMP;                   // Asigna el m�ximo valor
                    }
                    delay_ms(150);                              // Peque�o delay antirebotes - REVISAR
                    i8PulsosSMP=giPos;                          // Asigno el valor de pulsos a la variable que controla el n�mero de pulsos
                }else{                                          // Si se est� modificando el valor de corriente (bCorrientePulsos==0)
                    i16ISMP=giPos;                              // Asigno el valor de corriente
                }
                
                bCambiado=1;                                    // Indica que se ha realizado u cambio en la corriente o pulsos de SMP, para poder enviarlo a orco
            }else if(iMenuActual==120 || iMenuActual==140 || iMenuActual==180){     // Si estamos  en el men� de antes de empezar el tratamiento
                                                                                    // No hagas nada
            }else{                                                                  // ...si no est� en tratamiento
                if ((iMenuActual%10==0)&&(iMenuActual<90)&&(iMenuActual!=50)){      // Si est� en un men� principal y es menor que los men�s 7x
                    if(bModoRulancha && (iMenuActual==20 || iMenuActual==40 || iMenuActual==80)){   // Si la rulancha ha sido movida y estamos en los men�s de configuraci�n de tratamiento 
                        if(!((iMenuActual==20 && giPos==9) || (iMenuActual==40 && giPos==12) || (iMenuActual==80 && giPos==4))){    // Mientras que no estemos encima de la opci�n de Configurar Tratamiento
                            if(iMenuActual==40 && giPos==6){                        // Si estamos el men� de configuraci�n de corriente
                                giPosRulancha+=2;                                   // Incrementos en pasos de 2 (nivel de corriente aumenta de 100 en 100) 2*50
                            }else{                                                  // Si no...
                                giPosRulancha++;                                    // Aumenta en pasos de uno
                            }
                        }
                    }else{                                                          // Si no se utiliza la rulancha para modificar el valor...
                        if (giPos==0){                                              // Si giPos es igual a 0...
                            giPos=0;                                                // No bajes de ahi
                        }else{                                                      // ...si no es igual a cero
                            giPos--;                                                // Decrementa giPos
                            switch (iMenuActual){                                   // Dependiendo del men� actual
                                case 20:                                            // Galv�nica + microcorrientes
                                    switch(giPos){                                  // Dependiendo del men� sobre en el que estemos
                                        case 1:                                     // Configuracion corriente electrica galvanica  
                                            giPosRulancha=i16Igalv;                 // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 2:                                     // Configuracion tiempo galvanica               
                                            giPosRulancha=i16Tgalv;                 // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 3:                                     // Configuracion Tiempo de rampa galvanica      
                                            giPosRulancha=i8Trampagalv;             // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 4:                                     // Configuracion corriente microcorrientes micro
                                            giPosRulancha=i16Imicro;                // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 5:                                     // Configuracion Tiempo activo microcorriente   
                                            giPosRulancha=i16Tmicro/5;              // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 6:                                     // Configuracion de polaridad                   
                                            giPosRulancha=bPolaridadMicro;          // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 7:                                     // Configuracion ancho de pulso microcorrientes 
                                            giPosRulancha=i16PWmicro/25;            // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 8:                                     // Configuracion frecuencia microcorrientes     
                                            giPosRulancha=i16frecmicro;             // Inicializo la rulancha con el valor del men�
                                            i16FrecuenciaAnterior=i16frecmicro;     // Inicializo la frecuencia con el valor anterior (cambio de frecuencia/saltos en men�)
                                            break;
                                    }
                                    break;
                                case 40:                                            // Electroestimulaci�n + Pointer
                                    switch(giPos){                                  // Dependiendo del men� sobre en el que estemos
                                        case 2:                                     // Configuracion tiempo activo              
                                            giPosRulancha=i16TacElec[i8ConfigCanal]/5;  // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 3:                                     // Configuracion tiempo descanso            
                                            giPosRulancha=i16TdElec[i8ConfigCanal]/5;   // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 4:                                     // Configuracion tiempo rampa               
                                            giPosRulancha=i8TrElec[i8ConfigCanal];  // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 5:                                     // Configuracion n�mero de repeticiones   
                                            if(i16TdElec[i8ConfigCanal]!=0){        // Si hay tiempo de descanso (es decir, hay repeticiones configuradas)
                                                giPosRulancha=i8Nrep[i8ConfigCanal];    // Inicializo la rulancha con el valor del men�
                                            }else{                                  // Si no hay tiempo de descanso definido...
                                                giPosRulancha=i8TrElec[i8ConfigCanal];  // Inicializo la rulancha con el valor del men�
                                            }
                                            break;
                                        case 6:                                     // Configuracion de corriente de tratamiente
                                            giPosRulancha=i16IElec[i8ConfigCanal];  // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 7:                                     // Configuracion de frecuencia        
                                            
                                            giPosRulancha=i16frecElec[i8ConfigCanal]/gF;    // Inicializo la rulancha con el valor del men�
                                            i16FrecuenciaAnterior=i16frecElec[i8ConfigCanal];   // Inicializo la frecuencia con el valor anterior (cambio de frecuencia/saltos en men�)
                                            break;
                                        case 8:                                     // Configuracion de polaridad 
                                            giPosRulancha=bpolaridadElec[i8ConfigCanal];    // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 9:                                     // Configuracion de simetria  
                                            if(i8ConfigCanal==POINTER_C){                           // Si estamos configurando el pointer
                                                giPosRulancha=i16frecElec[i8ConfigCanal]/gF;        // Inicializo la rulancha con el valor del men�
                                                i16FrecuenciaAnterior=i16frecElec[i8ConfigCanal];   // Inicializo la frecuencia con el valor anterior (cambio de frecuencia/saltos en men�)
                                            }else{                                                  // Si no...            
                                                if(bpolaridadElec[i8ConfigCanal]){                  // Si al se�al es bipolar
                                                    giPosRulancha=bsimetriaElec[i8ConfigCanal];     // Inicializo la rulancha con el valor del men�
                                                }else{                                              // Si es monopolar
                                                    giPosRulancha=bpolaridadElec[i8ConfigCanal];    // Inicializo la rulancha con el valor del men�
                                                }
                                            }
                                            break;
                                        case 10:                                            // Configuracion del PW +         
                                            giPosRulancha=i16PW_plusElec[i8ConfigCanal]/25; // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 11:                                            // Configuracion del PW -   
                                            if(i8ConfigCanal==POINTER_C){                           // Si estamos configurando el pointer
                                                giPosRulancha=i16PW_plusElec[i8ConfigCanal]/25;     // Inicializo la rulancha con el valor del men�
                                            }else{                                                  // Si no...
                                                giPosRulancha=i16PW_minusElec[i8ConfigCanal]/25;    // Inicializo la rulancha con el valor del men�
                                            }
                                            break;
                                    }
                                    break;
                                case 80:                                            // SMP
                                    switch(giPos){                                  // Dependiendo del men� sobre en el que estemos
                                        case 0:                                     // Tiempo activo SMP 
                                            giPosRulancha=i16TacSMP/5;              // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 1:                                     // Tiempo desfase SMP
                                            giPosRulancha=i32TDesfaseSMP/100;       // Inicializo la rulancha con el valor del men�
                                            break;
                                        case 2:                                     // Frecuencia SMP    
                                            giPosRulancha=i16FrecSMP/gF;            // Inicializo la rulancha con el valor del men�
                                            i16FrecuenciaAnterior=i16FrecSMP/gF;    // Inicializo la frecuencia con el valor anterior (cambio de frecuencia/saltos en men�)
                                            break;
                                        case 3:                                     // Ancho de pulso SMP
                                            giPosRulancha=i16PWSMP/25;              // Inicializo la rulancha con el valor del men�
                                            break;
                                    }
                                    break;
                            }
                        }
                    }
                }else{                                                              // ...si se trata de otro tipo de men�
                    if(iMenuActual==21 || iMenuActual==24){                         // Si estamos el men� de configuraci�n de carga galvanica
                        (giPos<20) ? (giPos++) : (giPos+=2);                        // Incrementos en pasos de 2 (nivel de corriente aumenta de 100 en 100) 2*50
                    }else if(iMenuActual==28){
                        (giPos<20) ? (giPos++) : (giPos+=2); 
                    }else if(iMenuActual==47){                                      // Si estamos el men� de configuraci�n de corriente
                        giPos+=2;                                                   // Incrementos en pasos de 2 (nivel de corriente aumenta de 100 en 100) 2*50
                    }else{                                                          // Si estamos en otro men�
                        giPos++;                                                    // Incrementa de uno en uno
                    }
                }
            }   
            itecla=0;                                                               // Inicializa el valor de tecla
            pulsacion=0;                                                            // Inicializa el valor de pulsaci�n (DEBUG???)
            bGirIzquierda=0;                                                        // Inicializa flag giro izquierda
            bGirDerecha=0;                                                          // Inicializa flag giro derecha
            ControlSonido(0);                                                       // Apaga el sonido
            bModoRulancha=0;                                                        // Inicializo el modo rulancha
        }
        
        // --------------------------------------- TECLA 2 (SELECCTOR ABAJO / GIRO IZQUIERDA) ----------------------------------- 
        
        if(itecla==2){                                                              // Si se ha presionado la tecla 2
            var_puls=2;                                                             // Indicamos quen se ha pulsado la tecla 2                          
            bascendente=0;                                                          // Indicamos que se trata de la tecla descendente inicializando el flag
        
            if((i8CanalesActivados==0)&&((iMenuActual!=141)&&(iMenuActual!=142)&&(iMenuActual!=181)&&(iMenuActual!=121)&&(iMenuActual!=200))){  // Si no est� realizando ningun tratamiento
                var_tiempo=0;                                                       // Reinicia la variable tiempo para el autoapagado
            }
        
            if (iMenuActual==141 || iMenuActual==121){                              // Si estamos en tratamiento activo deelectroestimulaci�n o galv�nica  
                if(iMenuActual==141){                                               // Si estamos en tratamiento de elcetroestimulaci�n
                    if (giPos<=2){                                                  // Si giPos es igual a dos...
                        giPos=2;                                                    // No bajes de ahi
                    }else{                                                          // ...si no es igual a dos
                        giPos=i16IElec[i8ConfigCanal];                              // Asigno el valor de corriente a giPOs
                        giPos--;                                                    // Decrementa el valor
                    }
                }else if(iMenuActual==121){                                         // Si estamos en tratamiento de galv�nica
                    if(bValorAlcanzado){
                        if (giPos<=2){                                              // Si giPos es igual a doos...
                            giPos=2;                                                // No bajes de ahi
                        }else{                                                      // ...si no es igual a dos
                            (giPos>20) ? (giPos-=2) : (giPos--);                    // Si la corriente es superior a (20*50) = 1000uA = 1mA, decrementos de 100uA, sino, 50uA
                        }
                    }
                }
                
                bCambiado=1;                                                        // Indico que se ha realzado un cambio que hay que indicar a orco
                
                if(iMenuActual==121){                                               // Si estamos en tratamiento de galv�nica
                    if(!bTerapia){                                                  // Si estamos en galv�nica
                        if(bValorAlcanzado){                                        // Si se ha alcanzado el valor de corriente deseado
                            i16Igalv=giPos;                                         // Asigna el valor de corriente a la galv�mica
                            
                            i16DecrementoCargaGalvanica=i16Igalv*50;                // Asigno nuevo decremento de la carga galv�nica
                            if(i16Tgalv!=0){                                        // Si se ha seleccionado tiempo de galv�nica NO infinito
                                i16TimeRaw[0]=calc_Tgalv(i32CargaGalvanicaRestante,i16Igalv);   // Calculo el nuevo tiempo de carga
                            }
                        }else{                                                      // Si no se ha alcanzado el valor de corriente deseado
                            bCambiado=0;                                            // No se indica que se quiere hacer cambio (no debe modificar corriente durante rampa!)
                        }
                    }else{                                                          // Si estamos en microcorrientes
                        i16Imicro=giPos;                                            // Asignamos giPos a la corriente de microcorrientes
                    }
                }else{                                                              // Si estamos en electroestimulaci�n
                    i16IElec[i8ConfigCanal]=giPos;                                  // Asignamos giPos a la corriente
                }
            }else if (iMenuActual==181){                                            // Si estamos en tratamiento de SMP
            
                giPos--;                                                            // Decrementa el valor
                
                if (giPos<=4 && !bCorrientePulsos){                                 // Si giPos es igual a 4 y estamos configurando el valor de corriente
                    giPos=4;                                                        // No bajes de ahi
                }else if(giPos<=1 && bCorrientePulsos){                             // Si giPos es igual a 1 y estamos configurando el valor de pulsos
                    giPos=1;                                                        // No bajes de ahi
                }
                
                if(bCorrientePulsos){                                               // Si estamos configurando el n�merode pulsos
                    if(giPos>=i8MaxPulsosSMP){                                      // Si se ha llegado a el m�ximo n�mero de pulsos
                        gipos=i8MaxPulsosSMP;                                       // Asigno el valor m�ximo de pulsos a giPos
                    }
                    delay_ms(150);                                                  // Peque�o delay antirebotes
                    i8PulsosSMP=giPos;                                              // Asino el valor de giPos a los pulsos
                }else{                                                              // Si etsamos configurando el nivel de corriente
                    i16ISMP=giPos;                                                  // Asigno el valor de giPos a la corriente
                }
                 
                bCambiado=1;                                                        // Indico que se ha realizado un cambio a enviar a Orco
            }else if(iMenuActual==120 || iMenuActual==140 || iMenuActual==180){     // Si estamos en el men� previo a el tratamiento
                                                                                    // No hagas nada
            }else{                                                                  // ...si no estamos en tratamiento
                if((iMenuActual%10==0)&&(iMenuActual<90)&&(iMenuActual!=50)){       // Si estamos en un men� principal y el men� es menor de 7x...
                    if(bModoRulancha && (iMenuActual==20 || iMenuActual==40 || iMenuActual==80)){   // Si la rulancha ha sido movida y estamos en los men�s de configuraci�n de tratamiento 
                        if(giPosRulancha<=0){                                       // Si el valor es igual o inferior a 0
                            giPosRulancha=0;                                        // No debe de bajar de ahi
                        }else{                                                      // Si es superior...
                            if(!((iMenuActual==20 && giPos==9) || (iMenuActual==40 && giPos==12) || (iMenuActual==80 && giPos==4))){
                                if(iMenuActual==40 && giPos==6){                    // Si estamos el men� de configuraci�n de corriente
                                    giPosRulancha-=2;                               // Incrementos en pasos de 2 (nivel de corriente aumenta de 100 en 100) 2*50
                                }else{                                              // Si no estamos en el men� de configuraci�n de corriente
                                    giPosRulancha--;                                // Incrementamos en pasos de 1 (Nivel de corriente en pasos de 50uA)
                                }
                            }
                        }
                    }else{                                                          // En caso de que no se haya movido la rulancha
                        giPos++;                                                    // Incrementamos giPos
                        switch (iMenuActual){                                       // Dependidendo del men� en el que estemos
                            case 20:                                                // Men� Galv�nica + microcorrientes
                                switch(giPos){                                      // Dependiendo de la posici�n del cursor
                                    case 1:                                         // Configuracion corriente electrica galvanica  
                                        giPosRulancha=i16Igalv;                     // Inicializo la rulancha con el valor del men�
                                        break;
                                    case 2:                                         // Configuracion tiempo galvanica               
                                        giPosRulancha=i16Tgalv;                     // Inicializo la rulancha con el valor del men�
                                        break;
                                    case 3:                                         // Configuracion Tiempo de rampa galvanica      
                                        giPosRulancha=i8Trampagalv;                 // Inicializo la rulancha con el valor del men�
                                        break;
                                    case 4:                                         // Configuracion corriente microcorrientes micro
                                        giPosRulancha=i16Imicro;                    // Inicializo la rulancha con el valor del men�
                                        break;
                                    case 5:                                         // Configuracion Tiempo activo microcorriente   
                                        giPosRulancha=i16Tmicro/5;                  // Inicializo la rulancha con el valor del men�
                                        break;
                                    case 6:                                         // Configuracion de polaridad                   
                                        giPosRulancha=bPolaridadMicro;              // Inicializo la rulancha con el valor del men�
                                        break;
                                    case 7:                                         // Configuracion ancho de pulso microcorrientes 
                                        giPosRulancha=i16PWmicro/25;                // Inicializo la rulancha con el valor del men�
                                        break;
                                    case 8:                                         // Configuracion frecuencia microcorrientes     
                                        giPosRulancha=i16frecmicro;                 // Inicializo la rulancha con el valor del men�
                                        i16FrecuenciaAnterior=i16frecmicro;         // Inicializo la frecuencia con el valor anterior
                                        break;
                                }
                                break;
                            case 40:                                                // Men� Electroestimulaci�n + Pointer
                                switch(giPos){                                      // Dependiendo de la posici�n del cursor
                                    case 1:                                         // Configuraci�n de corriente (solo en Pointer)
                                        if(i8ConfigCanal==POINTER_C){               // Si se est� configurando el pointer
                                            giPosRulancha=i16IElec[i8ConfigCanal];  // Inicializo la rulancha con el valor del men�
                                        }           
                                        break;
                                    case 2:                                         // Configuracion tiempo activo              
                                        giPosRulancha=i16TacElec[i8ConfigCanal]/5;  // Inicializo la rulancha con el valor del men�
                                        break;
                                    case 3:                                         // Configuracion tiempo descanso            
                                        giPosRulancha=i16TdElec[i8ConfigCanal]/5;   // Inicializo la rulancha con el valor del men�
                                        break;
                                    case 4:                                         // Configuracion tiempo rampa               
                                        giPosRulancha=i8TrElec[i8ConfigCanal];      // Inicializo la rulancha con el valor del men�
                                        break;
                                    case 5:                                         // Configuracion n�mero de repeticiones   
                                        if(i16TdElec[i8ConfigCanal]!=0){            // Si hay tiempo de descanso definido
                                            giPosRulancha=i8Nrep[i8ConfigCanal];    // Inicializo la rulancha con el valor del men�
                                        }else{                                      // Si no...
                                            giPosRulancha=i16IElec[i8ConfigCanal];  // Inicializo la rulancha con el valor del men�
                                        }
                                        break;
                                    case 6:                                         // Configuracion de corriente de tratamiente
                                        giPosRulancha=i16IElec[i8ConfigCanal];      // Inicializo la rulancha con el valor del men�
                                        break;
                                    case 7:                                                 // Configuracion de frecuencia              
                                        giPosRulancha=i16frecElec[i8ConfigCanal]/gF;        // Inicializo la rulancha con el valor del men�
                                        i16FrecuenciaAnterior=i16frecElec[i8ConfigCanal];   // Inicializo la frecuencia con el valor anterior
                                        break;
                                    case 8:                                                 // Configuracion de polaridad
                                        if(i8ConfigCanal==POINTER_C){                       // Si estamos configurando el pointer
                                            giPosRulancha=i16PW_plusElec[i8ConfigCanal]/25; // Inicializo la rulancha con el valor del men�
                                        }else{                                              // Si no...
                                            giPosRulancha=bpolaridadElec[i8ConfigCanal];    // Inicializo la rulancha con el valor del men�
                                        }
                                        break;
                                    case 9:                                                 // Configuracion de simetria  
                                        if(bpolaridadElec[i8ConfigCanal]){                  // Si la se�al es bipolar
                                            giPosRulancha=bsimetriaElec[i8ConfigCanal];     // Inicializo la rulancha con el valor del men�
                                        }else{                                              // Si es monopolar...
                                            giPosRulancha=i16PW_plusElec[i8ConfigCanal]/25; // Inicializo la rulancha con el valor del men�
                                        }
                                        break;
                                    case 10:                                                // Configuracion del PW +         
                                        giPosRulancha=i16PW_plusElec[i8ConfigCanal]/25;     // Inicializo la rulancha con el valor del men�
                                        break;
                                    case 11:                                                // Configuracion del PW -                   
                                        giPosRulancha=i16PW_minusElec[i8ConfigCanal]/25;    // Inicializo la rulancha con el valor del men�
                                        break;
                                }
                                break;
                            case 80:                                            // Men� SMP
                                switch(giPos){                                  // Dependiendo de la posici�n del cursor
                                    case 0:                                     // Tiempo activo SMP 
                                        giPosRulancha=i16TacSMP/5;              // Inicializo la rulancha con el valor del men�
                                        break;
                                    case 1:                                     // Tiempo desfase SMP
                                        giPosRulancha=i32TDesfaseSMP/100;       // Inicializo la rulancha con el valor del men�
                                        break;
                                    case 2:                                     // Frecuencia SMP    
                                        giPosRulancha=i16FrecSMP/gF;            // Inicializo la rulancha con el valor del men�
                                        i16FrecuenciaAnterior=i16FrecSMP/gF;    // Inicializo la frecuencia con el valor anterior
                                        break;
                                    case 3:                                     // Ancho de pulso SMP
                                        giPosRulancha=i16PWSMP/25;              // Inicializo la rulancha con el valor del men�
                                        break;
                                }
                                break;
                        }
                    }
                }else{                                              // ...si no estamos en ninguno de esos men�s
                    if (giPos==0){                                  // Si giPos es igual a cero...
                        giPos=0;                                    // No bajes de ahi
                    }else{                                          // ...si no es igual a cero                                          
                        if(iMenuActual==21 || iMenuActual==24){     // Si estamos el men� de configuraci�n de corriente galv�nica o microcorrientes  
                            (giPos>20) ? (giPos-=2) : (giPos--);    // Si es superior a (20*50 = 1000uA = 1mA), decrementos de 100uA, sino, de 50uA 
                            if(giPos<=2){                           // Si es menor de dos
                                giPos=2;                            // Que no pase de ahi
                            }
                        }else if(iMenuActual==28){                  // Si estamos en el men� de configuraci�-on de frecuencia en galv�nica
                            (giPos>20) ? (giPos-=2) : (giPos--);    // Si es superior a 20Hz, incrementos de 2Hz, sino, de 1Hz
                            if(giPos<=2){                           // Si es menor de dos
                                giPos=2;                            // Que no pase de ahi
                            }
                        }else if(iMenuActual==47){                  // Si estamos el men� de configuraci�n de corriente
                            giPos-=2;                               // Decremento en pasos de 2 (nivel de corriente aumenta de 100 en 100) 2*50
                            if(giPos<=2){                           // Si es menor de dos
                                giPos=2;                            // Que no pase de ahi
                            }
                        }else{                                      // Si estamos en otro men�   
                            giPos--;                                // Decrementa el valor
                        }
                    }
                }
            }
            itecla=0;                                               // Inicializa el valor de tecla
            pulsacion=0;                                            // Inicializa el valor de pulsaci�n (DEBUG???)
            bGirIzquierda=0;                                        // Inicializa flag giro izquierda
            bGirDerecha=0;                                          // Inicializa flag giro derecha
            ControlSonido(0);                                       // Apago el sonido
            bModoRulancha=0;                                        // Inicializo modo rulancha
        }  
        
        // --------------------------------------- TECLA 3 (SELECTOR DERECHA/CONFIGURACION/SELECTOR) ----------------------------------- 
        
        if(itecla==3){                                                          // Si se ha presionado la tecla 3
            var_puls=3;                                                         // Indicamos quen se ha pulsado la tecla 3
            iMenuAnterior=iMenuActual;                                          // Guardamos el valor del menu actual en el men� anterior
        
            if((i8CanalesActivados==0)&&((iMenuActual!=141)&&(iMenuActual!=142)&&(iMenuActual!=181)&&(iMenuActual!=121)&&(iMenuActual!=200))){      // Si no est� realizando ningun tratamiento
                var_tiempo=0;                                                   // Reinicia la variable tiempo para el autoapagado
            }
            

            if(iMenuActual==140 || iMenuActual==141 || iMenuActual==142){       // Si estamos en algun canal de tratamiento
                i8ConfigCanal++;                                                // Cambiamos el canal a configurar
                if(i8ConfigCanal>3){                                            // Si hemos recorrido todos los canales
                    if(bPointerSeleccionado){                                   // Si el pointer est� seleccionado
                        i8ConfigCanal=CHB_C;                                    // Salta al canal B
                    }else{                                                      // Si no...
                        i8ConfigCanal=CHA_C;                                    // Salta al canal A
                    }
                }
                
                if(bPointerSeleccionado && i8ConfigCanal==CHA_C){               // Si el pointer est� seleccionado y se intenca configurar el canal A
                    i8ConfigCanal=POINTER_C;                                    // Salta a configurar el pointer
                }else if(!bPointerSeleccionado && i8ConfigCanal==POINTER_C){    // SI no est� seleccionado el pointer y se intenta configurar el mismo
                    i8ConfigCanal=CHA_C;                                        // Salta a configurar el canal A
                }
                
                switch(i8ConfigCanal){                              // Dependiendo del canal a configurar                 
                    case CHA_C:                                     // Si estamos configurando el canal A                 
                        if(i8CanalesConfigurados&CHA_ACT){          // Si se ha configurado y enviado los datos a Orco    
                            if(i8CanalesActivados&CHA_ACT){         // Si se encuentra el canal activado dando tratamiento
                                if(i8ReposoActivados&CHA_ACT){      // Si se encuentra el canal en reposo                 
                                    iMenuActual=142;                // Indico el men� de tratamiento en reposo            
                                }else{                              // Si no...                                           
                                    iMenuActual=141;                // Indico el men� de tratamiento activo               
                                }                                                                                         
                            }else{                                  // Si no se encuentra dando tratamiento               
                                iMenuActual=140;                    // Indico el men� de tratamiento                      
                            }                                                                                             
                        }else{                                      // Si todavia no se han enviado los datos a Orco      
                            iMenuActual=40;                         // Indico el men� de configuraci�n de tratamiento     
                            giPos=0;                                // Inicializo giPos                                   
                        }                                                                                                 
                        break;                                                                                            
                    case CHB_C:                                     // Dependiendo del canal a configurar                 
                        if(i8CanalesConfigurados&CHB_ACT){          // Si estamos configurando el canal B                 
                            if(i8CanalesActivados&CHB_ACT){         // Si se ha configurado y enviado los datos a Orco    
                                if(i8ReposoActivados&CHB_ACT){      // Si se encuentra el canal activado dando tratamiento
                                    iMenuActual=142;                // Si se encuentra el canal en reposo                 
                                }else{                              // Indico el men� de tratamiento en reposo            
                                    iMenuActual=141;                // Si no...                                           
                                }                                   // Indico el men� de tratamiento activo               
                            }else{                                                                                        
                                iMenuActual=140;                    // Si no se encuentra dando tratamiento               
                            }                                       // Indico el men� de tratamiento                      
                        }else{                                                                                            
                            iMenuActual=40;                         // Si todavia no se han enviado los datos a Orco      
                            giPos=0;                                // Indico el men� de configuraci�n de tratamiento     
                        }                                           // Inicializo giPos                                   
                        break;                                                                                            
                    case CHC_C:                                     // Dependiendo del canal a configurar                 
                        if(i8CanalesConfigurados&CHC_ACT){          // Si estamos configurando el canal C                 
                            if(i8CanalesActivados&CHC_ACT){         // Si se ha configurado y enviado los datos a Orco    
                                if(i8ReposoActivados&CHC_ACT){      // Si se encuentra el canal activado dando tratamiento
                                    iMenuActual=142;                // Si se encuentra el canal en reposo                 
                                }else{                              // Indico el men� de tratamiento en reposo            
                                    iMenuActual=141;                // Si no...                                           
                                }                                   // Indico el men� de tratamiento activo               
                            }else{                                                                                        
                                iMenuActual=140;                    // Si no se encuentra dando tratamiento               
                            }                                       // Indico el men� de tratamiento                      
                        }else{                                                                                            
                            iMenuActual=40;                         // Si todavia no se han enviado los datos a Orco      
                            giPos=0;                                // Indico el men� de configuraci�n de tratamiento     
                        }                                           // Inicializo giPos                                   
                        break;                                                                                            
                    case POINTER_C:                                 // Si estamos configurando el pointer                 
                        if(i8CanalesConfigurados&POINTER_ACT){      // Si se ha configurado y enviado los datos a Orco    
                            if(i8CanalesActivados&POINTER_ACT){     // Si se encuentra el canal activado dando tratamiento
                                iMenuActual=141;                    // Indico el men� de tratamiento activo               
                            }else{                                  // Si no se encuentra dando tratamiento               
                                iMenuActual=140;                    // Indico el men� de tratamiento                      
                            }                                                                                             
                        }else{                                      // Si todavia no se han enviado los datos a Orco      
                            iMenuActual=40;                         // Indico el men� de configuraci�n de tratamiento     
                            giPos=0;                                // Inicializo giPos                                   
                        }
                        
                        break;
                }
            }else if (iMenuActual==0){                                          // Si estamos en el men� principal
                if ((giPos<=5)&&(giPos!=4)){                                    // Miemntras se cumpla esta condici�n (para navegar entre men�s correctamente)...
                    if(giPos==2){                                               // Si seleccionamos galv�nica + microcorrientes
                        giPos=1;                                                // Indico posici�n de galv�nica
                        bSeleccionGalvanica=1;                                  // Indico que se va a utilizar microcorrientes
                    }else if(giPos==1){                                         // Si solo seleccionamos galv�nica
                        bSeleccionGalvanica=0;                                  // Desactivo opci�n de microcorrientes
                    }
                    
                    iMenuActual=10+10*giPos;                                    // Navego al men�seleccionado
                    
                    if(giPos==1 && bSeleccionGalvanica){                        // Si estamos en galv�nica + microcorrientes                  
                        Anterior_giPos[0]=giPos+1;                              // Guardo el valor anterior de giPos
                    }else{                                                      // Si estamos en cualquier otro tratamiento
                        Anterior_giPos[0]=giPos;                                // Guardo el valor anterior de giPos
                    }
                    giPos=0;                                                    // Inicializo giPos
                    
                    if(iMenuActual==20){                                        // Si estamos en el men� de galv�nica
                        giPosRulancha=i16Igalv;                                 // Asigno el valor de corriente a la rulancha
                    }
                }else if(giPos==4){                                             // SI seleccionamos el sistema multipulsos (SMP)
                    iMenuActual=80;                                             // Navego al men� seleccionado
                    Anterior_giPos[0]=giPos;                                    // Guardo el valor anterior de giPos
                    giPos=0;                                                    // Inicializo giPos 
                    giPosRulancha=i16TacSMP/5;                                  // Inicializa el valor de la rulancha
                }
            }else if((iMenuActual%10==0)&&(iMenuActual<90)&&(iMenuActual!=50)){     // Si estamos en un men� principal y el men� es menor o igual a 80...
                if ((giPos==9)&&(iMenuActual==20)||((giPos==6)&&(iMenuActual==30))||((giPos==12)&&(iMenuActual==40))||((giPos==4)&&(iMenuActual==80))){     // Si estamos en la posici�on de Config. Tratamiento...

                    iMenuActual=iMenuActual+100;                                // Navego a ese men�

                    switch(i8ConfigCanal){                                      // Dependiendo del canal que se est� configurando
                        case CHA_C:                                             // Canal A
                            if(i8CanalesConfigurados&POINTER_ACT){              // Si el pointer est� configurado
                               i8CanalesConfigurados&=~POINTER_ACT;             // Elimino la configuraci�n del pointer
                            }                                       
                            i8CanalesConfigurados|=CHA_ACT;                     // Indico que el canal se ha configurado
                            break;
                        case CHB_C:                                             // Canal B
                            i8CanalesConfigurados|=CHB_ACT;                     // Indico que el canal se ha configurado  
                            break;
                        case CHC_C:                                             // Canal C                     
                            i8CanalesConfigurados|=CHC_ACT;                     // Indico que el canal se ha configurado
                            break;
                        case POINTER_C:                                         // Pointer                            
                            if(i8CanalesConfigurados&CHA_ACT){                  // Si el canal A est� configurado     
                               i8CanalesConfigurados&=~CHA_ACT;                 // Elimino la configuraci�n del canal A
                            }
                            i8CanalesConfigurados|=POINTER_ACT;                 // Indico que el canal se ha configurado
                            break;
                    }                                                          
                }else if(iMenuActual==20){                                      // Si el men� es el de galv�nica/galv+micro
                    iMenuActual=iMenuActual+giPos;                              // Navego al men� seleccionado
                }else{                                                          // ...si no es ninguna de las anteriores
                    iMenuActual=iMenuActual+giPos+1;                            // Navego al men� seleccionado
                }
                Anterior_giPos[1]=giPos;                                        // Guardo el valor anterior de giPos
            }else if(iMenuActual>=41 && iMenuActual<=52){                       // Si esta dentro de alg�n men� de electroestimulaci�n
                iMenuActual++;                                                  // Incremento de men� (secuenciales) 
                switch(iMenuActual){                                            // Dependiendo del men� seleccionado
                    case 42:                                                    // Si pasamos de selecci�n del canal a simetria de canales...
                        if(i8ConfigCanal==POINTER_C){                           // Si estamos en el pointer
                            if(i8CanalesActivados&POINTER_ACT){                 // Si esta el pointer activado en tratamiento
                                iMenuActual=141;                                // Ve al men� de tratamiento activo
                            }else if(i8CanalesConfigurados&POINTER_ACT){        // Si solo se encuentra configurado
                                iMenuActual=140;                                // Ve al men� de tratamiento
                            }else{                                              // Si no....
                                iMenuActual=47;                                 // Saltamos al siguiente men� del pointer (I)
                            }
                        }
                        break;
                    case 46:                                                    // N�mero de repeticiones
                        if(i16TdElec[i8ConfigCanal]==0){                        // Si no hay tiempo de descanso definido
                            iMenuActual++;                                      // Aumento de men�, no se pueden configurar repeticiones
                        }
                        break;
                    case 49:                                                    // Si pasamos de la configuraci�n de la frecuencia a polaridad...
                        if(i8ConfigCanal==POINTER_C){                           // Si estamos en el pointer
                            iMenuActual=51;                                     // Saltamos al siguiente men� del pointer (PW)
                        }
                        break;
                    case 50:                                                    // Simetria
                        if(!bPolaridadElec[i8ConfigCanal]){                     // Si la se�al es monopolar
                            iMenuActual++;                                      // Se salta el men� de simetria
                        }
                        break;
                    case 52:                                                    // PW-
                        if(!bPolaridadElec[i8ConfigCanal]){                     // Si la se�al es monopolar
                            iMenuActual=40;                                     // Se salta el men� de PW- y vuelve al principal
                        }else if(bSimetriaElec[i8ConfigCanal]){                 // Si la se�al es sim�trica
                            iMenuActual=40;                                     // Se salta el men� de PW- y vuelve al principal
                        }
                        giPos=12;                                               // Pone la selecci�n en la opci�on de configura tratamiento
                        break;
                    case 53:                                                    // He terminado todos los men�s
                        iMenuActual=40;                                         // Voy al de configuraci�n principal
                        giPos=12;                                               // Pongo cursor sobre la opci�n de Config. Tratamiento
                        break;
                }
                Anterior_giPos[1]=giPos;                                        // Guardo el valor anterior de giPos
            }else if(iMenuActual>=81 && iMenuActual<=84){                       // Si estamos configurando SMP
                iMenuActual++;                                                  // Incremento al siguiente men�
                if(iMenuActual>=85){                                            // Si he llegado al final de los men�s
                    iMenuActual=80;                                             // Voy al de configuraci�n principal                  
                    giPos=4;                                                    // Pongo cursor sobre la opci�n de Config. Tratamiento
                }
                Anterior_giPos[1]=giPos;                                        // Guardo el valor anterior de giPos
            }else if(iMenuActual>=21 && iMenuActual<=31){                       // Si estamos configurando galv�nica/galv+micro
                iMenuActual++;                                                  // Incremento al siguiente men�
                switch(iMenuActual){                                            // Dependiedo del men� en el que est�
                    case 24:                                                    // Si hemos llegado a la �ltima posici�n del men� en galv�nica
                        if(!bSeleccionGalvanica){                               // Si estamos en galv�nica solo
                            iMenuActual=20;                                     // Voy al de configuraci�n principal                  
                            giPos=9;                                            // Pongo cursor sobre la opci�n de Config. Tratamiento
                        }
                        break;
                    case 29:                                                    // Si hemos llegado a la �ltima posici�n del men� en galv�nica+micro
                        iMenuActual=20;                                         // Voy al de configuraci�n principal                  
                        giPos=9;                                                // Pongo cursor sobre la opci�n de Config. Tratamiento
                        break;
                }
                Anterior_giPos[1]=giPos;                                        // Guardo el valor anterior de giPos
            }
            

            if(iMenuActual==181){                                               // Si estamos en el men� de tratamiento de SMP
                bCorrientePulsos=!bCorrientePulsos;                             // Cambia entre configuraci�n de corriente y pulsos
                if(bCorrientePulsos){                                           // Si est� seleccionado pulsos
                    giPos=i8PulsosSMP;                                          // Selecciona el n�mero de pulsos
                }else{                                                          // Si est� seleccionado corriente
                    giPos=i16ISMP;                                              // Selecciona el nivel de corriente
                }
            }
            
            itecla=0;                                                           // Inicializo el valor de tecla
            ControlSonido(0);                                                   // Apago el sonido
        }
        
        // --------------------------------------- TECLA 4 (SELECTOR IZQUIERDA/CANCELAR) -----------------------------------
        
        if (itecla==4){                                                         // Si se ha presionado la tecla 4
            var_puls=4;                                                         // Indicamos que se ha presionado la tecla 4
            iMenuAnterior=iMenuActual;                                          // Guardamos el valor del menu actual en el men� anterior
        
            if((i8CanalesActivados==0)&&((iMenuActual!=141)&&(iMenuActual!=142)&&(iMenuActual!=181)&&(iMenuActual!=121)&&(iMenuActual!=200))){      // Si no est� realizando ningun tratamiento
                var_tiempo=0;                                                   // Reinicia la variable tiempo para el autoapagado
            }
            
            if (iMenuActual<=95){                                               // Si no estamos en ning�n men� de tratamiento
                if((iMenuActual%10==0)&&(iMenuActual<70)&&!(iMenuActual==50)){  // Si estamos dentro de un men� principal 
                    if(iMenuActual==40 && i8CanalesActivados!=0){               // Si ya est� en el menu 40 e intenta ir al menu principal cuando hay un tratamiento activo
                        if(i8ConfigCanal!=CHA_C){                               // Si el canal a configurar es distinto del primero (A)  - Men� de salto entre canales              
                            i8ConfigCanal--;                                    // Voy al canalanterior
                            if(bPointerSeleccionado && i8ConfigCanal==CHA_C){   // Si el pointer est� seleccionado y se quiere configurar el A
                                i8ConfigCanal=POINTER_C;                        // Salta al pointer
                            }else if(!bPointerSeleccionado && i8ConfigCanal==POINTER_C){    // Si se quiere configurar el pointer y est� el canal A configurado
                                i8ConfigCanal=CHC_C;                            // Salta al canal C
                            }
                        }else{                                                  // Si el canal a configurar es el A
                            i8ConfigCanal=CHC_C;                                // Salto al C 
                        }                                               
                        
                        switch(i8ConfigCanal){                                  // Dependiendo del canal a configurar
                            case CHA_C:                                         // Si estamos configurando el canal A                 
                                if(i8CanalesConfigurados&CHA_ACT){              // Si se ha configurado y enviado los datos a Orco    
                                    if(i8CanalesActivados&CHA_ACT){             // Si se encuentra el canal activado dando tratamiento
                                        if(i8ReposoActivados&CHA_ACT){          // Si se encuentra el canal en reposo                 
                                            iMenuActual=142;                    // Indico el men� de tratamiento en reposo            
                                        }else{                                  // Si no...                                           
                                            iMenuActual=141;                    // Indico el men� de tratamiento activo               
                                        }                                                      
                                    }else{                                      // Si no se encuentra dando tratamiento               
                                        iMenuActual=140;                        // Indico el men� de tratamiento                                                             
                                    }                                                
                                }else{                                          // Si todavia no se han enviado los datos a Orco      
                                    iMenuActual=40;                             // Indico el men� de configuraci�n de tratamiento     
                                    giPos=0;                                    // Inicializo giPos                              
                                }
                                break;
                            case CHB_C:                                         // Dependiendo del canal a configurar                 
                                if(i8CanalesConfigurados&CHB_ACT){              // Si estamos configurando el canal B                 
                                    if(i8CanalesActivados&CHB_ACT){             // Si se ha configurado y enviado los datos a Orco    
                                        if(i8ReposoActivados&CHB_ACT){          // Si se encuentra el canal activado dando tratamiento
                                            iMenuActual=142;                    // Si se encuentra el canal en reposo                 
                                        }else{                                  // Indico el men� de tratamiento en reposo            
                                            iMenuActual=141;                    // Si no...                                           
                                        }                                       // Indico el men� de tratamiento activo               
                                    }else{                                                                                            
                                        iMenuActual=140;                        // Si no se encuentra dando tratamiento               
                                    }                                           // Indico el men� de tratamiento                      
                                }else{                                                                                                
                                    iMenuActual=40;                             // Si todavia no se han enviado los datos a Orco      
                                    giPos=0;                                    // Indico el men� de configuraci�n de tratamiento     
                                }                                               // Inicializo giPos                                   
                                break;
                            case CHC_C:                                         // Dependiendo del canal a configurar                 
                                if(i8CanalesConfigurados&CHC_ACT){              // Si estamos configurando el canal C                 
                                    if(i8CanalesActivados&CHC_ACT){             // Si se ha configurado y enviado los datos a Orco    
                                        if(i8ReposoActivados&CHC_ACT){          // Si se encuentra el canal activado dando tratamiento
                                            iMenuActual=142;                    // Si se encuentra el canal en reposo                 
                                        }else{                                  // Indico el men� de tratamiento en reposo            
                                            iMenuActual=141;                    // Si no...                                           
                                        }                                       // Indico el men� de tratamiento activo               
                                    }else{                                                                                            
                                        iMenuActual=140;                        // Si no se encuentra dando tratamiento               
                                    }                                           // Indico el men� de tratamiento                      
                                }else{                                                                                                
                                    iMenuActual=40;                             // Si todavia no se han enviado los datos a Orco      
                                    giPos=0;                                    // Indico el men� de configuraci�n de tratamiento     
                                }                                               // Inicializo giPos                                   
                                break;
                            case POINTER_C:                                     // Si estamos configurando el pointer                 
                                if(i8CanalesConfigurados&POINTER_ACT){          // Si se ha configurado y enviado los datos a Orco    
                                    if(i8CanalesActivados&POINTER_ACT){         // Si se encuentra el canal activado dando tratamiento
                                        iMenuActual=141;                        // Indico el men� de tratamiento activo               
                                    }else{                                      // Si no se encuentra dando tratamiento               
                                        iMenuActual=140;                        // Indico el men� de tratamiento                      
                                    }                                                                                                 
                                }else{                                          // Si todavia no se han enviado los datos a Orco      
                                    iMenuActual=40;                             // Indico el men� de configuraci�n de tratamiento     
                                    giPos=0;                                    // Inicializo giPos                                   
                                }
                                break;
                        }
                    }else{                                                      // Si no estamos en el men� principal de configuraci�n de electroestimulaci�n
                        iMenuActual=0;                                          // Voy al men� principal
                        giPos=Anterior_giPos[0];                                // Recupero el valor de giPos guardado
                        Anterior_giPos[0]=0;                                    // Inicializo el anterior giPos
                        Anterior_giPos[1]=0;                                    // Inicializo el anterior giPos
                    }
                }else if ((iMenuActual>=70)&&(iMenuActual<76)){                 // ...si est� entre  70 y 76 (men�s de test)...
                    iMenuActual=60;                                             // Vuelvo al men� 60
                    giPos=Anterior_giPos[1];                                    // Recupero giPos anterior
                }else if(iMenuActual==80){                                      // Si estoy en el men� 80 (config SMP)
                    iMenuActual=0;                                              // Voy al men� principal
                    giPos=Anterior_giPos[0];                                    // Recupero el valor de giPos guardado
                    Anterior_giPos[0]=0;                                        // Inicializo el anterior giPos
                    Anterior_giPos[1]=0;                                        // Inicializo el anterior giPos
                }else if(iMenuActual>80 && iMenuActual<85){                     // Si est� entre los men�s de SMP
                    giPos=iMenuActual-80-1;                                     // Recupera el valor de giPos
                    iMenuActual=80;                                             // Selecciona el men� 80
                }else{                                                          // ...si no es ninguna de las anteriores condiciones
                    if(iMenuActual==12){                                        // Si estamos saliendo del men� de configuraci�n del pito
                        setup_ccp7(CCP_OFF);                                    // Apaga el modulaador del pito
                    }

                    if((iMenuActual==40) && i8CanalesActivados!=0){             // Si ya est� en el menu 40 e intenta ir al menu principal cuando hay un tratamiento activo
                        (i8ConfigCanal==0)? (i8ConfigCanal=3) : (i8ConfigCanal--);  // No nos pasemos de 3 canales!
     
                        if(bPointerSeleccionado && i8ConfigCanal==CHA_C){       // Si est� el pointer seleccionado y queremos configurar el canal A
                            i8ConfigCanal=POINTER_C;                            // Salta al pointer
                        }else if(!bPointerSeleccionado && i8ConfigCanal==POINTER_C){    // Si estamos en el pointer sin estar configurado y queremos ir atr�s
                            i8ConfigCanal=CHC_C;                                // Salta al canal C
                        }
                        
                        switch(i8ConfigCanal){                              // Dependiendo del canal a configurar                 
                            case CHA_C:                                     // Si estamos configurando el canal A                 
                                if(i8CanalesConfigurados&CHA_ACT){          // Si se ha configurado y enviado los datos a Orco    
                                    if(i8CanalesActivados&CHA_ACT){         // Si se encuentra el canal activado dando tratamiento
                                        if(i8ReposoActivados&CHA_ACT){      // Si se encuentra el canal en reposo                 
                                            iMenuActual=142;                // Indico el men� de tratamiento en reposo            
                                        }else{                              // Si no...                                           
                                            iMenuActual=141;                // Indico el men� de tratamiento activo               
                                        }                                                                                         
                                    }else{                                  // Si no se encuentra dando tratamiento               
                                        iMenuActual=140;                    // Indico el men� de tratamiento                      
                                    }                                                                                             
                                }else{                                      // Si todavia no se han enviado los datos a Orco      
                                    iMenuActual=40;                         // Indico el men� de configuraci�n de tratamiento     
                                    giPos=0;                                // Inicializo giPos                                   
                                }                                                                                                 
                                break;                                                                                            
                            case CHB_C:                                     // Dependiendo del canal a configurar                 
                                if(i8CanalesConfigurados&CHB_ACT){          // Si estamos configurando el canal B                 
                                    if(i8CanalesActivados&CHB_ACT){         // Si se ha configurado y enviado los datos a Orco    
                                        if(i8ReposoActivados&CHB_ACT){      // Si se encuentra el canal activado dando tratamiento
                                            iMenuActual=142;                // Si se encuentra el canal en reposo                 
                                        }else{                              // Indico el men� de tratamiento en reposo            
                                            iMenuActual=141;                // Si no...                                           
                                        }                                   // Indico el men� de tratamiento activo               
                                    }else{                                                                                        
                                        iMenuActual=140;                    // Si no se encuentra dando tratamiento               
                                    }                                       // Indico el men� de tratamiento                      
                                }else{                                                                                            
                                    iMenuActual=40;                         // Si todavia no se han enviado los datos a Orco      
                                    giPos=0;                                // Indico el men� de configuraci�n de tratamiento     
                                }                                           // Inicializo giPos                                   
                                break;                                                                                            
                            case CHC_C:                                     // Dependiendo del canal a configurar                 
                                if(i8CanalesConfigurados&CHC_ACT){          // Si estamos configurando el canal C                 
                                    if(i8CanalesActivados&CHC_ACT){         // Si se ha configurado y enviado los datos a Orco    
                                        if(i8ReposoActivados&CHC_ACT){      // Si se encuentra el canal activado dando tratamiento
                                            iMenuActual=142;                // Si se encuentra el canal en reposo                 
                                        }else{                              // Indico el men� de tratamiento en reposo            
                                            iMenuActual=141;                // Si no...                                           
                                        }                                   // Indico el men� de tratamiento activo               
                                    }else{                                                                                        
                                        iMenuActual=140;                    // Si no se encuentra dando tratamiento               
                                    }                                       // Indico el men� de tratamiento                      
                                }else{                                                                                            
                                    iMenuActual=40;                         // Si todavia no se han enviado los datos a Orco      
                                    giPos=0;                                // Indico el men� de configuraci�n de tratamiento     
                                }                                           // Inicializo giPos                                   
                                break;                                                                                            
                            case POINTER_C:                                 // Si estamos configurando el pointer                 
                                if(i8CanalesConfigurados&POINTER_ACT){      // Si se ha configurado y enviado los datos a Orco    
                                    if(i8CanalesActivados&POINTER_ACT){     // Si se encuentra el canal activado dando tratamiento
                                        iMenuActual=141;                    // Indico el men� de tratamiento activo               
                                    }else{                                  // Si no se encuentra dando tratamiento               
                                        iMenuActual=140;                    // Indico el men� de tratamiento                      
                                    }                                                                                             
                                }else{                                      // Si todavia no se han enviado los datos a Orco      
                                    iMenuActual=40;                         // Indico el men� de configuraci�n de tratamiento     
                                    giPos=0;                                // Inicializo giPos                                   
                                }
                                
                                break;
                        }
                    }else if(iMenuActual==41){
                        switch(i8ConfigCanal){                              // Dependiendo del canal a configurar                 
                            case CHA_C:                                     // Si estamos configurando el canal A                 
                                if(i8CanalesConfigurados&CHA_ACT){          // Si se ha configurado y enviado los datos a Orco    
                                    if(i8CanalesActivados&CHA_ACT){         // Si se encuentra el canal activado dando tratamiento
                                        if(i8ReposoActivados&CHA_ACT){      // Si se encuentra el canal en reposo                 
                                            iMenuActual=142;                // Indico el men� de tratamiento en reposo            
                                        }else{                              // Si no...                                           
                                            iMenuActual=141;                // Indico el men� de tratamiento activo               
                                        }                                                                                         
                                    }else{                                  // Si no se encuentra dando tratamiento               
                                        iMenuActual=140;                    // Indico el men� de tratamiento                      
                                    }                                                                                             
                                }else{                                      // Si todavia no se han enviado los datos a Orco      
                                    iMenuActual=40;                         // Indico el men� de configuraci�n de tratamiento     
                                    giPos=0;                                // Inicializo giPos                                   
                                }                                                                                                 
                                break;                                                                                            
                            case CHB_C:                                     // Dependiendo del canal a configurar                 
                                if(i8CanalesConfigurados&CHB_ACT){          // Si estamos configurando el canal B                 
                                    if(i8CanalesActivados&CHB_ACT){         // Si se ha configurado y enviado los datos a Orco    
                                        if(i8ReposoActivados&CHB_ACT){      // Si se encuentra el canal activado dando tratamiento
                                            iMenuActual=142;                // Si se encuentra el canal en reposo                 
                                        }else{                              // Indico el men� de tratamiento en reposo            
                                            iMenuActual=141;                // Si no...                                           
                                        }                                   // Indico el men� de tratamiento activo               
                                    }else{                                                                                        
                                        iMenuActual=140;                    // Si no se encuentra dando tratamiento               
                                    }                                       // Indico el men� de tratamiento                      
                                }else{                                                                                            
                                    iMenuActual=40;                         // Si todavia no se han enviado los datos a Orco      
                                    giPos=0;                                // Indico el men� de configuraci�n de tratamiento     
                                }                                           // Inicializo giPos                                   
                                break;                                                                                            
                            case CHC_C:                                     // Dependiendo del canal a configurar                 
                                if(i8CanalesConfigurados&CHC_ACT){          // Si estamos configurando el canal C                 
                                    if(i8CanalesActivados&CHC_ACT){         // Si se ha configurado y enviado los datos a Orco    
                                        if(i8ReposoActivados&CHC_ACT){      // Si se encuentra el canal activado dando tratamiento
                                            iMenuActual=142;                // Si se encuentra el canal en reposo                 
                                        }else{                              // Indico el men� de tratamiento en reposo            
                                            iMenuActual=141;                // Si no...                                           
                                        }                                   // Indico el men� de tratamiento activo               
                                    }else{                                                                                        
                                        iMenuActual=140;                    // Si no se encuentra dando tratamiento               
                                    }                                       // Indico el men� de tratamiento                      
                                }else{                                                                                            
                                    iMenuActual=40;                         // Si todavia no se han enviado los datos a Orco      
                                    giPos=0;                                // Indico el men� de configuraci�n de tratamiento     
                                }                                           // Inicializo giPos                                   
                                break;                                                                                            
                            case POINTER_C:                                 // Si estamos configurando el pointer                 
                                if(i8CanalesConfigurados&POINTER_ACT){      // Si se ha configurado y enviado los datos a Orco    
                                    if(i8CanalesActivados&POINTER_ACT){     // Si se encuentra el canal activado dando tratamiento
                                        iMenuActual=141;                    // Indico el men� de tratamiento activo               
                                    }else{                                  // Si no se encuentra dando tratamiento               
                                        iMenuActual=140;                    // Indico el men� de tratamiento                      
                                    }                                                                                             
                                }else{                                      // Si todavia no se han enviado los datos a Orco      
                                    iMenuActual=40;                         // Indico el men� de configuraci�n de tratamiento     
                                    giPos=0;                                // Inicializo giPos                                   
                                }
                                
                                break;
                        }
                    }else if(iMenuActual>=41 && iMenuActual<=52){       // Si esta dentro de alg�n men� de electroestimulaci�n
                        giPos=iMenuActual-40-1;                         // Actualizo el valor de giPos
                        iMenuActual=40;                                 // Vuelvo al men� de configuraci�n
                    }else if(iMenuActual>=21 && iMenuActual<=28){       // Si esta dentro de alg�n men� de galv�nica/galv+micro
                        giPos=iMenuActual-20;                           // Actualizo el valor de giPos                        
                        iMenuActual=20;                                 // Vuelvo al men� de configuraci�n                    
                    }else{                                              // Para los otros casos....
                        aux_m=iMenuActual/10;                           // Vuelvo al men� raiz del que proviene el men� actual
                        iMenuActual=aux_m*10;                           // Aprovecho variable entera para volver la men� raiz
                    }
                }
            }else if ((iMenuActual>100)&&(iMenuActual%10==0)){          // Si estamos en un men� mayor de 100 (tratamiento) que sea principal (ej: config. tratamiento electroestimulaci�n)
                iMenuActual-=100;                                       // Restamos 100 para volver al raiz de ese men�
                giPos=0;                                                // Inicializamos giPos
                switch(i8ConfigCanal){                                  // Dependiedo del canal que estemos configurando
                    case CHA_C:                                         // Canal A
                        i8CanalesConfigurados&=~CHA_ACT;                // Inicializo el valor de canal configurado
                        break;
                    case CHB_C:                                         // Canal B                                  
                        i8CanalesConfigurados&=~CHB_ACT;                // Inicializo el valor de canal configurado
                        break;
                    case CHC_C:                                         // Canal C                                  
                        i8CanalesConfigurados&=~CHC_ACT;                // Inicializo el valor de canal configurado
                        break;
                    case POINTER_C:                                     // Pointer                                   
                        i8CanalesConfigurados&=~POINTER_ACT;            // Inicializo el valor de canal configurado
                        break;
                }
            }else if((iMenuActual==141||iMenuActual==142) && i8CanalesActivados!=0){    // Si ya est� en el menu 40 e intenta ir al menu principal cuando hay un tratamiento activo

                (i8ConfigCanal==0)? (i8ConfigCanal=3) : (i8ConfigCanal--);  // No nos pasemos de 3 canales!                                          
                                                                                                                                                     
                if(bPointerSeleccionado && i8ConfigCanal==CHA_C){       // Si est� el pointer seleccionado y queremos configurar el canal A          
                    i8ConfigCanal=POINTER_C;                            // Salta al pointer                                                          
                }else if(!bPointerSeleccionado && i8ConfigCanal==POINTER_C){    // Si estamos en el pointer sin estar configurado y queremos ir atr�s
                    i8ConfigCanal=CHC_C;                                // Salta al canal C                                                          
                }                                                                                                                                    

                switch(i8ConfigCanal){                                          // Dependiendo del canal a configurar                 
                    case CHA_C:                                                 // Si estamos configurando el canal A                 
                        if(i8CanalesConfigurados&CHA_ACT){                      // Si se ha configurado y enviado los datos a Orco    
                            if(i8CanalesActivados&CHA_ACT){                     // Si se encuentra el canal activado dando tratamiento
                                if(i8ReposoActivados&CHA_ACT){                  // Si se encuentra el canal en reposo                 
                                    iMenuActual=142;                            // Indico el men� de tratamiento en reposo            
                                }else{                                          // Si no...                                           
                                    iMenuActual=141;                            // Indico el men� de tratamiento activo     
                                }
                            }else{                                                                                                    
                                iMenuActual=140;                                // Si no se encuentra dando tratamiento               
                            }                                                   // Indico el men� de tratamiento                      
                        }else{                                                                                                        
                            iMenuActual=40;                                     // Si todavia no se han enviado los datos a Orco      
                            giPos=0;                                            // Indico el men� de configuraci�n de tratamiento     
                        }                                                       // Inicializo giPos                                   
                        break;                                                                                                        
                    case CHB_C:                                                                                                       
                        if(i8CanalesConfigurados&CHB_ACT){                      // Dependiendo del canal a configurar                 
                            if(i8CanalesActivados&CHB_ACT){                     // Si estamos configurando el canal B                 
                                if(i8ReposoActivados&CHB_ACT){                  // Si se ha configurado y enviado los datos a Orco    
                                    iMenuActual=142;                            // Si se encuentra el canal activado dando tratamiento
                                }else{                                          // Si se encuentra el canal en reposo                 
                                    iMenuActual=141;                            // Indico el men� de tratamiento en reposo            
                                }                                               // Si no...                                           
                            }else{                                              // Indico el men� de tratamiento activo               
                                iMenuActual=140;                                                                                      
                            }                                                   // Si no se encuentra dando tratamiento               
                        }else{                                                  // Indico el men� de tratamiento                      
                            iMenuActual=40;                                                                                           
                            giPos=0;                                            // Si todavia no se han enviado los datos a Orco      
                        }                                                       // Indico el men� de configuraci�n de tratamiento     
                        break;                                                  // Inicializo giPos                                   
                    case CHC_C:                                                                                                       
                        if(i8CanalesConfigurados&CHC_ACT){                      // Dependiendo del canal a configurar                 
                            if(i8CanalesActivados&CHC_ACT){                     // Si estamos configurando el canal C                 
                                if(i8ReposoActivados&CHC_ACT){                  // Si se ha configurado y enviado los datos a Orco    
                                    iMenuActual=142;                            // Si se encuentra el canal activado dando tratamiento
                                }else{                                          // Si se encuentra el canal en reposo                 
                                    iMenuActual=141;                            // Indico el men� de tratamiento en reposo            
                                }                                               // Si no...                                           
                            }else{                                              // Indico el men� de tratamiento activo               
                                iMenuActual=140;                                                                                      
                            }                                                   // Si no se encuentra dando tratamiento               
                        }else{                                                  // Indico el men� de tratamiento                      
                            iMenuActual=40;                                                                                           
                            giPos=0;                                            // Si todavia no se han enviado los datos a Orco      
                        }                                                       // Indico el men� de configuraci�n de tratamiento     
                        break;                                                  // Inicializo giPos                                   
                    case POINTER_C:                                                                                                   
                        if(i8CanalesConfigurados&POINTER_ACT){                  // Si estamos configurando el pointer                 
                            if(i8CanalesActivados&POINTER_ACT){                 // Si se ha configurado y enviado los datos a Orco    
                                iMenuActual=141;                                // Si se encuentra el canal activado dando tratamiento
                            }else{                                              // Indico el men� de tratamiento activo               
                                iMenuActual=140;                                // Si no se encuentra dando tratamiento               
                            }                                                   // Indico el men� de tratamiento                      
                        }else{                                                                                                        
                            iMenuActual=40;                                     // Si todavia no se han enviado los datos a Orco      
                            giPos=0;                                            // Indico el men� de configuraci�n de tratamiento     
                        }                                                       // Inicializo giPos                                   
                        
                        break;
                }
            }
            
            itecla=0;                                                           // Inicializamos el valor de tecla
            ControlSonido(0);                                                   // Apago el sonido
        }
        
        // --------------------------------------- TECLA 5 (SELECCTOR START/STOP) ----------------------------------- 
        
        if (itecla==5){                                                         // Si se ha presionado la tecla 5
            
            if((i8CanalesActivados==0)&&((iMenuActual!=141)&&(iMenuActual!=142)&&(iMenuActual!=181)&&(iMenuActual!=121))){      // Si no est� realizando ningun tratamiento
                var_tiempo=0;                                                   // Reinicia la variable tiempo para el autoapagado
            }
            
            if(iMenuActual==200){                                               // Proceso de autoapagado
                iMenuActual=iMenuReposo;                                        // Indico que voy al men� del que proven�a antes de estar en la pantalla de cuenta atr�s de autoapagado
                var_tiempo=0;                                                   // Inicializo la variable de tiempo
                itecla=0;                                                       // Inicializamos el valor de tecla
            }else{                                                              // Si no estamos en autoapagado...
                i32TiempoComunicaciones=0;                                      // Reinicio el contador de timeout de comunicaciones
                if(!bAguantaEnvio){                                             // Mientras que pueda enviar el paquete sin que haya colisiones...
                    bPrimeraMedida=0;                                           // Reinicia el flag de primera medida obtenida
                    switch(iMenuActual){                                        // Dependiendo del men� en el que se encuentre...
                        case 120:                                               // Tratamiento galvanica
                            iMenuActual=121;                                    // Voy el men� 121 (Activo el tratamiento)
                            
                            if(bPausaTratamiento){                              // Si se entra a pausar el tratamiento
                                bPausaTratamiento=0;                            // Reinicio el flag         
                            }else{                                              // Si no se encontraba pausado...
                                bTerapia=0;                                     // Indico que se empieza por galv�nica
                                if(i16Tgalv!=0){                                // Si el tiempo de tratamiento es finito
                                    i16TimeRaw[0]=i16Tgalv+i8TrampaGalv;        // Inicializo las variables de tiempo
                                    i32CargaGalvanicaRestante=i32Cgalv+i16CRampaGalv;   // Inicializo la variable de carga
                                }else{                                          // Si el tiempo es infinito
                                    i16TimeRaw[0]=0;                            // Inicializamos la variable de tiempo a 0
                                }
                            }
                            
                            if(!bPausaTratamiento){                             // Si el tratamiento empieza de cero
                                envioTratamiento(MODO_START_STOP,COMANDO_START);    // Envia el comando       
                            }else{                                              // Si el tratamiento entra en pausa
                                envioTratamiento(MODO_START_STOP,COMANDO_STOP_PAUSA);   // Envia el comando   
                            }
                            
                            control_led(1,verde,led_GALV);                      // Enciende LED galv�nica
                            
                            if(!bTerapia){                                      // Si empieza en galv�nica
                                bTratamientoGalvanicaActivado=1;                // Indica que se ha iniciado el tratamiento galv�nico
                            }else{                                              // Si empieza en microcorrientes
                                bMicrocorrientesEncendido=1;                    // Indica que se ha iniciado el tratamiento de microcorrientes   
                            }
                            break;
                        case 121:                                               // Tratamiento activo galv�nica
                            
                            if(!bPausaTratamiento){                                 // Si el tratamiento empieza de cero
                                i16Tgalv=calc_Tgalv(i32Cgalv,i16Igalv);             // Inicializo variables de tiempo
                                i16TimeRaw[0]=i16Tgalv+i8TrampaGalv;                // Inicializo variables de tiempo 
                                i32CargaGalvanicaRestante=i32Cgalv+i16CRampaGalv;   // Inicializo variable de carga
                                envioTratamiento(MODO_START_STOP,COMANDO_STOP);     // Envia el comando       
                                apagadoMicrocorrientes();
                            }else{                                                  // Si el tratamiento entra en pausa
                                envioTratamiento(MODO_START_STOP,COMANDO_START_PAUSA);  // Envia el comando   
                                apagadoGalvanica();
                            }
                            
                            iMenuActual=120;                                        // Vuelvo al men� 120 (Paro el tartamiento)
                            break;
                        case 123:                                                   // Error electrodo tratamiento galv�nica

                            envioTratamiento(MODO_START_STOP,COMANDO_STOP);         // Envio comando                     
                            
                            apagadoMicrocorrientes();                               // Apagado de los canales                 
                            bTratamientoGalvanicaActivado=0;                        // Inicializaci�n de las variables de tratamiento y reposo activado
    
                            iMenuActual=120;                                        // Vuelvo al men� 120 (Paro el tartamiento)
                            break;
                        case 40:                                                    // Electroestimulaci�n + pointer
                        case 41:                                                    // Sea cual sea el men� en el que se encuentre, 
                        case 42:                                                    // debe de poder hacer caso al boton de pausa
                        case 43:
                        case 44:
                        case 45:
                        case 46:
                        case 47:
                        case 48:
                        case 49:
                        case 50:
                        case 51:
                        case 52:
                            if(bPausaTratamiento){                                  // Si se entra en pausa
                                bPausaTratamiento=0;                                // Inicializo la variable de pausa
                                
                                if(i8CanalesActivados&CANALES_A){                   // Si este canal se encuentra activado
                                    i8CanalesActivados&=~CHA_ACT;                   // Lo desactivo
                                    apagadoCHA();                                   // Inicializo/apago el canal
                                    control_led(0,verde,led_CHA);                   // Apago el LED verde
                                }
                                if(i8CanalesActivados&CANALES_B){                   // Si este canal se encuentra activado
                                    i8CanalesActivados&=~CHB_ACT;                   // Lo desactivo                       
                                    apagadoCHB();                                   // Inicializo/apago el canal          
                                    control_led(0,verde,led_CHB);                   // Apago el LED verde                 
                                }
                                if(i8CanalesActivados&CANALES_C){                   // Si este canal se encuentra activado
                                    i8CanalesActivados&=~CHC_ACT;                   // Lo desactivo                       
                                    apagadoCHC();                                   // Inicializo/apago el canal          
                                    control_led(0,verde,led_CHC);                   // Apago el LED verde                 
                                }
                                if(i8CanalesActivados&CANALES_P){                   // Si este canal se encuentra activado
                                    i8CanalesActivados&=~POINTER_ACT;               // Lo desactivo                       
                                    apagadoCHA();                                   // Inicializo/apago el canal          
                                    control_led(0,verde,led_CHA);                   // Apago el LED verde                 
                                }
                               
                                envioTratamiento(MODO_START_STOP,COMANDO_START_PAUSA);  // Envio comando  
                            }
                            break;
                        case 140:                                                   // Tratamiento electroestimulaci�n
                            bPrimeraMedida=0;
                            if(bPausaTratamiento && i8CanalesActivados!=0){         // 
                                bPausaTratamiento=0;
                                
                                if(i8CanalesActivados&CANALES_A){                   // Si este canal se encuentra activado
                                    i8CanalesActivados&=~CHA_ACT;                   // Lo desactivo                       
                                    apagadoCHA();                                   // Inicializo/apago el canal          
                                    control_led(0,verde,led_CHA);                   // Apago el LED verde                 
                                }
                                if(i8CanalesActivados&CANALES_B){                   // Si este canal se encuentra activado
                                    i8CanalesActivados&=~CHB_ACT;                   // Lo desactivo                       
                                    apagadoCHB();                                   // Inicializo/apago el canal          
                                    control_led(0,verde,led_CHB);                   // Apago el LED verde                 
                                }
                                if(i8CanalesActivados&CANALES_C){                   // Si este canal se encuentra activado
                                    i8CanalesActivados&=~CHC_ACT;                   // Lo desactivo                       
                                    apagadoCHC();                                   // Inicializo/apago el canal          
                                    control_led(0,verde,led_CHC);                   // Apago el LED verde                 
                                }
                                if(i8CanalesActivados&CANALES_P){                   // Si este canal se encuentra activado
                                    i8CanalesActivados&=~POINTER_ACT;               // Lo desactivo                       
                                    apagadoCHA();                                   // Inicializo/apago el canal          
                                    control_led(0,verde,led_CHA);                   // Apago el LED verde                 
                                }

                                envioTratamiento(MODO_START_STOP,COMANDO_START_PAUSA);  // Envio comando 
                            }else{
                                iMenuActual=141;                                    // Voy el men� 141 (Activo el tratamiento)
                                bPausaTratamiento=0;                                // Inicializo la variable de pausa
                                
                                switch(i8ConfigCanal){                              // Dependiendo del canal seleccionado
                                    case CHA_C:                                     // Canal A
                                        i8CanalesActivados|=CHA_ACT;                // Activo el canal
                                        control_led(1,verde,led_CHA);               // Enciendo el LED verde
                                        break;
                                    case CHB_C:                                     // Canal B              
                                        i8CanalesActivados|=CHB_ACT;                // Activo el canal      
                                        control_led(1,verde,led_CHB);               // Enciendo el LED verde
                                        break;
                                    case CHC_C:                                     // Canal C              
                                        i8CanalesActivados|=CHC_ACT;                // Activo el canal      
                                        control_led(1,verde,led_CHC);               // Enciendo el LED verde
                                        break;
                                    case POINTER_C:                                 // Pointer              
                                        i8CanalesActivados|=POINTER_ACT;            // Activo el canal      
                                        control_led(1,verde,led_CHA);               // Enciendo el LED verde
                                        break;
                                }
                                
                                envioTratamiento(MODO_START_STOP,COMANDO_START);    // Envia el comando                                                                

                                bReposoActivado=0;                                  // Inicializa variable de reposo
                            }
                            break;
                        case 141:                                                   // Tratamiento electroestimulaci�n activo
                            i16TimeRepRaw[i8ConfigCanal]=i16TdElec[i8ConfigCanal];  // Inicializo variable tiempo de descanso
                            i16TimeRaw[i8ConfigCanal]=i16TacElec[i8ConfigCanal];    // Inicializo variable tiempo activo
                            i8NrepRaw[i8ConfigCanal]=i8Nrep[i8ConfigCanal];         // Inicializo el n�mero de repeticiones
                        
                            if(!bPausaTratamiento){                                 // Si el tratamiento no est� en pausa
                                switch(i8ConfigCanal){                              // Dependiendo del canal seleccionado
                                    case CHA_C:                                     // Canal A
                                        i8CanalesActivados&=~CHA_ACT;               // Desactivo el canal
                                        apagadoCHA();                               // Inicializo/apago el canal
                                        control_led(0,verde,led_CHA);               // Apago el LED verde
                                        break;
                                    case CHB_C:                                     // Canal B                 
                                        i8CanalesActivados&=~CHB_ACT;               // Desactivo el canal       
                                        apagadoCHB();                               // Inicializo/apago el canal
                                        control_led(0,verde,led_CHB);               // Apago el LED verde       
                                        break;
                                    case CHC_C:                                     // Canal C                  
                                        i8CanalesActivados&=~CHC_ACT;               // Desactivo el canal       
                                        apagadoCHC();                               // Inicializo/apago el canal
                                        control_led(0,verde,led_CHC);               // Apago el LED verde       
                                        break;
                                    case POINTER_C:                                 // Pointer                  
                                        i8CanalesActivados&=~POINTER_ACT;           // Desactivo el canal       
                                        apagadoCHA();                               // Inicializo/apago el canal
                                        control_led(0,verde,led_CHA);               // Apago el LED verde       
                                        break;
                                }
                                
                                if(i16IElec[i8ConfigCanal]>=20){                    // Si la corriente de tratamiento al apagar el mayor o igual a (20*50 = 1000uA = 1mA)
                                    i16IElec[i8ConfigCanal]=20;                     // Pone como valor m�ximo 1mA
                                    giPos=20;                                       // Inicializo a ese valor el valor de giPos
                                }
                            }else{                                                  // Si pausamos el canal
                                if(i8CanalesActivados&CANALES_A){                   // Si este canal se encuentra activado 
                                    i8CanalesActivados&=~CHA_ACT;                   // Lo desactivo                        
                                    apagadoCHA();                                   // Inicializo/apago el canal           
                                    control_led(0,verde,led_CHA);                   // Apago el LED verde                   
                                }                                                                                          
                                if(i8CanalesActivados&CANALES_B){                   // Si este canal se encuentra activado 
                                    i8CanalesActivados&=~CHB_ACT;                   // Lo desactivo                        
                                    apagadoCHB();                                   // Inicializo/apago el canal           
                                    control_led(0,verde,led_CHB);                   // Apago el LED verde                   
                                }                                                                                          
                                if(i8CanalesActivados&CANALES_C){                   // Si este canal se encuentra activado 
                                    i8CanalesActivados&=~CHC_ACT;                   // Lo desactivo                        
                                    apagadoCHC();                                   // Inicializo/apago el canal           
                                    control_led(0,verde,led_CHC);                   // Apago el LED verde                   
                                }                                                                                          
                                if(i8CanalesActivados&CANALES_P){                   // Si este canal se encuentra activado 
                                    i8CanalesActivados&=~POINTER_ACT;               // Lo desactivo                        
                                    apagadoCHA();                                   // Inicializo/apago el canal           
                                    control_led(0,verde,led_CHA);                   // Apago el LED verde                   
                                }                                                                                          
                            }
                            structMedidasElectro.si16IMedElec[i8ConfigCanal][PULSO_POS]=0;  // Inicializamos las variable de corriente de la esctructura de datos
                            structMedidasElectro.si16IMedElec[i8ConfigCanal][PULSO_NEG]=0;  // Inicializamos las variable de corriente de la esctructura de datos

                            if(!bPausaTratamiento){                                 // Si no estamos pausando el tratamiento
                                envioTratamiento(MODO_START_STOP,COMANDO_STOP);     // Envia el comando                                                              
                            }else{                                                  // Si estamos pausando el tratamiento...
                                envioTratamiento(MODO_START_STOP,COMANDO_START_PAUSA);  // Envia el comando
                            }
                            
                            bReposoActivado=0;                                      // Inicializa variables de reposo activado
                            iMenuActual=140;                                        // Vuelvo al men� 140 (Paro el tartamiento)
                            break;
                        case 142:                                                   // Tratamiento electroestimulaci�n activo (reposo)
                            i16TimeRepRaw[i8ConfigCanal]=i16TdElec[i8ConfigCanal];  // Inicializo variable tiempo de descanso
                            i16TimeRaw[i8ConfigCanal]=i16TacElec[i8ConfigCanal];    // Inicializo variable tiempo activo
                            i8NrepRaw[i8ConfigCanal]=i8Nrep[i8ConfigCanal];         // Inicializo el n�mero de repeticiones
        
                            if(!bPausaTratamiento){                                 // Si no estamos pausando el tratamiento
                                switch(i8ConfigCanal){                              // Dependiendo del canal seleccionado
                                    case CHA_C:                                     // Canal A                           
                                        i8CanalesActivados&=~CHA_ACT;               // Desactivo el canal                
                                        apagadoCHA();                               // Inicializo/apago el canal         
                                        control_led(0,verde,led_CHA);               // Apago el LED verde                
                                        break;                                                                           
                                    case CHB_C:                                     // Canal B                           
                                        i8CanalesActivados&=~CHB_ACT;               // Desactivo el canal                
                                        apagadoCHB();                               // Inicializo/apago el canal         
                                        control_led(0,verde,led_CHB);               // Apago el LED verde                
                                        break;                                                                           
                                    case CHC_C:                                     // Canal C                           
                                        i8CanalesActivados&=~CHC_ACT;               // Desactivo el canal                
                                        apagadoCHC();                               // Inicializo/apago el canal         
                                        control_led(0,verde,led_CHC);               // Apago el LED verde                
                                        break;                                                                           
                                    case POINTER_C:                                 // Pointer                           
                                        i8CanalesActivados&=~POINTER_ACT;           // Desactivo el canal                
                                        apagadoCHA();                               // Inicializo/apago el canal         
                                        control_led(0,verde,led_CHA);               // Apago el LED verde                
                                        break;
                                }
                            }else{
                                if(i8CanalesActivados&CANALES_A){                   // Si este canal se encuentra activado 
                                    i8CanalesActivados&=~CHA_ACT;                   // Lo desactivo                        
                                    apagadoCHA();                                   // Inicializo/apago el canal           
                                    control_led(0,verde,led_CHA);                   // Apago el LED rojo                   
                                }                                                                                          
                                if(i8CanalesActivados&CANALES_B){                   // Si este canal se encuentra activado 
                                    i8CanalesActivados&=~CHB_ACT;                   // Lo desactivo                        
                                    apagadoCHB();                                   // Inicializo/apago el canal           
                                    control_led(0,verde,led_CHB);                   // Apago el LED rojo                   
                                }                                                                                          
                                if(i8CanalesActivados&CANALES_C){                   // Si este canal se encuentra activado 
                                    i8CanalesActivados&=~CHC_ACT;                   // Lo desactivo                        
                                    apagadoCHC();                                   // Inicializo/apago el canal           
                                    control_led(0,verde,led_CHC);                   // Apago el LED rojo                   
                                }                                                                                          
                                if(i8CanalesActivados&CANALES_P){                   // Si este canal se encuentra activado 
                                    i8CanalesActivados&=~POINTER_ACT;               // Lo desactivo                        
                                    apagadoCHA();                                   // Inicializo/apago el canal           
                                    control_led(0,verde,led_CHA);                   // Apago el LED rojo                   
                                }                                                                                          
                            }

                            if(!bPausaTratamiento){                                 // Si no estamos pausando el tratamiento
                                envioTratamiento(MODO_START_STOP,COMANDO_STOP);     // Envia el comando                                                                                                                                  
                            }else{                                                  // Si estamos pausando el tratamiento...
                                envioTratamiento(MODO_START_STOP,COMANDO_START_PAUSA);  // Envia el comando 
                            }

                            bReposoActivado=0;                                      // Inicializaci�n de las variables de reposo activado
                            iMenuActual=140;                                        // Vuelvo al men� 140 (Paro el tartamiento)
                            break;
                        case 143:                                                   // Tratamiento electroestimulaci�n activo (error) 
                            i16TimeRepRaw[i8ConfigCanal]=i16TdElec[i8ConfigCanal];  // Inicializo variable tiempo de descanso
                            i16TimeRaw[i8ConfigCanal]=i16TacElec[i8ConfigCanal];    // Inicializo variable tiempo activo
                            i8NrepRaw[i8ConfigCanal]=i8Nrep[i8ConfigCanal];         // Inicializo el n�mero de repeticiones
                            
                            if(!bPausaTratamiento){                                 // Si no estamos pausando el tratamiento 
                                switch(i8ConfigCanal){                              // Dependiendo del canal seleccionado    
                                    case CHA_C:                                     // Canal A                               
                                        i8CanalesActivados&=~CHA_ACT;               // Desactivo el canal                    
                                        apagadoCHA();                               // Inicializo/apago el canal             
                                        control_led(0,verde,led_CHA);               // Apago el LED verde                    
                                        break;                                                                               
                                    case CHB_C:                                     // Canal B                               
                                        i8CanalesActivados&=~CHB_ACT;               // Desactivo el canal                    
                                        apagadoCHB();                               // Inicializo/apago el canal             
                                        control_led(0,verde,led_CHB);               // Apago el LED verde                    
                                        break;                                                                               
                                    case CHC_C:                                     // Canal C                               
                                        i8CanalesActivados&=~CHC_ACT;               // Desactivo el canal                    
                                        apagadoCHC();                               // Inicializo/apago el canal             
                                        control_led(0,verde,led_CHC);               // Apago el LED verde                    
                                        break;                                                                               
                                    case POINTER_C:                                 // Pointer                               
                                        i8CanalesActivados&=~POINTER_ACT;           // Desactivo el canal                    
                                        apagadoCHA();                               // Inicializo/apago el canal             
                                        control_led(0,verde,led_CHA);               // Apago el LED verde                    
                                        break;
                                }
                            }else{                                                  // Si estamos entrando en pausa
                                if(i8CanalesActivados&CANALES_A){                   // Si este canal se encuentra activado 
                                    i8CanalesActivados&=~CHA_ACT;                   // Lo desactivo                        
                                    apagadoCHA();                                   // Inicializo/apago el canal           
                                    control_led(0,verde,led_CHA);                   // Apago el LED rojo                   
                                }                                                                                          
                                if(i8CanalesActivados&CANALES_B){                   // Si este canal se encuentra activado 
                                    i8CanalesActivados&=~CHB_ACT;                   // Lo desactivo                        
                                    apagadoCHB();                                   // Inicializo/apago el canal           
                                    control_led(0,verde,led_CHB);                   // Apago el LED rojo                   
                                }                                                                                          
                                if(i8CanalesActivados&CANALES_C){                   // Si este canal se encuentra activado 
                                    i8CanalesActivados&=~CHC_ACT;                   // Lo desactivo                        
                                    apagadoCHC();                                   // Inicializo/apago el canal           
                                    control_led(0,verde,led_CHC);                   // Apago el LED rojo                   
                                }                                                                                          
                                if(i8CanalesActivados&CANALES_P){                   // Si este canal se encuentra activado 
                                    i8CanalesActivados&=~POINTER_ACT;               // Lo desactivo                        
                                    apagadoCHA();                                   // Inicializo/apago el canal           
                                    control_led(0,verde,led_CHA);                   // Apago el LED rojo                   
                                }                                                                                          
                            }

                            if(!bPausaTratamiento){                                 // Si no estamos pausando el tratamiento
                                envioTratamiento(MODO_START_STOP,COMANDO_STOP);     // Envia el comando                                                                                                                                  
                            }else{                                                  // Si estamos pausando el tratamiento...
                                envioTratamiento(MODO_START_STOP,COMANDO_START_PAUSA);  // Envia el comando 
                            }

                            
                            bReposoActivado=0;                                      // Inicializaci�n de las variables de tratamiento y reposo activado
                            i16ErroresOcurridos=0;                                  // Reinicio la variable de errores ocurridos
                            
                            iMenuActual=140;                                        // Vuelvo al men� 140 (Paro el tartamiento)
                            break;  
                        case 180:                                                   // Tratamiento de SMP
                            if(!bPausaTratamiento){                                 // Si no estamos entrando en pausa
                                i16TimeRaw[0]=i16TacSMP;                            // Inicializo variable tiempo activo
                            }
                            
                            bPausaTratamiento=0;                                    // Pongo a cero la variable de pausa

                            envioTratamiento(MODO_START_STOP,COMANDO_START);        // Envia el comando       
   
                            control_led(1,verde,led_CHC);                           // Enciende LED CHA
                            bTratamientoSMPActivado=1;                              // Activa el flag de tratamiento SMP activado
                            
                            iMenuActual=181;                                        // Voy al men� 181 (Activo el tratamiento)
                            break;
                        case 181:                                                   // Tratamiento de SMP Activo
                            if(!bPausaTratamiento){                                 // Si no estamos entrando en pausa
                                i16TimeRaw[0]=i16TacSMP;                            // Inicializo variable tiempo activo
                                i16ISMP=4;                                          // Inicializo variable de corriente (4*50 = 200uA)
                                i8PulsosSMP=1;                                      // Inicializo n�mero de pulsos
                                bCorrientePulsos=0;                                 // Inicializo selector corriente/pulsos a corriente
                            }
                            
                            if(!bPausaTratamiento){                                 // Si no estamos pausando el tratamiento 
                                envioTratamiento(MODO_START_STOP,COMANDO_STOP);     // Envia el comando                                                                                                                                  
                            }else{                                                  // Si estamos pausando el tratamiento... 
                                envioTratamiento(MODO_START_STOP,COMANDO_START_PAUSA);  // Envia el comando  
                            }  
                                
                            apagadoSMP();                                           // Apagado de los canales            
                            bTratamientoSMPActivado=0;                              // Inicializa variable de tratamiento
                            iMenuActual=180;                                        // Vuelvo al men� 180 (Paro el tartamiento)
                            break;
                        case 183:                                                   // Error en el tratamiento de SMP
                            i16TimeRaw[0]=i16TacSMP;                                // Inicializo variable tiempo activo
                            i16ISMP=4;                                              // Inicializo variable de corriente (4*50 = 200uA)
                            i8PulsosSMP=1;                                          // Inicializo n�mero de pulsos
                            bCorrientePulsos=0;                                     // Inicializo selector corriente/pulsos a corriente
                            
                            envioTratamiento(MODO_START_STOP,COMANDO_STOP);         // Envia el comando   
                                
                            apagadoSMP();                                           // Apagado de los canales            
                            bTratamientoSMPActivado=0;                              // Inicializa variable de tratamiento
                            iMenuActual=180;                                        // Vuelvo al men� 180 (Paro el tartamiento)
                            break;
                        case 200:                                                   // Proceso de autoapagado
                            iMenuActual=iMenuReposo;                                // Indico que voy al men� del que proven�a nates d estar en la pantalla de cuenta atr�s de autoapagado
                            var_tiempo=0;                                           // Inicializo la variable de tiempo
                            break;
                    }
                    itecla=0;                                                       // Inicializo el valor de tecla
                }
            }                                                                                            
            ControlSonido(0);                                                       // Apago el pitido
        }
        
        // --------------------------------------- CAMBIO DE CORRIENTE DURANTE TRATAMIENTO ELECTROESTIMULACI�N----------------------------------- 
        
        if(bCambiado&&iMenuActual==141&&bEmpiezaContadorTiempo){                    // Si ha habido un cambio y estoy en tratamiento activo de electroestimulaci�n
            bCambiado=0;                                                            // Inicializo variable de cambiado
            i32TiempoComunicaciones=0;                                              // Inicializo el contador de timeout
            
            structTratamientoElectroActivo.si8ConfigCanal=i8ConfigCanal;            // Indico el canal activo
            structTratamientoElectroActivo.si8CanalesActivados=i8CanalesActivados;  // Indico la configuraci�n de canales activados
            structTratamientoElectroActivo.si16IElec=i16IElec[i8ConfigCanal];       // Asigno el valor de corriente
            
            envioTratamiento(MODO_TRAT_ELECT_ACTIVO);                               // Envia el comando                                                              
        }
        
        // --------------------------------------- CAMBIO DE CORRIENTE/PULSOS DURANTE TRATAMIENTO  SMP ----------------------------------- 
        
        if(bCambiado&&iMenuActual==181&&bEmpiezaContadorTiempo){                    // Si ha habido un cambio y estoy en tratamiento activo de SMP
            bCambiado=0;                                                            // Inicializo variable de cambiado
            i32TiempoComunicaciones=0;                                              // Inicializo el contador de timeout
            
            structTratamientoMultipulsosActivo.si16ISMP=i16ISMP;                    // Asigna el valor de corriente
            structTratamientoMultipulsosActivo.si8PulsosSMP=i8PulsosSMP;            // Asigna el valor de pulsos SMP

            envioTratamiento(MODO_TRAT_SMP_ACTIVO);                                 // Envia el comando                                                                        
        }
        
        // --------------------------------------- CAMBIO DE CORRIENTE DURANTE TRATAMIENTO GALV�NICA ----------------------------------- 
        
        if(bCambiado&&iMenuActual==121&&bEmpiezaContadorTiempo){                    // Si ha habido un cambio y estoy en tratamiento activo de galv�nica
            bCambiado=0;                                                            // Inicializo variable de cambiado                            
            i32TiempoComunicaciones=0;                                              // Inicializo el contador de timeout
            
            structTratamientoGalvanicaActivo.si16IGalv=i16IGalv;                    // Asigna el valor de corriente galv�nica
            structTratamientoGalvanicaActivo.si16Imicro=i16Imicro;                  // Asigna el valor de corriente microcorrientes
            structTratamientoGalvanicaActivo.sbTerapia=bTerapia;                    // Asigna el valor de terapia 
            
            envioTratamiento(MODO_TRAT_GALV_ACTIVO);                                // Envia el comando                                                                         
        }
        
        
        // --------------------------------------- PRINTF DEPURACI�N -----------------------------------  
        
        //sprintf(mystring,"Carga restante- %LU",i32CargaGalvanicaRestante);
        //sprintf(mystring,"%u %u %u %u",iMenuActual,i8CanalesConfigurados,i8CanalesActivados, i8ConfigCanal);
        //sprintf(mystring,"%LU",redondeoI_50((int16)structMedidasElectro.si16IMedElec[CHA_C][PULSO_POS]));
        //ST7529_printf(mystring,0,110,S_,0);
        
        //sprintf(mystring,"Carga restante- %07LU",i32CargaGalvanicaRestante);
        
        
        //ST7529_printf("[",0,0,S_,0);
        //ST7529_printf("[",3,0,M_,0);
        //ST7529_printf("[",7,0,L_,0);
        //sprintf(mystring,"%u",i8ErrorCom);
        //ST7529_printf(mystring,0,120,S_,0);
        
        // DEBUG - MUESTRA LA CORRIENTE EN PANTALLLA
        //sprintf(mystring,"%04Ld mA",getCurrent());                        
        //ST7529_printf(mystring,65,120,S_,0);
    }   // Cierre bucle while principal
}   // Cierre main

// --------------------------------------- FUNCIONES -----------------------------------  

/*
*   Funci�n: initReles
*   Descripci�n: Inicializa los rel�s
*       - rele_GALV     0
*       - rele_CHA      1   
*       - rele_CHB      2  
*       - rele_CHC      3   
*       - rele_PGM      4
*   Input:
*         - 
*   Output:
*         -
*/
void initReles(){
    for (int i8Cont=0;i8Cont<=TOTAL_RELES;i8Cont++){            // Puesta a reset de todos los reles
        control_rele(0,i8Cont);                                 // Cambia el estado del rel�
        delay_ms(100);                                          // Delay para estabilizar
    }
}

/*
*   Funci�n: control_led
*   Descripci�n: 
*
*   Input:
*       - control   -   1/0
*       - color     -   rojo/verde
*       - led       -   led_CHC,led_CHB,led_CHA,led_GALV
*   Output:
*       -
*/
void  control_led(int1 control,int1 color,int led){       

    // Address=0x00 PCA9555 - Solo hay un expansor 
    int16   mask_led=0x0300;                                    // Inicializamos la m�scara a 0x03 (Los dos primeros bits)
    int16   state_led=0x0100;                                   // Inicializamos el estado del LED (Encendemos uno de ellos)
    int16   state_ant=0xAA00;                                   // Inicializamos el estado anterior
    int16   desp=led*2;                                         // Generamos el desplazamiento de bits necesario para cada LED
    int8     DATA_MSB=0;                                        // Dato para SMB
    int8     DATA_LSB=0;                                        // Dato para LSB
    
    if(!control){                                               // Si control es igual a 0 (OFF)
        state_led>>=1;                                          // Se pone los dos bits a cero - state_led = 0x00
    }else  if (!color){                                         // Si se quiere encender y se ha de encender el color Verde (0)
        state_led<<=1;                                          // Si es verde el bit de mayor peso a 1 - state_led = 0x02
    }
    
    state_led&=0xFF00;                                          // Obligo a que solo se quede en el MSB para no afectar a los rel�s (LSB)
        
    state_led<<=desp;                                           // Se deplaza la posicion de excitaci�n
    mask_led<<=desp;                                            // Genera la m�scara de lectura
    mask_led=~mask_led;                                         // Se realiza la negaci�n de la m�scara. Ej: 0x03 a 0xFC
    
    state_ant=read_PCA955X(0x00,PCA9555);                       // Leo los valores a los que est� el expansor ahora mismo
    state_ant&=mask_led;                                        // Aplico una m�scara para resetear a cero solo los bits del LED a cambiar
    state_led|=state_ant;                                       // Aplico la operaci�n OR para asignar los nuevos valores de esa posici�n
    
    DATA_LSB=MAKE8(state_led, 0);                               // Obtiene el LSB (Rel�s)
    DATA_MSB=MAKE8(state_led, 1);                               // Obtiene el MSB (LEDs)
    
    write_PCA955X(DATA_LSB,DATA_MSB,0x00,PCA9555);              // Envia el dato completo al expansor
}

/*
*      Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
void  control_DC(int1 control,int8 DC){                                                                                     // Control 0--> Apagar 1--> Encender  

    output_bit(DC,control);                                                                                                 // Pone a "control" el pin "DC"
    if(DC==EN_12){                                                                                                          // TODO - Revisar para ver para que vale
        bDebug=control;
    }
}

/*
*      Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
void  control_rele(int1 control,int8 rele){                                                                                 // control     1--> set 0-->reset

    int16 state_rele=0x0100;                                                                                                // Inicializamos el estado del LED (Encendemos uno de ellos)
    int16 i16Ref=0x81;                                                                                                      // Define este valor para poner a 1 los extremos del byte (0b10000001)
    int8 DATA_MSB=0;                                                                                                        // Dato para MSB
    int8 DATA_LSB=0;                                                                                                        // Dato para LSB

    if(rele==rele_PGM){                                                                                                     // En el caso de que se trate del rel� de programaci�n...(este NO va mediante el expansor)
    
        if(control){                                                                                                        // Si se quiere activar
            output_high(C_RL_PGM_S);                                                                                        // Activamos rel�
        }else{                                                                                                              // Si se quiere desactivar
            output_high(C_RL_PGM_R);                                                                                        // Desactivamos rel�
        }
        
        delay_ms(100);                                                                                                      // Delay para activar el bobinado del rel�
        output_low(C_RL_PGM_S);                                                                                             // Ponemos de nuevo a nivel bajo estas se�ales
        output_low(C_RL_PGM_R);
        
    }else{                                                                                                                  // En el caso de querer  activar uno de los rel�s conectados al expansor
    
        DATA_MSB=make8(read_PCA955X(0x00,PCA9555),1);                                                                       // Guardo el LSB (es el valor de los LEDs), ya que este no lo quiero modificar
    
        i16Ref=(0xFF)&((i16Ref>>rele)|(i16Ref<<rele));                                                                      // Obtengo que bits son los que me interesan
        i16Ref<<=8;                                                                                                         // Desplazo ese valor al m�s significativo
        
        if(control){                                                                                                        // Si activo el rel�
            state_rele=i16Ref & MASK_RELE_SET;                                                                              // Activo el rel� seleccionado mediante una m�scara
        }else{                                                                                                              // Si desactivo el rel�
            state_rele=i16Ref & MASK_RELE_RESET;                                                                            // Desactivo el rel� seleccionado mediante una m�scara
        }
        
        DATA_LSB=make8(state_rele,1);                                                                                       // Obtengo el byte m�s significativo
        
        write_PCA955X(DATA_LSB,DATA_MSB, 0x00,PCA9555);                                                                     // Escribo los valores al expansor
        delay_ms(100);                                                                                                      // Delay de activacion de bobinado
        
        DATA_LSB=0;                                                                                                         // Pongo a cero el byte de control de rel�s
        write_PCA955X(DATA_LSB,DATA_MSB, 0x00,PCA9555);                                                                     // Escribo de nuevo
    }
}

/*
*      Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
void ControlSonido(int1 control){               
    if (control){                                                                                                           // Si se ha activado el sonido
        if (i16nivel_son!=0){                                                                                               // Mientras en nivel de sonido sea distinto de 0
            CCP7CON=0x0C;                                                                                                   // Enciendo el modulador
            set_pwm7_duty((int16)((i16nivel_son*5)));                                                                       // Fijo el PWM que controla el pito
        }                               
    }else{                                                                                                                  // En caso de querer apagarlo
        CCP7CON=0x00;                                                                                                       // Apagamos modulador
    }
}

/*
*      Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
void  update_button(long *button_history){
   *button_history = *button_history << 1;                                                                                  // Desplazamiento de un bit para recoger el siguiete dato
   *button_history= *button_history |read_button();                                                                         // Capturamos el nuevo dato y lo guardamos
}

/*
*      Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
int1 read_button(){
   return input_state(COD_A); ;                                                                                             // Devuelve el valor del estado del codificador
}

/*
*      Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
int1 is_button_pressed(long *button_history){

   int8 pressed = 0; 
   
   if ((*button_history | MASK) == 0b11111111111000000){                                                                    // Si se ha podido detectar mediante la m�scara que se ha girado el codificador
      pressed = 1;                                                                                                          // Indico que se ha presionado el bot�n
      *button_history = 0xFFFF;                                                                                             // Inicializo de nuevo la variable
   }
   
   return (pressed);                                                                                                        // Devuelvo si se ha detectado giro (1) o no (0)
}

/*
*      Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
void pausa_I(int16 delay){
    
    for(int16 m=0;m<=delay;m++){
        delay_us(1);                                                                                                   // Genera un delay multiplo de 1uS ( Delay total= 1uS*X )
    }
}

/*
*      Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
void funcion_dormir(){     
    
    // Muestro men� de apagando equipo
    iMenuActual=201;    
    //ControlSonido(1);                                                                                               // Activa sonido para la tecla
    result=(*funcArr_menu[iMenuActual])();          
    
    // Reset a PIC Orco
    output_high(RST_ORCO);
    
    // Stop interrupts
    disable_interrupts(INT_EXT1_H2L);           // Deshabilito interrupci�n codificador    
    disable_interrupts(INT_EXT3_H2L);           // Deshabilito interrupci�n teclado
    disable_interrupts(INT_TIMER10);            // Deshabilito interrupci�n Timer 10
    disable_interrupts(INT_TIMER12);            // Deshabilito interrupci�n Timer 12 8por si acaso)
    
    // Clear interrupts
    clear_interrupt(INT_EXT1_H2L);              // Limpia flags interrupciones
    clear_interrupt(INT_EXT3_H2L);              // Limpia flags interrupciones
    clear_interrupt(INT_RB);                    // Limpia flags interrupciones  
    clear_interrupt(INT_TIMER10);               // Limpia flags interrupciones
    clear_interrupt(INT_TIMER12);               // Limpia flags interrupciones
    
    // Stop Timers
    TIMER10_ON=0;                               // Paro Timer 10 - Base de tiempos
    TIMER12_ON=0;                               // Paro Timer 12 - Antirebotes
      
    // Apagado DCDC de 30 V
    control_DC(0,EN_30);                        // Apaga los 30 V de perif�ricos
    
    // Puesta a reset de todos los reles      
    initReles();                                // Inicializa los rel�s a 0
    restart_wdt();
    
    // Apagado leds de tratamiento
    for (int8 i=0;i<TOTAL_LEDS;i++){                 // Bucle para el apagado de los leds
        control_led(0,verde,i);
        control_led(0,rojo,i);
    }   
    
    // Borrado de pantalla
    ST7529_clear();
    restart_wdt();
    // Apagado moduladores pantalla y sonido
    set_pwm7_duty((int16)0);                    // Nivel bajo modulador pito
    set_pwm8_duty((int16)0);                    // Nivel bajo modulador luz pantalla
    
    CCP7CON=0x00;                               // Apago modulador pito
    CCP8CON=0x00;                               // Apago modulador luz
    
    // Apagado comunicaciones
    I2C_1_ON=0;                                 // Desactivo I2C1
    SPI_2_ON=0;                                 // Desactivo SPI2
    
    DEBUG_UART_ON=0;                            // Apaga UART DEBUG
    COM_PIC_UART_ON=0;                          // Apaga UARt comunicaci�n entre PICs
    
    // Apagado de los 12V +5V
    control_DC(0,EN_5_sw);                      // Apaga los 5 V de perif�ricos
    control_DC(0,EN_12);                        // Apaga los 12 V de perif�ricos
    delay_ms(200);
    
    // Mantienen su configuraci�n como salida y no se modifican
    output_low(C_RL_PGM_S);
    output_low(C_RL_PGM_R);
    output_low(LED_ALPP);
    output_low(SEL_PGM);
    output_low(RST_ORCO);
    output_low(LCD_A0);
    output_low(LCD_RST);
    output_low(LCD_XCS);
    output_low(HOLD_MEM);
    output_low(SPI2_SDO);
    output_low(SPI2_SCLK);
    output_low(CS_MEM);
    output_low(LED_CHG_V);
    output_low(LED_CHG_R);
    output_low(EN_5);
    output_low(W_DOG);
    output_low(EN_30);
    output_low(EN_5_SW);
    output_low(EN_12);
    output_low(EN_ISO);
    
    output_low(PWM_LUS);
    output_low(PWM_PITO);
    
    TRISB&=~0x80;
    TRISA&=0xC8;
    
    output_low(PGM_D_1);
    output_low(PIN_TEST);
    output_low(RA6);
    output_low(RA7);
    
    // Cambian su configuraci�n a salida y se fijan a nivel bajo
    
    TRISC&=~0xD8;
    TRISG&=~0x02;
    
    output_low(I2C_SCL);
    output_low(I2C_SDA);
    output_low(TX_ORCO_SAURON);
    output_low(TX_AUX_1);
    output_low(RX_AUX_1);

    
    // Inicializacion variables...  
    enable_interrupts(INT_RB);                  // Habilita las interrupciones del puerto RB
    bSleepMode=1;                               // Indica que se encuentra en modo sleep
    ControlSonido(0);                                                                                               // Activa sonido para la tecla
}

/*
*      Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
int8 nivelBateria(){
  return getSOC();                              // Devuelve el valor de la bateria en porcentaje
}

/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
int1 estadoCarga(){
  return (getFlags()&0x0001);                   // Realiza comprobaci�n mediante BQ del estado de carga
}

/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
int16 calc_Tgalv(int32 carga,int16 corriente){

    float aux2=((float)carga)/(corriente*50);              // Obtengo el tiempo de tratamiento a partir de la carga el�ctrica dividida por la corriente
    
    return(aux2);                                       // Devuelve el valor
}

/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
int32 calc_CargaGalv(int16 corriente){

    float fAux=0;
    
    if(i8TrampaGalv>0){             // Si hay tiempo de rampa configurado
        i16CRampaGalv=(float)corriente*50*i8TrampaGalv/2;        // Obtengo la craga de la rampa
        i16CRampaGalvInc=i16CRampaGalv/i8TrampaGalv;
    }else{
        i16CRampaGalv=0;
    }
    
    fAux=(float)corriente*50*i16Tgalv;     // Obtengo la  carga del tratamiento, si hay rampa, la sumo
    
    return(fAux);                                       // Devuelve el valor
}
       
/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
int16 calc_Tmicro(){

    float aux;                              // Variables auxiliares para el c�lculo
    float aux1;
    float aux2;
    
    aux=(i16Cmicro*100.0);                                                              // Escalo el valor de la carga el�ctrica 
    aux1=(10.0*(i16Imicro)*(i16PWmicro/1000000.0)*i16frecmicro*(1.0+bpolaridadmicro));  // C�lculo del valor de la corriente
    aux2=aux/aux1;                                                                      // Obtenci�n del tiempo de tratamiento
    
    return(aux2);                                                                       // Devuelve el valor
}   

/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
int16 Calc_BWmax(int16 frecuencia,int1 polaridad){

    float aux;                                          // Variables auxiliares para el c�lculo
    int32 aux1;
    
    aux=((0.9*1000000)/(frecuencia*(1+polaridad)));     // Obtengo el valor de ancho de pulso
    aux1=aux;                                           // Cast data
     
    if (aux1>=1000){                                    // Si el valor obtenido es mayor a 1000
        aux1=1000;                                      // Fijo el alor de 1000
    }
    
    aux1/=25;                                           // Dividimos por factor de 25
    if(i8ConfigCanal==POINTER_C){
        if(aux1>=20){
            aux1=20;
        }
    }
    return(aux1);                                       // Devuelve el valor obtenido
}

/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
int16 Calc_BW(int16 max,int16 BW){

    if (BW>max*25){         // Si el PW es mayor que esa expresi�n
        BW=max*25;          // Asigno el valor
    }
    
    return(BW);             // Devuelve el valor
}

/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
void  Calc_representacion_t(int16 iTiempoActivo, int16 iTiempoReposo){

    float fAuxAct, fAuxRep;             // Variables auxiliares para el c�lculo
    
    fAuxAct=iTiempoActivo/60.0;         // Divido el tiempo activo para obtener los minutos
    fAuxRep=iTiempoReposo/60.0;         // Divido el tiempo en resposo para obtener los minutos

    i8Tmin=fAuxAct;                     // Asigno los minutos
    i8Tseg=iTiempoActivo%60;            // Hago el m�dulo de 60 para obtener los segundos
    i8T1min=fAuxRep;                    // Asigno los minutos                             
    i8T1seg=iTiempoReposo%60;           // Hago el m�dulo de 60 para obtener los segundos 
}

/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
int8 checkAutoapagado(){                // Funci�n para comprobar el autoapagado del equipo

    if(var_tiempo>=540000){             // Si han pasado 9 minutos (cada minuto son 150000 cuentas)...
        if(var_tiempo>=600000){         // Si han pasado 10 minutos...
            return INACTIVO;            // Indica que debe de entrar en modo de reposo
        }else{                          // ...si no han pasado 10 minutos
            return TIEMPO_DESCUENTO;    // Todavia est� en tiempo de descuento
        }
    }else{                              // ...si no han pasado 9 minutops todavia
        return 0;                       // Devuelve valor DUMMY
    }
}

/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
int16 redondeoI_50(int16 Ivalor){       // Redondeo de la corriente en pasos de 50uA

    int16 Iy;                               // Variable entera para el c�lculo
    float Ix;                               // Variable flotante para el c�lculo

    Ix=Ivalor/100.0;                        // Divido entre 100 y lo guardo en una variable flotante
    Iy=Ix;                                  // Paso el resultado a entero
    
    if ((Iy+0.5)<=Ix){                      // Si a la variable entera le sumo 0.5 y el resultado es menor o igual que el de la variable flotante...
        if ((Iy+0.75)>=Ix){                 // Si le sumamos 0.75 a la variable entera y el resultado es mayor o igual que la variable flotante...
            Ix=(float)(Iy+0.5)*100.0;       // Le sumamos 0.5 a la variable entera y lo guardamos como flotante
        }else{                              // ...si no es mayor o igual
            Ix=(float)(Iy+1.0)*100.0;       // Le sumamos 1 a la variable entera y lo guardamos como flotante
        }       
    }else{                                  // ...si no es menor o igual
        if ((Iy+0.25)>=Ix){                 // Si le sumamos 0.25 a la variable entera y el resultado es mayor o igual que el de la variable flotante...
            Ix=Iy*100.0;                    // Escala el resultado
        }else{                              // ...si no es mayor o igual
            Ix=(float)(Iy+0.5)*100.0;       // SUmamos 0.5 a la variable entera y lo guardamos como flotante
        }
    }
    
    Iy=Ix;                                  // Pasamos el resultado a entero
    
    return (Iy);                            // Devuelve el resultado
}

/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
int16 redondeoI_100(int16 Ivalor){      // Redondeo de la corriente en pasos de 100uA

    int16 Iy;                   // Variable entera para el c�lculo  
    float Ix;                   // Variable flotante para el c�lculo
    
    if (Ivalor<=80){            // Si el valor es menor o iguual que 80
        Ivalor=0;               // Po nel valor a 0
    }
    
    Ix=Ivalor/100.0;            // Divido entre 100 y lo guardo en una variable flotante
    Iy=Ix;                      // Paso el resultado a entero
    
    if ((Iy+0.5)<=Ix){          // Si a la variable entera le sumo 0.5 y el resultado es menor o igual que el de la variable flotante...
        Iy=Iy+1;                // incremento el valor
    }
    
    Iy=(Iy*100);                // Escalo el valor
    
    return (Iy);                // Devuelvo el valor
}

/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
void  f_avisos(){                      // Funcion que detecta max value o baja resistencia de carga

    // Guardo los datos en variables 
    bMAX[CHA_C][PULSO_POS]=structMedidasElectro.sbMAX[CHA_C][PULSO_POS];
    bMAX[CHA_C][PULSO_NEG]=structMedidasElectro.sbMAX[CHA_C][PULSO_NEG];
    bCC[CHA_C]=structMedidasElectro.sbCC[CHA_C];
    
    bMAX[CHB_C][PULSO_POS]=structMedidasElectro.sbMAX[CHB_C][PULSO_POS];
    bMAX[CHB_C][PULSO_NEG]=structMedidasElectro.sbMAX[CHB_C][PULSO_NEG];
    bCC[CHB_C]=structMedidasElectro.sbCC[CHB_C];
    
    bMAX[CHC_C][PULSO_POS]=structMedidasElectro.sbMAX[CHB_C][PULSO_POS];
    bMAX[CHC_C][PULSO_NEG]=structMedidasElectro.sbMAX[CHB_C][PULSO_NEG];
    bCC[CHC_C]=structMedidasElectro.sbCC[CHC_C];
    
    //sprintf(mystring,"Ap - %U  An - %U  CC - %U",bMAX[CHA_C][PULSO_POS],bMAX[CHA_C][PULSO_NEG],bCC[CHA_C]);
    //ST7529_printf(mystring,0,110,S_,0);
    
    switch(i8CanalesActivados){
        case CANALES_A:            // Canal A
            if ((bMAX[CHA_C][PULSO_POS])||(bMAX[CHA_C][PULSO_NEG])){                    // Si se ha activado el max value ...
                mystring3="MAX A";                                                      // Muestra el texto por pantalla
            }else{                                                                      // ...si no hay max value
                mystring3="     ";                                                      // Quita el posible texto que haya en pantalla
            }
    
            if (bCC[CHA_C]){                                                            // Si se ha detectado cortocircuito en la carga...
                mystring4="CC  A";                                                      // Indicamos cortotcircuito
            }else{                                                                      // ...si es mayor
                mystring4="     ";                                                      // Quita el posible texto que haya en pantalla
            }
            break;
        case CANALES_B:            // Canal B
            if ((bMAX[CHB_C][PULSO_POS])||(bMAX[CHB_C][PULSO_NEG])){                    // Si se ha activado el max value ...
                mystring3="MAX B";                                                      // Muestra el texto por pantalla
            }else{                                                                      // ...si no hay max value
                mystring3="     ";                                                      // Quita el posible texto que haya en pantalla
            }
    
            if (bCC[CHB_C]){                                                            // Si se ha detectado cortocircuito en la carga...
                mystring4="CC  B";                                                      // Indicamos cortotcircuito
            }else{                                                                      // ...si es mayor
                mystring4="     ";                                                      // Quita el posible texto que haya en pantalla
            }
            break;
        case CANALES_C:            // Canal C
            if ((bMAX[CHC_C][PULSO_POS])||(bMAX[CHC_C][PULSO_NEG])){                    // Si se ha activado el max value ...
                mystring3="MAX C";                                                      // Muestra el texto por pantalla
            }else{                                                                      // ...si no hay max value
                mystring3="     ";                                                      // Quita el posible texto que haya en pantalla
            }
    
            if (bCC[CHC_C]){                                                            // Si se ha detectado cortocircuito en la carga...
                mystring4="CC  C";                                                      // Indicamos cortotcircuito
            }else{                                                                      // ...si es mayor
                mystring4="     ";                                                      // Quita el posible texto que haya en pantalla
            }
            break;
        case CANALES_AB:            // Canal A y B
            if ( ( (bMAX[CHA_C][PULSO_POS])||(bMAX[CHA_C][PULSO_NEG]) ) &&  
                    ( (bMAX[CHB_C][PULSO_POS])||(bMAX[CHB_C][PULSO_NEG]) ) ){            // Si se ha activado el max value en ambos canales
                mystring3="MAX  ";                                                      // Muestra el texto por pantalla
            }else if( ( (bMAX[CHA_C][PULSO_POS])||(bMAX[CHA_C][PULSO_NEG]) ) &&  
                    ( !(bMAX[CHB_C][PULSO_POS]) && !(bMAX[CHB_C][PULSO_NEG]) ) ){     // Si se ha activado el max value soslo en el canal A
                mystring3="MAX A";
            }else if( ( !(bMAX[CHA_C][PULSO_POS]) && !(bMAX[CHA_C][PULSO_NEG]) ) &&  
                    ( (bMAX[CHB_C][PULSO_POS])||(bMAX[CHB_C][PULSO_NEG]) ) ){         // Si se ha activado el max value solo en el canal B
                mystring3="MAX B";
            }else{                                                                      // ...si no hay max value
                mystring3="     ";                                                      // Quita el posible texto que haya en pantalla
            }
    
            if (bCC[CHA_C]&&bCC[CHB_C]){                                                            // Si se ha detectado cortocircuito en la carga en ambos canales
                mystring4="CC  ";                                                      // Indicamos cortotcircuito
            }else if(bCC[CHA_C]){
                mystring4="CC A";
            }else if(bCC[CHB_C]){
                mystring4="CC B";
            }else{                                                                      // ...si es mayor
                mystring4="     ";                                                      // Quita el posible texto que haya en pantalla
            }
            break;
        case CANALES_BC:            // Canal B y C
            if ( ( (bMAX[CHB_C][PULSO_POS])||(bMAX[CHB_C][PULSO_NEG]) ) &&  
                    ( (bMAX[CHC_C][PULSO_POS])||(bMAX[CHC_C][PULSO_NEG]) ) ){            // Si se ha activado el max value en ambos canales
                mystring3="MAX  ";                                                      // Muestra el texto por pantalla
            }else if( ( (bMAX[CHB_C][PULSO_POS])||(bMAX[CHB_C][PULSO_NEG]) ) &&  
                    ( !(bMAX[CHC_C][PULSO_POS]) && !(bMAX[CHC_C][PULSO_NEG]) ) ){       // Si se ha activado el max value solo en el canal B
                mystring3="MAX B";
            }else if( ( !(bMAX[CHB_C][PULSO_POS]) && !(bMAX[CHB_C][PULSO_NEG]) ) &&  
                    ( (bMAX[CHC_C][PULSO_POS])||(bMAX[CHC_C][PULSO_NEG]) ) ){          // Si se ha activado el max value solo en el canal C
                mystring3="MAX C";
            }else{                                                                      // ...si no hay max value
                mystring3="     ";                                                      // Quita el posible texto que haya en pantalla
            }
    
            if (bCC[CHB_C]&&bCC[CHC_C]){                                                            // Si se ha detectado cortocircuito en la carga...
                mystring4="CC  ";                                                      // Indicamos cortotcircuito
            }else if(bCC[CHA_C]){
                mystring4="CC B";
            }else if(bCC[CHB_C]){
                mystring4="CC C";
            }else{                                                                      // ...si es mayor
                mystring4="     ";                                                      // Quita el posible texto que haya en pantalla
            }
            break;
        case CANALES_AC:            // Canal A y C
            if ( ( (bMAX[CHA_C][PULSO_POS])||(bMAX[CHA_C][PULSO_NEG]) ) &&  
                    ( (bMAX[CHC_C][PULSO_POS])||(bMAX[CHC_C][PULSO_NEG]) ) ){            // Si se ha activado el max value ...
                mystring3="MAX  ";                                                      // Muestra el texto por pantalla
            }else if( ( (bMAX[CHA_C][PULSO_POS])||(bMAX[CHA_C][PULSO_NEG]) ) &&  
                    ( !(bMAX[CHC_C][PULSO_POS]) && !(bMAX[CHC_C][PULSO_NEG]) ) ){
                mystring3="MAX A";
            }else if( ( !(bMAX[CHA_C][PULSO_POS]) && !(bMAX[CHA_C][PULSO_NEG]) ) &&  
                    ( (bMAX[CHC_C][PULSO_POS])||(bMAX[CHC_C][PULSO_NEG]) ) ){
                mystring3="MAX C";
            }else{                                                                      // ...si no hay max value
                mystring3="     ";                                                      // Quita el posible texto que haya en pantalla
            }
    
            if (bCC[CHA_C]&&bCC[CHC_C]){                                                            // Si se ha detectado cortocircuito en la carga...
                mystring4="CC  ";                                                      // Indicamos cortotcircuito
            }else if(bCC[CHA_C]){
                mystring4="CC A";
            }else if(bCC[CHC_C]){
                mystring4="CC C";
            }else{                                                                      // ...si es mayor
                mystring4="     ";                                                      // Quita el posible texto que haya en pantalla
            }
            break;
        case CANALES_ABC:            // Canal A, B y C
            if ( ( (bMAX[CHA_C][PULSO_POS])||(bMAX[CHA_C][PULSO_NEG]) ) &&  
                    ( (bMAX[CHB_C][PULSO_POS])||(bMAX[CHB_C][PULSO_NEG]) ) &&
                    ( (bMAX[CHC_C][PULSO_POS])||(bMAX[CHC_C][PULSO_NEG]) ) ){            // Si se ha activado el max value ...
                mystring3="MAX   ";                                                      // Muestra el texto por pantalla
            }else if( ( (bMAX[CHA_C][PULSO_POS])||(bMAX[CHA_C][PULSO_NEG]) ) &&  
                    ( (bMAX[CHB_C][PULSO_POS])||(bMAX[CHB_C][PULSO_NEG]) ) &&
                    ( !(bMAX[CHC_C][PULSO_POS]) && !(bMAX[CHC_C][PULSO_NEG]) ) ){
                mystring3="MAX AB";
            }else if( ( !(bMAX[CHA_C][PULSO_POS])&& !(bMAX[CHA_C][PULSO_NEG]) ) &&  
                    ( (bMAX[CHB_C][PULSO_POS])||(bMAX[CHB_C][PULSO_NEG]) ) &&
                    ( (bMAX[CHC_C][PULSO_POS])||(bMAX[CHC_C][PULSO_NEG]) ) ){
                mystring3="MAX BC";
            }else if( ( (bMAX[CHA_C][PULSO_POS])||(bMAX[CHA_C][PULSO_NEG]) ) &&  
                    ( !(bMAX[CHB_C][PULSO_POS]) && !(bMAX[CHB_C][PULSO_NEG]) ) &&
                    ( (bMAX[CHC_C][PULSO_POS])||(bMAX[CHC_C][PULSO_NEG]) ) ){
                mystring3="MAX AC";
            }else if( (bMAX[CHA_C][PULSO_POS])||(bMAX[CHA_C][PULSO_NEG]) ){
                mystring3="MAX A ";
            }else if( (bMAX[CHB_C][PULSO_POS])||(bMAX[CHB_C][PULSO_NEG]) ){
                mystring3="MAX B ";
            }else if( (bMAX[CHC_C][PULSO_POS])||(bMAX[CHC_C][PULSO_NEG]) ){
                mystring3="MAX C ";
            }else{                                                                      // ...si no hay max value
                mystring3="      ";                                                      // Quita el posible texto que haya en pantalla
            }
    
            if (bCC[CHA_C]&&bCC[CHB_C]&&bCC[CHC_C]){                                                            // Si se ha detectado cortocircuito en la carga...
                mystring4="CC   ";                                                      // Indicamos cortotcircuito
            }else if(bCC[CHA_C]&&bCC[CHB_C]){
                mystring4="CC AB";
            }else if(bCC[CHB_C]&&bCC[CHB_C]){
                mystring4="CC BC";
            }else if(bCC[CHA_C]&&bCC[CHC_C]){
                mystring4="CC AC";
            }else if(bCC[CHA_C]){
                mystring4="CC A ";
            }else if(bCC[CHB_C]){
                mystring4="CC B ";
            }else if(bCC[CHC_C]){
                mystring4="CC C ";
            }else{                                                                      // ...si es mayor
                mystring4="     ";                                                      // Quita el posible texto que haya en pantalla
            }
            break;    
    }   // Cierre switch-case
}

/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
void calculoTiempoDesfase(){
    // OJO: Modificado para dar siempre el m�nimo desfase permitido
    int8 i8Multiplicador=1;                                                                                 // Definici�n de la variable multiplicador (por si la se�al es bipolar)
    
    if ( (i8CanalesActivados==CANALES_AB) || (i8CanalesActivados==CANALES_AC) ||  (i8CanalesActivados==CANALES_ABC) ){                                 // Si estamos en un modo donde el primer canal es el A (C�lculo primer desfase)
        if(bPolaridadElec[CHA_C]){                                                                          // Si la se�al es bipolar
            i8Multiplicador=2;                                                                              // Ponemos el multiplicador a dos
            //i16PW_minusElec[CHA_C]=0;                                                                       // Ponemos el valor del PW- a cero -- NOTA : WHAAT?? Pa que?
        }/*
        if(i16TfElec12 < (i16PW_plusElec[CHA_C]+i16PW_minusElec[CHA_C]+i8Multiplicador*BANDA_GUARDA)){*/      // Si el valor de desfase especificado es menor al permitido
            i16TfElec12=i16PW_plusElec[CHA_C]+i16PW_minusElec[CHA_C]+i8Multiplicador*BANDA_GUARDA;          // Se asigan el valor m�nimo
            /*i16TfElec12Min=i16TfElec12;
        }*/
    }else if (i8CanalesActivados==CANALES_BC){                                                                            // Si estamos en un modo donde el primer canal es B
        if(bPolaridadElec[CHB_C]){                                                                          // Si la se�al es bipolar                                   
            i8Multiplicador=2;                                                                              // Ponemos el multiplicador a dos                           
            //i16PW_minusElec[CHB_C]=0;                                                                       // Ponemos el valor del PW- a cero                          
        }                                                                                                                                                               
        /*if(i16TfElec12 < (i16PW_plusElec[CHB_C]+i16PW_minusElec[CHB_C]+i8Multiplicador*BANDA_GUARDA)){*/      // Si el valor de desfase especificado es menor al permitido
            i16TfElec12=i16PW_plusElec[CHB_C]+i16PW_minusElec[CHB_C]+i8Multiplicador*BANDA_GUARDA;          // Se asigan el valor m�nimo         
            /*i16TfElec12Min=i16TfElec12;
        }*/
    }
    
    if(i8CanalesActivados==CANALES_ABC){                                                                                   // Si estamos en el modo de tres canales (C�lculo segundo desfase)
        if(bPolaridadElec[CHB_C]){                                                                          // Si la se�al es bipolar                                   
            i8Multiplicador=2;                                                                              // Ponemos el multiplicador a dos                           
            //i16PW_minusElec[CHB_C]=0;                                                                       // Ponemos el valor del PW- a cero                          
        }                                                                                                                                                               
        /*if(i16TfElec23 < (i16PW_plusElec[CHB_C]+i16PW_minusElec[CHB_C]+i8Multiplicador*BANDA_GUARDA)){      // Si el valor de desfase especificado es menor al permitido
            */i16TfElec23=i16PW_plusElec[CHB_C]+i16PW_minusElec[CHB_C]+i8Multiplicador*BANDA_GUARDA;          // Se asigan el valor m�nimo 
            /*i16TfElec23Min=i16TfElec23;
        }*/
    }
}

// Funci�n utilizada para hacer un delay sin que el WDG externo reinicie el microcontrolador,
// debido a que si se usa un delay que supera el tiempo de refresco del WDG, se podria reiniciar
/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
void delay_ms_wdt(int16 i16DelayWDT){

   if(i16DelayWDT>WDG_T){                                                  // Si el valor del delay supera el valor prefijado como valor "casi" critico de delay que podria afectar al WDG
      for(int16 i16ContWDT=1; i16ContWDT<=i16DelayWDT; i16ContWDT++){      // En caso de que lo supere, hace delays de un milisegundo hasta alcanzar el valor deseado
         delay_ms(1);
         if((i16ContWDT%WDG_T)==0){                                        // En el caso en el que llegue al valor cr�tico, realizamos un pulso
            output_high(W_DOG);                                            // No hace falta poner nig�n tipo de delay debido a que as� es suficiente para que detyecte el pulso, solo necesita unos pocos ns de pulso
            output_low(W_DOG);
         }
      }
   }else{                                                                  // En el caso de que el delay tenga un valor razonable que no interfiera con el WDG
      delay_ms(i16DelayWDT);                                               // Realizamos el delay normal
   }
}

/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
void apagadoMicrocorrientes(){
    bTerapia=0;
    apagadoGalvanica();
    
}

/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
void apagadoGalvanica(){
    //if(!bTerapia){           // Si solo es tratamiento de galv�nica
        control_DC(0,EN_30);                                     // Apagado DC 30 V                                
        control_rele(0,rele_GALV);                               // Apagado rele galvanica
        control_led(0,verde,led_GALV);                           // Apagado LED galvanica
    //}
    /*bErrorElectrodo[CHB_C]=0;                                // Inicializaci�n variables
    bEmpiezaContadorTiempo=0;                                
    i16IMedGalv=structMedidasGalvanica.si16IMedGalv=0;       
    i16VMedGalv=structMedidasGalvanica.si16VMedGalv=0;       
    i16ResGalv=structMedidasGalvanica.si16ResGalv=0;         
    bValorAlcanzado=structControlTiempo.sbValorAlcanzado=0;  
    bDescuentaCargaRampa=0;*/
    if(bPausaTratamiento){
        // Con pausa
        bEmpiezaContadorTiempo=0;
        bValorAlcanzado=0;
        bTratamientoGalvanicaActivado=0;
        bMicrocorrientesEncendido=0;
    }else{
        // Sin pausa
        bEmpiezaContadorTiempo=0;                            
        bValorAlcanzado=0;
        bDescuentaCargaRampa=0;
        bTerapia=0;
        bTratamientoGalvanicaActivado=0;
        bMicrocorrientesEncendido=0;
        i32CargaGalvanicaRestante=0;
        i16TimeRaw[0]=i16Tgalv+i8TrampaGalv;
    }
    
    bPrimeraMedida=0;
    bAguantaEnvio=0;
    i8BufferIndex=0;
    bCasiRecibido=0;
    bDatoRecibido=0;
    
    i16ErroresOcurridos&=~ERROR_ELECTRODO_CHB;
}

/*
*   Funci�n: 
*   Descripci�n: 
*        
*   Input:
*       - 
*   Output:
*       -
*/
void apagadoSMP(){
    control_DC(0,EN_30);                                    // Apagado DC 30 V                                                     
    control_rele(0,rele_CHC);                               // Apagado rele SMP          
    control_led(0,verde,led_CHC);                           // Apagado LED SMP              
    bErrorElectrodo[CHC_C]=0;                               // Inicializaci�n variables      
    bEmpiezaContadorTiempo=0;
    structMedidasElectro.si16IMedElec[CHC_C][PULSO_POS]=0;  
    structMedidasElectro.si16IMedElec[CHC_C][PULSO_NEG]=0;
    structMedidasElectro.si16VMedElec[CHC_C][PULSO_POS]=0;  
    structMedidasElectro.si16VMedElec[CHC_C][PULSO_NEG]=0;
    /*if(i16ISMP>20){        // Si es mayor de 1mA, fija a 1mA, sino, mantiene el valor
        i16ISMP=20;
    }*/
    if(!bPausaTratamiento){
        giPos=1;
    }
    bPrimeraMedida=0;
    i16ErroresOcurridos&=~ERROR_ELECTRODO_CHC;
}

/*
*   Funci�n: apagadoCHB
*   Descripci�n: Apaga el canal A
*        
*   Input:
*       - 
*   Output:
*       -
*/
void apagadoCHA(){
    if(i8CanalesActivados==0 && !bPausaTratamiento){            // Si ya no hay m�s canales activados y no se encuentra en pausa
        control_DC(0,EN_30);                                    // Apagado DC 30 V                                               
        bEmpiezaContadorTiempo=0;                               // Inicializo flag contador de tiempo tratamiento               
        bPausaTratamiento=0;                                    // Inicializo flag pausa                                        
        structMedidasElectro.si16IMedElec[CHA_C][PULSO_POS]=0;  // Inicializo variables de corriente                            
        structMedidasElectro.si16IMedElec[CHA_C][PULSO_NEG]=0;  // Inicializo variables de corriente                            
        structMedidasElectro.si16VMedElec[CHA_C][PULSO_POS]=0;  // Inicializo variables de tensi�n                              
        structMedidasElectro.si16VMedElec[CHA_C][PULSO_NEG]=0;  // Inicializo variables de tensi�n                              
        if(i16IElec[CHA_C]>20){                                 // Si es mayor de 1mA                                           
            i16IElec[CHA_C]=20;                                 // Fija a 1mA, sino, mantiene el valor                          
        }                                                                                                                       
    }                                                                                                                           
    bPrimeraMedida=0;                                           // Inicializo flag primera medida                               
    i8ReposoActivados&=~CANALES_A;                              // Inicializo flag de reposo del canal                          
    control_rele(0,rele_CHA);                                   // Apagado rele canal                                           
    control_led(0,verde,led_CHA);                               // Apagado LED verde canal                                      
    bErrorElectrodo[CHA_C]=0;                                   // Inicializo flag de error de electrodo                        
    bValorAlcanzado=structControlTiempo.sbValorAlcanzado=0;     // Inicializo flag de valor de corriente alcanzado              
    i16ErroresOcurridos&=~ERROR_ELECTRODO_CHA;                  // Inicializo flag de error de electrodo                        
    // TODO MAX y CC init
}

/*
*   Funci�n: apagadoCHB
*   Descripci�n: Apaga el canal B
*        
*   Input:
*       - 
*   Output:
*       -
*/
void apagadoCHB(){
    if(!i8CanalesActivados && !bPausaTratamiento){              // Si ya no hay m�s canales activados y no se encuentra en pausa
        control_DC(0,EN_30);                                    // Apagado DC 30 V                                                    
        bEmpiezaContadorTiempo=0;                               // Inicializo flag contador de tiempo tratamiento               
        bPausaTratamiento=0;                                    // Inicializo flag pausa                                        
        structMedidasElectro.si16IMedElec[CHB_C][PULSO_POS]=0;  // Inicializo variables de corriente                            
        structMedidasElectro.si16IMedElec[CHB_C][PULSO_NEG]=0;  // Inicializo variables de corriente                            
        structMedidasElectro.si16VMedElec[CHB_C][PULSO_POS]=0;  // Inicializo variables de tensi�n                              
        structMedidasElectro.si16VMedElec[CHB_C][PULSO_NEG]=0;  // Inicializo variables de tensi�n                              
        if(i16IElec[CHB_C]>20){        r                        // Si es mayor de 1mA                                           
            i16IElec[CHB_C]=20;                                 // Fija a 1mA, sino, mantiene el valor                          
        }                                                                                                                       
    }                                                                                                                           
    bPrimeraMedida=0;                                           // Inicializo flag primera medida                               
    i8ReposoActivados&=~CANALES_B;                              // Inicializo flag de reposo del canal                          
    control_rele(0,rele_CHB);                                   // Apagado rele canal                                           
    control_led(0,verde,led_CHB);                               // Apagado LED verde canal                                      
    bErrorElectrodo[CHB_C]=0;                                   // Inicializo flag de error de electrodo                        
    bValorAlcanzado=structControlTiempo.sbValorAlcanzado=0;     // Inicializo flag de valor de corriente alcanzado              
    i16ErroresOcurridos&=~ERROR_ELECTRODO_CHB;                  // Inicializo flag de error de electrodo                        
}

/*
*   Funci�n: apagadoCHC
*   Descripci�n: Apaga el canal C
*        
*   Input:
*       - 
*   Output:
*       -
*/
void apagadoCHC(){
    if(!i8CanalesActivados && !bPausaTratamiento){              // Si ya no hay m�s canales activados y no se encuentra en pausa
        control_DC(0,EN_30);                                    // Apagado DC 30 V   
        bEmpiezaContadorTiempo=0;                               // Inicializo flag contador de tiempo tratamiento
        bPausaTratamiento=0;                                    // Inicializo flag pausa
        structMedidasElectro.si16IMedElec[CHC_C][PULSO_POS]=0;  // Inicializo variables de corriente    
        structMedidasElectro.si16IMedElec[CHC_C][PULSO_NEG]=0;  // Inicializo variables de corriente 
        structMedidasElectro.si16VMedElec[CHC_C][PULSO_POS]=0;  // Inicializo variables de tensi�n     
        structMedidasElectro.si16VMedElec[CHC_C][PULSO_NEG]=0;  // Inicializo variables de tensi�n 
        if(i16IElec[CHC_C]>20){                                 // Si es mayor de 1mA
            i16IElec[CHC_C]=20;                                 // Fija a 1mA, sino, mantiene el valor
        }
    }        
    bPrimeraMedida=0;                                           // Inicializo flag primera medida
    i8ReposoActivados&=~CANALES_C;                              // Inicializo flag de reposo del canal
    control_rele(0,rele_CHC);                                   // Apagado rele canal
    control_led(0,verde,led_CHC);                               // Apagado LED verde canal
    bErrorElectrodo[CHC_C]=0;                                   // Inicializo flag de error de electrodo
    bValorAlcanzado=structControlTiempo.sbValorAlcanzado=0;     // Inicializo flag de valor de corriente alcanzado
    i16ErroresOcurridos&=~ERROR_ELECTRODO_CHC;                  // Inicializo flag de error de electrodo
}

/*
*   Funci�n: apagadoCanales
*   Descripci�n: Apagado de todos los canales activos en electroestimulaci�n 
*        
*   Input:
*       - 
*   Output:
*       -
*/
void apagadoCanales(){
    switch(i8CanalesActivados){     // Dependiendo del n�mero de canales activados
        case CANALES_A:             // Canal A
            apagadoCHA();           // Apagado canal
            break;
        case CANALES_B:             // Canal B
            apagadoCHB();           // Apagado canal
            break;
        case CANALES_C:             // Canal C
            apagadoCHC();           // Apagado canal
            break;
        case CANALES_AB:            // Canal A y B
            apagadoCHA();           // Apagado canal
            apagadoCHB();           // Apagado canal
            break;
        case CANALES_BC:            // Canal B y C
            apagadoCHB();           // Apagado canal
            apagadoCHC();           // Apagado canal
            break;
        case CANALES_AC:            // Canal A y C
            apagadoCHA();           // Apagado canal
            apagadoCHC();           // Apagado canal
            break;
        case CANALES_ABC:           // Canal A, B y C
            apagadoCHA();           // Apagado canal
            apagadoCHB();           // Apagado canal
            apagadoCHC();           // Apagado canal
            break;   
        case CANALES_P:             // Canal P
            apagadoCHA();           // Apagado canal
            break;
        case CANALES_BP:            // Canal B y C
            apagadoCHB();           // Apagado canal
            apagadoCHA();           // Apagado canal
            break;
        case CANALES_CP:            // Canal A y C
            apagadoCHA();           // Apagado canal
            apagadoCHC();           // Apagado canal
            break;
        case CANALES_BCP:           // Canal A, B y C
            apagadoCHA();           // Apagado canal
            apagadoCHB();           // Apagado canal
            apagadoCHC();           // Apagado canal     
            break;   
    }
    i8CanalesActivados=0;           // Inicializo variable de canales activados
    i8ReposoActivados=0;            // Inicializo variable de canales en reposo
}

/*
*   Funci�n: maxPulsosSMP
*   Descripci�n: Indica el n�mero m�ximo d epulsos que podemos realizar 
*       en un tratamiento SMP dependiendo del valor de la frecuencia 
*       y el tiempo de desfase
*        
*   Input:
*       - 
*   Output:
*       -
*/
void maxPulsosSMP(){
    float fCalculoRaw;                                              // Variable auxiliar para el c�lculo
    
    fCalculoRaw=1000000/((float)i16FrecSMP*i32TDesfaseSMP);         // Obtencion del m�ximo n�mero de pulsos
    i8MaxPulsosSMP=(int16)fCalculoRaw;                              // M�ximo n�mmero de pulsos
}

/*
*   Funci�n: copiarDatosSimetria
*   Descripci�n: Copia los datos principales al seleccionar simetr�a entre canales
*        
*   Input:
*       - bTiempo (DEBUG ONLY)                       
*           - 1 - Copia los valores de tiempo    
*           - 0 - No copia los valores de tiempo 
*
*   Output:
*       -
*/
void copiarDatosSimetria(int1 bTiempo){
    switch(i8SimetriaCanales){                                                      // Dependiendo de la simetria entre canales elegida
        case 1:                                                                     // Canales AB
            if(bTiempo){                                                            // Si queremos copiar los valores de tiempo
                i16TacElec[CHB_C]=i16TacElec[CHA_C];                                // Copiamos tiempo activo
                i16TdElec[CHB_C]=i16TdElec[CHA_C];                                  // Copiamos tiempo descanso
                i8TrElec[CHB_C]=i8TrElec[CHA_C];                                    // Copiamos tiempo de rampa
                i8Nrep[CHB_C]=i8Nrep[CHA_C];                                        // Copiamos n�mero de repeticiones
            }
            
            i16FrecElec[CHB_C]=i16FrecElec[CHA_C];                                  // Copiamos el valor de frecuencia

            bSimetriaElec[CHB_C]=bSimetriaElec[CHA_C];                              // Copiamos la simetria de se�al
            bPolaridadElec[CHB_C]=bPolaridadElec[CHA_C];                            // Copiamos la polaridad de se�al
            i16PW_plusElec[CHB_C]=i16PW_plusElec[CHA_C];                            // Copiamos el PW+
            i16PW_minusElec[CHB_C]=i16PW_minusElec[CHA_C];                          // Copiamos el PW-
            break;
        case 2:                                                                     // Canales ABC
            if(bTiempo){                                                            // Si queremos copiar los valores de tiempo
                i16TacElec[CHC_C]=i16TacElec[CHB_C]=i16TacElec[CHA_C];              // Copiamos tiempo activo                  
                i16TdElec[CHC_C]=i16TdElec[CHB_C]=i16TdElec[CHA_C];                 // Copiamos tiempo descanso                
                i8TrElec[CHC_C]=i8TrElec[CHB_C]=i8TrElec[CHA_C];                    // Copiamos tiempo de rampa                
                i8Nrep[CHC_C]=i8Nrep[CHB_C]=i8Nrep[CHA_C];                          // Copiamos n�mero de repeticiones         
            }                                                                                                                  
                                                                                                                               
            i16FrecElec[CHC_C]=i16FrecElec[CHB_C]=i16FrecElec[CHA_C];               // Copiamos el valor de frecuencia         
                                                                                                                               
            bSimetriaElec[CHC_C]=bSimetriaElec[CHB_C]=bSimetriaElec[CHA_C];         // Copiamos la simetria de se�al           
            bPolaridadElec[CHC_C]=bPolaridadElec[CHB_C]=bPolaridadElec[CHA_C];      // Copiamos la polaridad de se�al          
            i16PW_plusElec[CHC_C]=i16PW_plusElec[CHB_C]=i16PW_plusElec[CHA_C];      // Copiamos el PW+                         
            i16PW_minusElec[CHC_C]=i16PW_minusElec[CHB_C]=i16PW_minusElec[CHA_C];   // Copiamos el PW-                         
            break;
    }
}

/*
*   Funci�n: comprobacionLimitesFrecuencia
*   Descripci�n: Comprueba los l�mites de frecuencia para cada canal 
*       cuando hay varios canales activados
*        
*   Input:
*       - 
*   Output:
*       -
*/
void comprobacionLimitesFrecuencia(){
    switch(i8CanalesConfigurados){                          // Dependiendo del n�emro de canales activados
        case 0:                                             // Si no hay nada configurado, inicializo los l�mites
            i16FrecLimSup[CHA_C]=1000;                      // Ajusto l�mite superior
            i16FrecLimInf[CHA_C]=2;                         // Ajusto l�mite inferior
            i16FrecLimSup[CHB_C]=1000;                      // Ajusto l�mite superior
            i16FrecLimInf[CHB_C]=2;                         // Ajusto l�mite inferior
            i16FrecLimSup[CHC_C]=1000;                      // Ajusto l�mite superior
            i16FrecLimInf[CHC_C]=2;                         // Ajusto l�mite inferior
            i16FrecLimSup[POINTER_C]=150;                   // Ajusto l�mite superior
            i16FrecLimInf[POINTER_C]=2;                     // Ajusto l�mite inferior
            break;
        case CHA_ACT:                                       // Si est� el CHA configurado, ponemos l�mites B y C
            i16FrecLimSup[CHB_C]=1000;                      // Ajusto l�mite superior
            i16FrecLimInf[CHB_C]=i16FrecElec[CHA_C];        // Ajusto l�mite inferior
            i16FrecLimSup[CHC_C]=1000;                      // Ajusto l�mite superior         
            i16FrecLimInf[CHC_C]=i16FrecElec[CHA_C];        // Ajusto l�mite inferior
            break;
        case CHB_ACT:                                       // Si est� el CHB configurado, ponemos l�mites A y C
            i16FrecLimSup[CHA_C]=i16FrecElec[CHB_C];        // Ajusto l�mite superior
            i16FrecLimInf[CHA_C]=2;                         // Ajusto l�mite inferior
            i16FrecLimSup[CHC_C]=1000;                      // Ajusto l�mite superior
            i16FrecLimInf[CHC_C]=i16FrecElec[CHB_C];        // Ajusto l�mite inferior
            i16FrecLimSup[POINTER_C]=i16FrecLimSup[CHA_C];  // Ajusto l�mite superior
            if(i16FrecLimSup[POINTER_C]>=150){              // Si la frecuencia del l�mite superior del pointer es mayor a 150 Hz
                i16FrecLimSup[POINTER_C]=150;               // Ajusto l�mite superior a su m�ximo
            }   
            i16FrecLimInf[POINTER_C]=2;                     // Ajusto l�mite inferior
            break;
        case CHC_ACT:                                       // Si est� el CHC configurado, ponemos l�mites A y B
            i16FrecLimSup[CHA_C]=i16FrecElec[CHC_C];        // Ajusto l�mite superior                                            
            i16FrecLimInf[CHA_C]=2;                         // Ajusto l�mite inferior                                            
            i16FrecLimSup[CHB_C]=i16FrecElec[CHC_C]; ;      // Ajusto l�mite superior                                            
            i16FrecLimInf[CHB_C]=2;                         // Ajusto l�mite inferior                                            
            i16FrecLimSup[POINTER_C]=i16FrecLimSup[CHA_C];  // Ajusto l�mite superior                                            
            if(i16FrecLimSup[POINTER_C]>=150){              // Si la frecuencia del l�mite superior del pointer es mayor a 150 Hz
                i16FrecLimSup[POINTER_C]=150;               // Ajusto l�mite superior a su m�ximo                                
            }                                                                                                                    
            i16FrecLimInf[POINTER_C]=2;                     // Ajusto l�mite inferior                                            
            break;
        case POINTER_ACT:                                   // Si est� el POINTER configurado, ponemos l�mites B y C
            i16FrecLimSup[CHB_C]=1000;                      // Ajusto l�mite superior
            i16FrecLimInf[CHB_C]=i16FrecElec[POINTER_C];    // Ajusto l�mite inferior
            i16FrecLimSup[CHC_C]=1000;                      // Ajusto l�mite superior
            i16FrecLimInf[CHC_C]=i16FrecElec[POINTER_C];    // Ajusto l�mite inferior
            break;
        case CHA_ACT | CHB_ACT:                             // Si est� el CHA y CHB configurado, ponemos l�mites C
            i16FrecLimSup[CHC_C]=1000;                      // Ajusto l�mite superior
            i16FrecLimInf[CHC_C]=i16FrecElec[CHB_C];        // Ajusto l�mite inferior
            break;
        case CHB_ACT | CHC_ACT:                             // Si est� el CHB y CHC configurado, ponemos l�mites A
            i16FrecLimSup[CHA_C]=i16FrecElec[CHB_C];        // Ajusto l�mite superior
            i16FrecLimInf[CHA_C]=2;                         // Ajusto l�mite inferior
            i16FrecLimSup[POINTER_C]=i16FrecLimSup[CHA_C];  // Ajusto l�mite superior
            if(i16FrecLimSup[POINTER_C]>=150){              // Si la frecuencia del l�mite superior del pointer es mayor a 150 Hz
                i16FrecLimSup[POINTER_C]=150;               // Ajusto l�mite superior a su m�ximo                                
            }                                                                                                                    
            i16FrecLimInf[POINTER_C]=2;                     // Ajusto l�mite inferior                                            
            break;
        case CHA_ACT | CHC_ACT:                             // Si est� el CHA y CHC configurado, ponemos l�mites B
            i16FrecLimSup[CHB_C]=i16FrecElec[CHC_C];        // Ajusto l�mite superior
            i16FrecLimInf[CHB_C]=i16FrecElec[CHA_C];        // Ajusto l�mite inferior
            break;
        case POINTER_ACT | CHB_ACT:                         // Si est� el POINTER y CHB configurado, ponemos l�mites C
            i16FrecLimSup[CHC_C]=1000;                      // Ajusto l�mite superior
            i16FrecLimInf[CHC_C]=i16FrecElec[CHB_C];        // Ajusto l�mite inferior
            break;
        case POINTER_ACT | CHC_ACT:                         // Si est� el POINTER y CHC configurado, ponemos l�mites B
            i16FrecLimSup[CHB_C]=i16FrecElec[CHC_C];        // Ajusto l�mite superior
            i16FrecLimInf[CHB_C]=i16FrecElec[POINTER_C];    // Ajusto l�mite inferior
            break;
    }
    
    for(int8 i8Cont=0; i8Cont<4; i8Cont++){                     // Recorro todos los canales (3 EESTIM + POINTER)
        if(i16FrecElec[i8Cont]>=i16FrecLimSup[i8Cont]){         // Si la frecuencia de ese canal es superior o igual al l�mite superior para ese canal
            i16FrecElec[i8Cont]=i16FrecLimSup[i8Cont];          // Ajustamos al l�mite superior
        }else if(i16FrecElec[i8Cont]<=i16FrecLimInf[i8Cont]){   // Si no, si la frecuencia de ese canal es inferior o igual al l�mite inferior para ese canal
            i16FrecElec[i8Cont]=i16FrecLimInf[i8Cont];          // Ajustamos al l�mite inferior
        }
    }
}

/*
*   Funci�n: isPower12OK
*   Descripci�n: Comprueba el estado del DC/DC de 12V
*        
*   Input:
*       - 
*   Output:
*       - Devuelve 1 si la tensi�n de 12V est� encendida y bien
*       - Devuelve 0 si la tensi�n de 12V est� apagada o no OK
*/
int1 isPower12OK(){
    return !input_state(POK_12V);   // Devuelve el estado del DC/DC
}

/*
*   Funci�n: isPower30OK
*   Descripci�n: Comprueba el estado del DC/DC de 30V
*        
*   Input:
*       - 
*   Output:
*       - Devuelve 1 si la tensi�n de 30V est� encendida y bien
*       - Devuelve 0 si la tensi�n de 30V est� apagada o no OK
*/
int1 isPower30OK(){
    return !input_state(POK_30V);   // Devuelve el estado del DC/DC
}

/*
*   Funci�n: reset_orco
*   Descripci�n: Resetea el PIC Orco
*        
*   Input:
*       - 
*   Output:
*       -
*/
void reset_orco(){
    output_high(RST_ORCO);      // Pone a nivel alto el reset (resetea)
    delay_ms(50);               // Espera del reset
    output_low(RST_ORCO);       // Pone a nivel bajo el reset (normal)
}

/*
*   Funci�n: pitidoCorto
*   Descripci�n: Pitido corto
*        
*   Input:
*       - 
*   Output:
*       -
*/
void pitidoCorto(){
    controlSonido(1);           // Enciende el pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    controlSonido(0);           // Apaga el pito
}

/*
*   Funci�n: pitidoLargo
*   Descripci�n: Pitido largo
*        
*   Input:
*       - 
*   Output:
*       -
*/
void pitidoLargo(){
    controlSonido(1);           // Enciende el pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    controlSonido(0);           // Apaga el pito
}

/*
*   Funci�n: pitidoPointerConectado
*   Descripci�n: Pitido cuando el pointer se conecta a la carga
*        
*   Input:
*       - 
*   Output:
*       -
*/
void pitidoPointerConectado(){
    controlSonido(1);           // Enciende el pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    controlSonido(0);           // Apaga el pito
}

/*
*   Funci�n: pitidoPointerDesconectado
*   Descripci�n: Pitido cuando el pointer se deconecta de la carga
*        
*   Input:
*       - 
*   Output:
*       -
*/
void pitidoPointerDesconectado(){
    controlSonido(1);           // Enciende el pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    pausa_I(DURACION_PITIDO);   // Espera del pito
    controlSonido(0);           // Apaga el pito
}                               
