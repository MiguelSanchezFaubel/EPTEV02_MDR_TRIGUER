/*
*    File: comunicacionOS.h
*    
*    Descripción: Header file que describe los parámetros 
*        necesarios para la comunicación Orco->Sauron
*    
*    Proyecto:EPTE V2
*    Versión: 1.0
*
*    Ionclinics & Deionics SL
*/

/******************************** Definicion de constantes/enum/struct *****************************************/
// enum eModos: Identifica el tipo de dato que se va a enviar de Orco a Sauron
enum eMODOS{
   M_CHECK_ALIVE=0,         // 0: Comprueba que se encuentra correctamente la comunicaci�n entre los dos microcontroladores
   M_START,                 // 1: Empieza el tratamiento
   M_STOP,                  // 2: Para el tratamiento activo
   M_CONFIG_TRAT,           // 3: Configura el tratamiento
   M_CONFIG_TRAT_ACT,       // 4: Configura el tratamiento activo TODO : ES NECESARIO? PUEDE QUE CON EL COMANDO ANTERIOR VALGA
   M_TEST,                  // 5: Selecciona el men� de test
   M_CONFIGURACION,         // 6: Selecciona el men� de configuraci�n  
   M_ACK,                   // 7: Selecciona el modo de env�o del ACK
   M_ERRORES,               // 8: Selecciona el modo de env�o de errores
   M_CHECKSUM,              // 9: Selecciona el modo de env�o de checksum
   M_CORRIENTE_ACT,         // 10: Modo de env�o de lectura de corriente
};   // 4 bits
#define LENGTH_MODES 4   // Indica el tama�o en bits que ocupa

// enum eCHANNEL: Identifica el canal/es elegidos
enum eCANAL{
   CH_A=0,              // 0: Canal A              
   CH_B,                // 1: Canal B  
   CH_C,                // 2: Canal C 
   CH_AB,               // 3: Canal A + Canal B  
   CH_AC,               // 4: Canal A + Canal C 
   CH_BC,               // 5: Canal B + Canal C
   CH_ABC,              // 6: Canal A + Canal B + Canal C
   CH_GALVANICA,        // 7: Galvanica
   CH_MICROCORRIENTES,  // 8: Microcorrientes
   CH_POINTER=8,        // 8: Pointer ++
};   // 4 bits
#define LENGTH_CHANNEL 4      // Indica el tama�o en bits que ocupa

/* ++ El Pointer comparte el mismo valor que microcorrientes debido a que de esta manera 
    podemos usarlo como indicador para saber cuando se ha elegido el pointer junto con los
    canales elegidos realizando la operación OR.
    Ej:
        envioCanales(POINTER | CH_AB); 
    En la función anterior se indica que se va a utilizar el canal A y B, siendo uno de ellos el pointer
*/

// enum: ---- DUDA: GASTEM ENUM PER A LA CORRENT?
enum eCORRIENTE{

};

// enum: ----
enum eFRECUENCIA{

};

// enum: ePOLARIDAD
enum ePOLARIDAD{
    MONOPOLAR=0,            // 0: Monopolar            
    BIPOLAR,                // 1: Bipolar
};    // 1 bit
#define LENGTH_POLARIDAD 1    // Indica el tamaño en bits que ocupa 

// enum eSIMETRIA:  
enum eSIMETRIA{
    ASIMETRICA=0,            // 0: Asimetrica
    SIMETRICA,                // 1: Simétrica
};    // 1 bit
#define LENGTH_SIMETRIA 1    // Indica el tamaño en bits que ocupa 

// enum eSIMETRIA_CANALES:  
enum eSIMETRIA_CANALES{
    CANAL_ASIMETRICO=0,            // 0: Asimetrica
    CANAL_SIMETRICO,            // 1: Simétrica
};    // 1 bit
#define LENGTH_SIMETRIA_CANALES 1    // Indica el tamaño en bits que ocupa 

// enum eERRORES: Indica el tipo de error que hay en ese momento
enum eERRORES{                
    NO_ERROR=0,                // 0: Sin error
    ERROR_ELECTRODO,        // 1: Error de electrodo
    ERROR_SIMETRIA,            // 2: Error de simetría
    ERROR_CALIBRADO,            // 3: Error de calibrado
    ERROR_ACELEROMETRO,        // 4: Error de acelerómetro / caida libre
    ERROR_NOACK,                // 5: Error de no recepción del ACK
    ERROR_DESCONOCIDO,        // 6: Error desconocido, usado en casos que no tienen que ocurrir, pero para eliminar futuros problema
};    // 3 bits
#define LENGTH_ERRORES 3    // Indica el tamaño en bits que ocupa 

// enum eMENU_TEST: Indica las diferentes opciones del men� de test que existen
enum eMENU_TEST{
    T_LEDS=0,             // 0: Test de los LEDs  
    T_SONIDO,             // 1: Test de sonido
    T_PULSADORES,         // 2: Test de pulsadores
    T_PANTALLA,           // 3: Test de pantalla
    T_ACELEROMETRO,       // 4: Test de aceler�metro
    T_ALIM_EXT,           // 5: Test de alimentaci�n externa
    T_STATUS_CARGADOR,    // 6: Test de cargador
    T_DC12V,              // 7: Test del DC/DC de 12 V
    T_DC30V,              // 8: Test del DC/DC de 30 V 
    T_RELES,              // 9: Test de los rel�s
    T_BQ34Z100,           // 10: Test del BQ34Z100     
    T_COMUN_PIC,          // 11: Test de comunicaci�n entre Sauron y Orco    
};  // 4 bits
#define LENGTH_MENU_TEST 4  // Indica el tana�o en bytes que ocupa

// enum eMENU_CONFIG: Indica las diferentes opciones del men� de congiguraci�n que existen
enum eMENU_CONFIG{
    VOLUMEN=0,          // 0: Modifica el nivel de volumen del equipo
    BRILLO,             // 1: Modifica el brillo de la pantalla
    VERSION,            // 2: Muestra la version de hardware/firmware
};  // 2 bits
#define LENGTH_MENU_CONFIG 2    // Indica el tama�o en bytes que ocupa

// Definición de máscaras
#define MASK_SIMETRIA_CANALES       0x40        // Máscara utilizada para seleccionar el bit de simetría de canales
#define MASK_SIMETRIA               0x20        // Máscara utilizada para seleccionar el bit de simetría
#define MASK_POLARIDAD              0x10        // Máscara utilizada para seleccionar el bit de polaridad
#define MASK_CANAL                  0x0F        // M�scara utilizada para seleccionar los bits del canal
#define MSB                         0xFF00        // Máscara utilizada para seleccionar el MSB de un int16
#define LSB                         0x00FF        // Máscara utilizada para seleccionar el LSB de un int16

// Listado de comandos
#define COMANDO_CONFIG_TRAT         0x55        // Comando de configuraci�n de tratamiento
#define COMANDO_CONFIG_TRAT_ACT     0x56        // Comando de configuraci�n de tratamiento en activo
#define COMANDO_START               0xAA        // Comando de START
#define COMANDO_STOP                0xBB        // Comando de STOP
#define COMANDO_CHECK_ALIVE         0xCA        // Comando Check Alive
#define COMANDO_CHECKSUM            0xC5        // Comando CHECKSUM
#define COMANDO_ACK                 0xCC        // Comando identificador del ACK
#define COMANDO_ERRORES             0xEE        // Comando identificador de que se va a recibir un error
#define COMANDO_CONFIGURACION       0x11        // Conando para acceder al men� de configuraci�n
#define COMANDO_TEST                0x12        // Comando para acceder al men� de test 
#define COMMAND_CORRIENTE_MED       0x13        // Comando para identificar que se env�a corriente medida


// Definiciones Buffer entrada datos
#define BUFFER_SIZE 32                  // Se define un buffer de 32 bytes
int8 gi8BufferData[BUFFER_SIZE]={0};        // Crea un buffer de BUFFER_SIZE bytes de tipo int8
int8 gi8BufferIndex=0;                  // Indice de los datos del buffer, indica el n�mero de bytes a leer
int1 bDatoRecibido=0;                   // Indica si los datos ya est�n disponibles para leer (1) o no (0)

// Otras definiciones
//#define CHECKSUM                            // Si está descomentado, se hace uso del checksum

#ifdef CHECKSUM                             // Si se ha definido el uso de CHECKSUM
int8 gi8CheckSum;                           // Crea la variable para el checksum
#endif
int8 gi8NumeroBytesLeer;                    // Indica el n�mero de bytes a leer de la trama recibida
int8 gi8Secuencia=0;                        // Variable global utilizada como seguidor de secuencia para saber que capturar y como procesar los datos
int8 gi8NumeroCanalesConfigurar;            // Variable que indica el n�mero de canales a configurar dependiendo de la selecci�n hecha en Sauron

// Variables prueba recepcion datos
int8 i8Canal; 
int16 i16TiempoActivo; 
int8 i8TiempoReposo; 
int8 i8TiempoRampa; 
int8 i8Repeticiones;
int16 i16Corriente; 
int16 i16Frecuencia; 
int1 bSimetria; 
int1 bPolaridad; 
int16 i16PWP; 
int16 i16PWN; 
int1 bSimetriaCanales;
/********************************* Prototipo de funciones ***********************************************/

/*
*    Función: procesaComando
*
*    Descripción: Procesa el comando recibido desde Sauron 
*
*    Parámetros de entrada:
*        - i8Received    - Le pasa el valor recibido por UART 
*
*    Parámetros de salida:
*        - int8        - Devuelve un valor a comparar con la enum eERRORES
*/
int8 procesaComando();

/*
*    Función: procesaAsignacionCanales
*
*    Descripción: Procesa el n�mero de canales a configurar
*
*    Parámetros de entrada:
*        - 
*
*    Parámetros de salida:
*        - int8        - Devuelve un valor a comparar con la enum eERRORES
*/
int8 procesaAsignacionCanales();

/*
*    Función: procesaConfiguracionCanal
*
*    Descripción: Procesa la configuraci�n del canal enviada desde Sauron
*
*    Parámetros de entrada:
*        - 
*
*    Parámetros de salida:
*        - int8        - Devuelve un valor a comparar con la enum eERRORES
*/
int8 procesaConfiguracionCanal();

/*
*    Función: seleccionMenuTest
*
*    Descripción: Selecciona el menu recibido por la selecci�n en Sauron
*
*    Parámetros de entrada:
*           - i8MenuTest   - Men� a realizar test de la lista del enum eMENU_TEST
*
*    Parámetros de salida:
*           - int8         - Devuelve un valor a comparar con la enum eERRORES
*/
int8 seleccionMenuTest(int8 i8MenuTest);

/*
*    Función: seleccionMenuConfiguracion
*
*    Descripción: Selecciona el menu recibido por la selecci�n en Sauron
*
*    Parámetros de entrada:
*           - i8MenuConfig 
*
*    Parámetros de salida:
*        - int8        - Devuelve un valor a comparar con la enum eERRORES
*/
int8 seleccionMenuConfiguracion(int8 i8MenuConfig);
