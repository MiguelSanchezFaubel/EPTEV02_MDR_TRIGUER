/*
*    File: comunicacionOS.c
*    
*    Descripción: Program file que describe los parámetros 
*        necesarios para la comunicación Orco->Sauron
*    
*    Proyecto:EPTE V2
*    Versión: 1.0
*
*    Ionclinics & Deionics SL
*/

#include "comunicacionOS.h"

int8 procesaComando(){ 

    int8 i8Return;

    switch(gi8BufferData[0]){
        case M_CHECK_ALIVE:                             // Compruueba la comunicaci�n entre Orco y Sauron
            fputc(COMANDO_CHECK_ALIVE,COM_PIC_UART);    // Envia el comando Check Alive
            fputc('\r',COM_PIC_UART);                   // Env�a la secuencia de finalizaci�n de trama
            fputc('\n',COM_PIC_UART);
            i8Return=NO_ERROR;                          // Indica que no hay error
            break;  
        case M_START:                                   // Secuencia de incio de tratamiento
            // TODO: Start tratamiento
            i8Return=NO_ERROR;                          // Indica que no hay error
            break;          
        case M_STOP:                                    // Secuencia de parada de tratamiento
            // TODO: Stop tratamiento
            i8Return=NO_ERROR;                          // Indica que no hay error
            break;           
        case M_CONFIG_TRAT:                             // Configuraci�n de tratamiento
            // TODO: Configuraci�n tratamiento
            break;    
        case M_CONFIG_TRAT_ACT:                         // Configuraci�n de tratamiento activo
            // Configuraci�n tratamiento activo
            break;
        case M_TEST:                                    // Selecci�n del men� de test
            // Selecci�n del men� de test elegido
            while(!bDatoRecibido);                      // Espera a recibir la selecci�n del men�
            bDatoRecibido=0;                            // Inicializo el valor de dato recibido
            // TODO: Men� seleccionado
            seleccionMenuTest(gi8BufferData[0]);
            break;           
        case M_CONFIGURACION:                           // Selecci�n del men� de configuraci�n
            // Selecci�n del men� de configuraci�n elegido
            while(!bDatoRecibido);                      // Espera a recibir la selecci�n del men� de configuraci�n
            bDatoRecibido=0;                            // Inicializo el valor de dato recibido
            // TODO: Men� seleccionado
            break;  
        case M_ACK:                                     // Recepci�n de ACK
            i8Return=NO_ERROR;                          // Indica que no hay error
            break;            
        case M_ERRORES:                                 // Recepci�n de errores
            // Selecciona el error ocurrido
            while(!bDatoRecibido);                      // Espera a recibir el error que le est� enviando
            bDatoRecibido=0;                            // Inicializo el valor de dato recibido
            // TODO: Error seleccionado
            break;        
#ifdef CHECKSUM
        case M_CHECKSUM:                                // Recepci�n del checksum
            // Recibo el valor de checksum
            while(!bDatoRecibido);                      // Espero a recibir el dato
            bDatoRecibido=0;                            // Inicializo el valor de dato recibido
            // TODO: Checksum
            if(checksumOK){                             // En el caso de que el cheksum sea correcto
                i8Return=NO_ERROR;                      // Devuelve que no hay error
            }else{                                      // En el caso de que exista error
                i8Return=ERROR_NOACK;                   // Indica que ha ocurrido un error
                // TODO: Enviar comando error
            }
            break;  
#endif
        default:                                        // En el caso de que se seleccione una opci�n no v�lida
            i8Return=ERROR_DESCONOCIDO;                 // Devuelve error desconocido
    }

    if(NO_ERROR == i8Return){                           // Si no ha ocurrido ning�n error
        fputc(COMANDO_ACK,COM_PIC_UART);                // Enviamos el comando ACK
        fputc('\r',COM_PIC_UART);                       // Enviamos la secuencia de fin de trama \r\n
        fputc('\n',COM_PIC_UART);
    }else{                                              // Si ha ocurrido alg�n error
        if(ERROR_DESCONOCIDO != i8Return){              // En el caso de que sea distinto a un error desconocido
            i8Return=ERROR_NOACK;                       // Devueleve el error NO ACK
        }                                               // De esta forma, si existe un error desconocido, lo podemos detectar si nque lo machaque
    }
    
    return i8Return;
}

int8 procesaAsignacionCanales(){

    int8 i8Return;
    
    // Se recibe un byte con el canal especificado de eCANALES
    
    switch(gi8BufferData[0]){
        case CH_A:                          // Bloque de 1 Canal
        case CH_B:
        case CH_c:
            gi8NumeroCanalesConfigurar=1;   // N�mero de canales a configurar
            i8Return=NO_ERROR;              // Devuelve NO ERROR
            break;
        case CH_AB:                         // Bloque de 2 canales   
        case CH_AC:
        case CH_BC:                 
            gi8NumeroCanalesConfigurar=2;   // N�mero de canales a configurar
            i8Return=NO_ERROR;
            break;
        case CH_ABC:                        // Bloque de 3 canales
            gi8NumeroCanalesConfigurar=3;   // N�mero de canales a configurar
            break;
        default:                            // En el caso de que ocurra un erro desconocido
            i8Return=ERROR_DESCONOCIDO;     // Indicamos que hay un error deconocido
    }
    
    if(NO_ERROR == i8Return){
        fputc(COMANDO_ACK,COM_PIC_UART);            // Envia ACK
        fputc('\r',COM_PIC_UART);
        fputc('\n',COM_PIC_UART);
        i8Return=NO_ERROR;
    }else{
        if(ERROR_DESCONOCIDO != i8Return){
            i8Return=ERROR_NOACK;
        }
    }
    
    return i8Return;
}

int8 procesaConfiguracionCanal(){

    int8 i8Return=NO_ERROR;
    
    // Primer paquete (8bits) (Simetr�a entre canales | Simetr�a | Polaridad | Canal)
    bSimetriaCanales=MASK_SIMETRIA_CANALES & gi8BufferData[0];
    bSimetria=MASK_SIMETRIA & gi8BufferData[0];
    bPolaridad=MASK_POLARIDAD & gi8BufferData[0];
    i8Canal=MASK_CANAL & gi8BufferData[0];
    
    // Segundo paquete (16 bits) (TiempoActivo)
    i16TiempoActivo=make16(gi8BufferData[1],gi8BufferData[2]); 
    
    // Tercer paquete (8 bits) (TiempoReposo)
    i8TiempoReposo=gi8BufferData[3]; 
    
    // Cuarto paquete (8 bits) (TiempoRampa)
    i8TiempoRampa=gi8BufferData[4]; 
    
    // Quinto paquete (8 bits) (Repeticiones)
    i8Repeticiones=gi8BufferData[5];
    
    // Sexto paquete (16 bits) (Corriente)
    i16Corriente=make16(gi8BufferData[6],gi8BufferData[7]); 
    
    // S�ptimo paquete (16 bits) (Frecuencia)
    i16Frecuencia=make16(gi8BufferData[8],gi8BufferData[9]);  
    
    // Octavo paquete (16 bits) (PW+)
    i16PWP=make16(gi8BufferData[10],gi8BufferData[11]);  
    
    // Noveno paquete (16 bits) (PW-)
    i16PWN=make16(gi8BufferData[12],gi8BufferData[13]);  

    fputc(COMANDO_ACK,COM_PIC_UART);            // Envia ACK
    fputc('\r',COM_PIC_UART);                   // Env�a secuencia de fin de trama \r\n
    fputc('\n',COM_PIC_UART);

    return i8Return;
}


int8 seleccionMenuTest(int8 i8MenuTest){

    int8 i8Return;
    // TODO: Tot
    switch(i8MenuTest){
        case T_LEDS:                  // Comprobaci�n de los LEDs indicadores de tratamiento
            i8Return=NO_ERROR;
            break;             
        case T_SONIDO:                // Comprobaci�n del pito
            i8Return=NO_ERROR;
            break;             
        case T_PULSADORES:            // comprobaci�n de los pulsadores
            i8Return=NO_ERROR;
            break;         
        case T_PANTALLA:              // Comprobaci�n de pantalla
            i8Return=NO_ERROR;
            break;           
        case T_ACELEROMETRO:          // Comprobaci�n del aceler�metro
            i8Return=NO_ERROR;
            break;       
        case T_ALIM_EXT:              // Comprobaci�n de la alimentaci�n externa
            i8Return=NO_ERROR;
            break;           
        case T_STATUS_CARGADOR:       // Comprobaci�n del estado del cargador
            i8Return=NO_ERROR;
            break;    
        case T_DC12V:                 // Comprobaci�n del DC/DC de 12V
            i8Return=NO_ERROR;
            break;              
        case T_DC30V:                 // Comprobaci�n del DC/DC de 30V
            i8Return=NO_ERROR;
            break;              
        case T_RELES:                 // Comprobaci�n de los rel�s
            i8Return=NO_ERROR;
            break;              
        case T_BQ34Z100:              // Comprobaci�n del puto BQ34Z100
            i8Return=NO_ERROR;
            break;           
        case T_COMUN_PIC:             // Comprobaci�n de la comunicaci�n entre orco y sauron
            i8Return=NO_ERROR;
            break;   
        default:
            i8Return=ERROR_DESCONOCIDO;
    }

    return i8Return;
}


int8 seleccionMenuConfiguracion(int8 i8MenuConfig){

    int8 i8Return;
    // TODO: Tot
    switch(i8MenuConfig){
        case VOLUMEN:               // Control del volumen del pito
            i8Return=NO_ERROR;
            break;             
        case BRILLO:                // Control del brillo de la pantalla
            i8Return=NO_ERROR;
            break;                
        case VERSION:               // Muestra la versi�n de HW/FW por pantalla
            i8Return=NO_ERROR;
            // Mostrar HW
            // Mostrar FW Orco
            // Mostrar FW Sauron
            break;   
        default:
            i8Return=ERROR_DESCONOCIDO;
    }
    
    return i8Return;
}

int8 enviaComando(int8 i8Modo,int8 i8Comando){

    int8 i8Return;
    
    switch(i8Modo){
        case M_ERRORES:                                     // Envio de errores
            fputc(COMANDO_ERRORES,COM_PIC_UART);            // Env�o el comando indicando que voy a enviar un error
            fputc('\r',COM_PIC_UART);                       // Env�o la secuencia de fin de trama \r\n
            fputc('\n',COM_PIC_UART);
            while(!bDatoRecibido);                          // Espero a recibir ACK
            bDatoRecibido=0;                                // Inicializo el valor de dato recibido
            i8Return=gi8BufferData[0];                      // Guardo el valor del buffer de entrada
            if(COMANDO_ACK == i8Return){                    // Si se trata del ACK
                fputc(i8Comando,COM_PIC_UART);              // Env�o el c�digo de error que quiero indicar
                fputc('\r',COM_PIC_UART);                   // Env�o la secuencia de fin de trama \r\n
                fputc('\n',COM_PIC_UART);
                while(!bDatoRecibido);                      // Espero a recibir ACK
                bDatoRecibido=0;                            // Inicializo el valor de dato recibido
                i8Return=gi8BufferData[0];                  // guardo el valor del buffer de entrada
            }else{                                          // En caso de que ocurra error
                i8Return = ERROR_NOACK;                     // Indicamos que no se ha recibido el ACK
            }
            break;
        default:                                            // En el caso de que se haga una selecci�n incorrecta
            i8Return=ERROR_DESCONOCIDO;                     // Mostramos el error desconocido
    }
    
    if(COMANDO_ACK == i8Return){                            // Si se recibe un ACK
        i8Return=NO_ERROR;                                  // Indica que no hay error
    }else{                                                  // En el caso de que no se reciba error
        if(ERROR_DESCONOCIDO != i8Return){                  // Si es distinto a ERROR_DESCONOCIDO
            i8Return=ERROR_NOACK;                           // Devuelve error de NO ACK
        }
    }
    
    return i8Return;
}


int8 enviaComando(int8 i8Modo){

    int8 i8Return;
    // TODO: Secuencia de env�o de corriente medida
    switch(i8Modo){
        case M_CORRIENTE_ACT:                               // Env�a el comando de corriente medida a Sauron
            fputc(COMMAND_CORRIENTE_MED,COM_PIC_UART);      // Env�a el comando que indica que se va a enviar la corriente medida
            fputc('\r',COM_PIC_UART);                       // Env�a la secuencia de fin de tramma \r\n
            fputc('\n',COM_PIC_UART);
            while(!bDatoRecibido);                          // Mientras no haya recibido un dato...
            bDatoRecibido=0;                                // Inicializa el bit de dato recibido
            i8Return=gi8BufferData[0];                      // Recoge el dato del buffer de entrada
            break;
        default:                                            // En el caso de que se haga una selecci�n incorrecta
            i8Return=ERROR_DESCONOCIDO;                     // Devuelve error desconocido
    }
    
    if(COMANDO_ACK == i8Return){                            // Si se recibe un ACK                 
        i8Return=NO_ERROR;                                  // Indica que no hay error             
    }else{                                                  // En el caso de que no se reciba error
        if(ERROR_DESCONOCIDO != i8Return){                  // Si es distinto a ERROR_DESCONOCIDO  
                i8Return=ERROR_NOACK;                       // Devuelve error de NO ACK            
        }
    }
    
    return i8Return;
}
    
